package javaFrame;

import java.io.FileInputStream;
import java.util.Optional;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import application.Main;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import util.StringEncrpt;

public class AdminForm extends Application {
	
	public static Logger loggerAdminForm = LogManager.getLogger(AdminForm.class);
	
	String optionName = null;
	boolean isAdminLocal = false;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("DVMap - Administration Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerAdminForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);

		Text scenetitle = new Text(" DVMap Administration");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 1, 0, 2, 1);
		
//		Label starLabel1 = new Label("*");
//		starLabel1.setFont(Font.font("Tahoma", FontWeight.BOLD, 15));
//		starLabel1.setTextFill(Color.RED);
//		
//		Label starLabel2 = new Label("*");
//		starLabel2.setFont(Font.font("Tahoma", FontWeight.BOLD, 15));
//		starLabel2.setTextFill(Color.RED);
		
		Label newUser = new Label("User Details:");
//		grid.add(newUser, 0, 1);

		Label userID = new Label("Enter User ID:");
//		grid.add(userID, 1, 2);

		TextField userIDTextField = new TextField();
		userIDTextField.setPromptText("(*) mandatory field");
//		grid.add(userIDTextField, 2, 2);
		
//		Button userIDBtn = new Button("Add");
//		grid.add(userIDBtn, 3, 2);

		Label userPassword = new Label("Enter Password:");
//		grid.add(userPassword, 1, 3);

		PasswordField userPasswordTextField = new PasswordField();
		userPasswordTextField.setPromptText("(*) mandatory field");
//		grid.add(userPasswordTextField, 2, 3);
		
//		Button userPasswordBtn = new Button("Add");
//		grid.add(userPasswordBtn, 3, 3);
		
		Label macAddress = new Label("Enter MAC Address:");// (seperated by ':' OR '-'):");
//		grid.add(macAddress, 1, 4);

		TextField macAddressTextField = new TextField();
		macAddressTextField.setPromptText("(*) mandatory field");
//		grid.add(macAddressTextField, 2, 4);
		
		macAddressTextField.focusedProperty().addListener((arg0, oldValue, newValue) -> {
	        if (!newValue) { // when focus lost
	        	//6C-4B-90-09-B5-C0
	                if (!macAddressTextField.getText().matches("^([0-9A-Fa-f]{2}[-]){5}([0-9A-Fa-f]{2})$")) {
	                    // when it not matches the pattern (1.0 - 6.0)
	                    // set the textField empty
//	                	macAddressTextField.setStyle("-fx-text-inner-color: red;");
	                	macAddressTextField.setText("");
	                	//macAddressTextField.setPromptText("* missing field!");
	                	//macAddressTextField.setText("*");
	                }
//	                else {
//	                	macAddressTextField.setStyle("-fx-text-inner-color: black;");
//	                }
	            }
	        });
		
//		Button macAddressBtn = new Button("Add");
//		grid.add(macAddressBtn, 3, 4);
		
		Button saveUserDetailsBtn = new Button("Save User Details");
        HBox hbBtn4 = new HBox(10);
        hbBtn4.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn4.getChildren().add(saveUserDetailsBtn);
//      grid.add(saveUserDetailsBtn, 3, 5);
        
        Label radioLabel = new Label("Select Type of User:");
        
        ToggleGroup toggleGroup = new ToggleGroup();
        
        RadioButton adminButton1 = new RadioButton("Admin");
        adminButton1.setToggleGroup(toggleGroup);
        adminButton1.setUserData("Admin");
        //adminButton1.setSelected(true);
        
        RadioButton userButton2 = new RadioButton("User");
        userButton2.setToggleGroup(toggleGroup);
        userButton2.setUserData("User");
        //toggleGroup.selectedToggleProperty().addListener((observable, oldVal, newVal) -> System.out.println(newVal + " was selected"));
        
        HBox hbBtn5 = new HBox(10);
        hbBtn5.setAlignment(Pos.BOTTOM_CENTER);
        hbBtn5.getChildren().add(adminButton1);
        hbBtn5.getChildren().add(userButton2);
        
        toggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
            	if (toggleGroup.getSelectedToggle() != null) {
            		System.out.println(toggleGroup.getSelectedToggle().getUserData().toString());
            		if (toggleGroup.getSelectedToggle().getUserData().toString().equals("Admin")) {
            			isAdminLocal = true;
            		} else {
            			isAdminLocal = false;
            		}
	            }
            }
        });
        
		Separator sepHor = new Separator();
        sepHor.setValignment(VPos.CENTER);
        GridPane.setConstraints(sepHor, 0, 7);
        GridPane.setColumnSpan(sepHor, 4);
//      grid.getChildren().add(sepHor);
        
        if (Main.isAdministrator) {
        	grid.add(newUser, 0, 1);
        	grid.add(userID, 1, 2);
        	grid.add(userIDTextField, 2, 2);
        	grid.add(userPassword, 1, 3);
        	grid.add(userPasswordTextField, 2, 3);
        	grid.add(macAddress, 1, 4);
        	grid.add(macAddressTextField, 2, 4);
        	grid.add(radioLabel, 1, 5);
        	grid.add(hbBtn5, 2, 5);
        	grid.add(saveUserDetailsBtn, 3, 6);
        	grid.getChildren().add(sepHor);
        }
        
        Label databaseDetails = new Label("Database Configuration Details:");
		grid.add(databaseDetails, 0, 8);
		
		TextField optionTextField = new TextField();
		optionTextField.setPromptText("(*) mandatory field");
		grid.add(optionTextField, 2, 9);
		
		Button addOptionBtn = new Button("Add");
		grid.add(addOptionBtn, 3, 9);

		ComboBox addMenuComboBox = new ComboBox();
		addMenuComboBox.getItems().add("Application Name");
		addMenuComboBox.getItems().add("Region Name");
		addMenuComboBox.getItems().add("Host Name");
		addMenuComboBox.getItems().add("Port Number");
		addMenuComboBox.getItems().add("Database Name");
		addMenuComboBox.getItems().add("Table Name");
		addMenuComboBox.getItems().add("Server Name");
		addMenuComboBox.setPromptText("Select Option");
		addMenuComboBox.setMaxWidth(150);
		grid.add(addMenuComboBox, 1, 9);
		
		addMenuComboBox.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				if (t1.equals("Application Name")) {
					//appName = optionTextField.getText();
					optionName = "app";
				}
				else if (t1.equals("Region Name")) {
					//regionName = optionTextField.getText();
					optionName = "region";
				}
				else if (t1.equals("Host Name")) {
					//hostName = optionTextField.getText();
					optionName = "host";
				}
				else if (t1.equals("Port Number")) {
					//portNo = optionTextField.getText();
					optionName = "port";
				}
				else if (t1.equals("Database Name")) {
					//dbName = optionTextField.getText();
					optionName = "db";
				}
				else if (t1.equals("Table Name")) {
					//tableName = optionTextField.getText();
					optionName = "table";
				}
				else if (t1.equals("Server Name")) {
					//tableName = optionTextField.getText();
					optionName = "Server Name";
				}	
			}
		});
		



		
        Button backBtn = new Button("Back to Select Option");
        HBox hbBtn41 = new HBox(10);
        backBtn.setMinWidth(150);
        backBtn.setMinHeight(35);
        backBtn.setTextFill(Color.DARKBLUE);
        backBtn.setTextAlignment(TextAlignment.CENTER);
        backBtn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
        hbBtn41.setAlignment(Pos.BOTTOM_LEFT);
        hbBtn41.getChildren().add(backBtn);
        grid.add(hbBtn41, 0, 14);

//        Button saveDBDetailsBtn = new Button("Save Database Details");
//        HBox hbBtn411 = new HBox(10);
//        hbBtn411.setAlignment(Pos.BOTTOM_RIGHT);
//        hbBtn411.getChildren().add(saveDBDetailsBtn);
//        grid.add(hbBtn411, 3, 14);
		
        saveUserDetailsBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
            	Alert alert = new Alert(AlertType.ERROR);
//            	Alert alert2 = new Alert(AlertType.INFORMATION);
				if (userIDTextField.getText() == null || userIDTextField.getText().trim().isEmpty() 
						|| userPasswordTextField == null || userPasswordTextField.getText().trim().isEmpty() 
						|| macAddressTextField == null || macAddressTextField.getText().trim().isEmpty()
						|| toggleGroup.getSelectedToggle() == null || toggleGroup.getSelectedToggle().getUserData().toString().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("User Details Field values are missing!");
					loggerAdminForm.info("Run Time Error: User Details Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					if (isAdminLocal) {
						try {
//							LocalDate now = LocalDate.now();
							PropertiesConfiguration configFile = new PropertiesConfiguration("loginDetails.properties");
							configFile.setProperty(userIDTextField.getText() + "AdminID", userIDTextField.getText());
							configFile.setProperty(userIDTextField.getText() + "AdminPassword", userPasswordTextField.getText());
							configFile.setProperty(userIDTextField.getText() + "AdminMACAddress", StringEncrpt.encrypt(macAddressTextField.getText()+","+userIDTextField.getText()+","+userPasswordTextField.getText()+","+"admin"+","+Main.nowDate.plusYears(1)));
							configFile.save();
							
							TextInputDialog dialog = new TextInputDialog(StringEncrpt.encrypt(macAddressTextField.getText()+","+userIDTextField.getText()+","+userPasswordTextField.getText()+","+"admin"+","+Main.nowDate.plusYears(1)));
							dialog.setTitle("Admin Details");
							dialog.setHeaderText("Admin Information is saved successfully!");
							loggerAdminForm.info("Admin Details: Admin Information is saved successfully!");
							dialog.setContentText("Key for " + userIDTextField.getText()+ " is:");
							((Stage) dialog.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							dialog.showAndWait();
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							loggerAdminForm.error("ConfigurationException in loginDetails.properties", e1);
							e1.printStackTrace();
						}
					} else {
						try {
//							LocalDate now = LocalDate.now();
							PropertiesConfiguration configFile = new PropertiesConfiguration("loginDetails.properties");
							configFile.setProperty(userIDTextField.getText() + "UserID", userIDTextField.getText());
							configFile.setProperty(userIDTextField.getText() + "UserPassword", userPasswordTextField.getText());
							configFile.setProperty(userIDTextField.getText() + "UserMACAddress", StringEncrpt.encrypt(macAddressTextField.getText()+","+userIDTextField.getText()+","+userPasswordTextField.getText()+","+"user"+","+Main.nowDate.plusYears(1)));
							configFile.save();
							
							TextInputDialog dialog = new TextInputDialog(StringEncrpt.encrypt(macAddressTextField.getText()+","+userIDTextField.getText()+","+userPasswordTextField.getText()+","+"user"+","+Main.nowDate.plusYears(1)));
							dialog.setTitle("User Details");
							dialog.setHeaderText("User Information is saved successfully!");
							loggerAdminForm.info("User Details: User Information is saved successfully!");
							dialog.setContentText("Key for " + userIDTextField.getText()+ " is:");
							((Stage) dialog.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							dialog.showAndWait();
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							loggerAdminForm.error("ConfigurationException in loginDetails.properties", e1);
							e1.printStackTrace();
						}
					}
				}
            }
        });
        
        backBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
            	System.out.println("You are back in Main Menu!");
            	optionForm oppage = new optionForm();
            	oppage.start(primaryStage);
            }
        });
        
        addOptionBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
            	Alert alert = new Alert(AlertType.ERROR);
            	Alert alert2 = new Alert(AlertType.INFORMATION);
				if (optionTextField.getText() == null || optionTextField.getText().trim().isEmpty()
						//|| addMenuComboBox.getSelectionModel().getSelectedItem().toString() == null
						|| addMenuComboBox.getSelectionModel().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("User Details Field values are missing!");
					loggerAdminForm.info("Run Time Error: User Details Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					switch (optionName) {
	            	case "app":
	                	Main.appCount = Main.appCount + 1;
	                	try {
	    					PropertiesConfiguration appDetailsFile = new PropertiesConfiguration("appDetails.properties");
	    					appDetailsFile.setProperty("AppKey" + Main.appCount + "." + optionTextField.getText(), optionTextField.getText());
	    					appDetailsFile.save();
							alert2.setTitle("Application Details");
							alert2.setHeaderText("Application is saved successfully!");
							loggerAdminForm.info("Application Details: Application is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	            		} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	            			loggerAdminForm.error("ConfigurationException in appDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            		
	            	case "region":
	                	Main.regionCount = Main.regionCount + 1;
	                	try {
	                		PropertiesConfiguration regionDetailsFile = new PropertiesConfiguration("regionDetails.properties");
	                		regionDetailsFile.setProperty("RegionKey" + Main.regionCount + "." + optionTextField.getText(), optionTextField.getText());
	                		regionDetailsFile.save();
							alert2.setTitle("Region Details");
							alert2.setHeaderText("Region is saved successfully!");
							loggerAdminForm.info("Region Details: Region is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	    				} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	    					loggerAdminForm.error("ConfigurationException in regionDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            		
	            	case "host":
	                	Main.hostCount = Main.hostCount + 1;
	                	try {
	    					PropertiesConfiguration hostDetailsFile = new PropertiesConfiguration("hostDetails.properties");
	    					hostDetailsFile.setProperty("HostKey" + Main.hostCount + "." + optionTextField.getText(), optionTextField.getText());
	    					hostDetailsFile.save();
							alert2.setTitle("Host Details");
							alert2.setHeaderText("Host is saved successfully!");
							loggerAdminForm.info("Host Details: Host is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	    				} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	    					loggerAdminForm.error("ConfigurationException in hostDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            		
	            	case "port":
	                	Main.portCount = Main.portCount + 1;
	                	try {
	                		PropertiesConfiguration portDetailsFile = new PropertiesConfiguration("portDetails.properties");
	                		portDetailsFile.setProperty("PortNoKey" + Main.portCount + "." + optionTextField.getText(), optionTextField.getText());
	                		portDetailsFile.save();
							alert2.setTitle("Port Number Details");
							alert2.setHeaderText("Port Number is saved successfully!");
							loggerAdminForm.info("Port Number Details: Port Number is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	    				} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	    					loggerAdminForm.error("ConfigurationException in portDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            		
	            	case "db":
	                	Main.dbNameCount = Main.dbNameCount + 1;
	                	try {
	                		PropertiesConfiguration dbDetailsFile = new PropertiesConfiguration("dbNameDetails.properties");
	                		dbDetailsFile.setProperty("DBNameKey" + Main.dbNameCount + "." + optionTextField.getText(), optionTextField.getText());
	                		dbDetailsFile.save();
							alert2.setTitle("Database Details");
							alert2.setHeaderText("Database is saved successfully!");
							loggerAdminForm.info("Database Details: Database is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	    				} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	    					loggerAdminForm.error("ConfigurationException in dbNameDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            		
	            	case "table":
	                	Main.tableCount = Main.tableCount + 1;
	                	try {
	                		PropertiesConfiguration tableDetailsFile = new PropertiesConfiguration("tableDetails.properties");
	                		tableDetailsFile.setProperty("TableKey" + Main.tableCount + "." + optionTextField.getText(), optionTextField.getText());
	                		tableDetailsFile.save();
							alert2.setTitle("Table Name Details");
							alert2.setHeaderText("Table Name is saved successfully!");
							loggerAdminForm.info("Table Name Details: Table Name is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	    				} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	    					loggerAdminForm.error("ConfigurationException in tableDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            	case "Server Name":
	                	Main.serverCount = Main.serverCount + 1;
	                	try {
	                		PropertiesConfiguration serverDetailsFile = new PropertiesConfiguration("serverDetails.properties");
	                		serverDetailsFile.setProperty("ServerKey" + Main.serverCount + "." + optionTextField.getText(), optionTextField.getText());
	                		serverDetailsFile.save();
							alert2.setTitle("Server Name Details");
							alert2.setHeaderText("Server Name is saved successfully!");
							loggerAdminForm.info("Server Name Details: Table Name is saved successfully!");
							alert2.setContentText("");
							((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert2.showAndWait();
	    				} catch (Exception e1) {
	    					// TODO Auto-generated catch block
	    					loggerAdminForm.error("ConfigurationException in tableDetails.properties", e1);
	    					e1.printStackTrace();
	    				}
	            		break;
	            	default:
	            		loggerAdminForm.info("Without Selecting Option, Data is Entered!");
	            		System.out.println("Wrong Option Selected!");
	            		break;
	            	}
				}            	
            }
        });
        
//        saveDBDetailsBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Alert alert = new Alert(AlertType.ERROR);
//				if (appNameTextField.getText() == null || appNameTextField.getText().trim().isEmpty() 
//						|| regionNameTextField == null || regionNameTextField.getText().trim().isEmpty() 
//						|| hostNameTextField == null || hostNameTextField.getText().trim().isEmpty()
//						|| dbNameTextField == null || dbNameTextField.getText().trim().isEmpty()
//						|| portNoTextField == null || portNoTextField.getText().trim().isEmpty()
//						|| tableNameTextField == null || tableNameTextField.getText().trim().isEmpty()) {
//					alert.setTitle("Run Time Error");
//					alert.setHeaderText("Database Details Field values are missing!");
//					alert.setContentText("");
//					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
//					alert.showAndWait();
//				} else {
//	            	String tableNames = tableNameTextField.getText().toString();
//	            	List<String> l = Lists.newArrayList(Splitter.on(",").trimResults().split(tableNames));
//	            	for (String tname : l) {
//	            		System.out.println(tname);
//	            	}
//					System.out.println("Database Details Saved Successfully!");
//				}
//            }
//        });
//        
//        addAppNameBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Main.appCount = Main.appCount + 1;
//            	try {
//					PropertiesConfiguration appDetailsFile = new PropertiesConfiguration("appDetails.properties");
//					appDetailsFile.setProperty("AppKey" + Main.appCount + "." + appNameTextField.getText(), appNameTextField.getText());
//					appDetailsFile.save();
//        		} catch (ConfigurationException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//            }
//        });
//        
//        addRegionNameBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Main.regionCount = Main.regionCount + 1;
//            	try {
//            		PropertiesConfiguration regionDetailsFile = new PropertiesConfiguration("regionDetails.properties");
//            		regionDetailsFile.setProperty("RegionKey" + Main.regionCount + "." + regionNameTextField.getText(), regionNameTextField.getText());
//            		regionDetailsFile.save();
//				} catch (ConfigurationException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}            	
//            }
//        });
//        
//        addDBNameBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Main.dbNameCount = Main.dbNameCount + 1;
//            	try {
//            		PropertiesConfiguration dbDetailsFile = new PropertiesConfiguration("dbNameDetails.properties");
//            		dbDetailsFile.setProperty("DBNameKey" + Main.dbNameCount + "." + dbNameTextField.getText(), dbNameTextField.getText());
//            		dbDetailsFile.save();
//				} catch (ConfigurationException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//            }
//        });
//        
//        addHostNameBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Main.hostCount = Main.hostCount + 1;
//            	try {
//					PropertiesConfiguration hostDetailsFile = new PropertiesConfiguration("hostDetails.properties");
//					hostDetailsFile.setProperty("HostKey" + Main.hostCount + "." + hostNameTextField.getText(), hostNameTextField.getText());
//					hostDetailsFile.save();
//				} catch (ConfigurationException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//            }
//        });
//        
//        addPortNoBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Main.portCount = Main.portCount + 1;
//            	try {
//            		PropertiesConfiguration portDetailsFile = new PropertiesConfiguration("portDetails.properties");
//            		portDetailsFile.setProperty("PortNoKey" + Main.portCount + "." + portNoTextField.getText(), portNoTextField.getText());
//            		portDetailsFile.save();
//				} catch (ConfigurationException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//            }
//        });
//        
//        addTableNameBtn.setOnAction(new EventHandler<ActionEvent>() {
//
//            @Override
//            public void handle(ActionEvent e) {
//            	Main.tableCount = Main.tableCount + 1;
//            	try {
//            		PropertiesConfiguration tableDetailsFile = new PropertiesConfiguration("tableDetails.properties");
//            		tableDetailsFile.setProperty("TableKey" + Main.tableCount + "." + tableNameTextField.getText(), tableNameTextField.getText());
//            		tableDetailsFile.save();
//				} catch (ConfigurationException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//            }
//        });
        
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				// consume event
				event.consume();

				// show close dialog
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerAdminForm.info("AdminForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 700, 500);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
	}
}
