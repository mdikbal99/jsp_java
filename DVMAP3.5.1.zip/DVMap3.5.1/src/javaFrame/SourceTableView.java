package javaFrame;



import org.apache.commons.configuration.ConfigurationException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Callback;
import util.MyExcelConnect;
 
public class SourceTableView extends Application {
	public static Logger loggerSourceTableView = LogManager.getLogger(SourceTableView.class);
    private  TableView<SourceDataDTO> tableSource = new TableView<SourceDataDTO>();
    public static ObservableList<SourceDataDTO> dataSource =FXCollections.observableArrayList();
   // new SourceDataDTO("HLD_TEST", "7", "10","y","no","comma");
    
    
    final HBox hb = new HBox();
    final HBox hb2 = new HBox();
    final VBox vbox = new VBox();
 
   /* public static void main(String[] args) {
        launch(args);
    }*/
    
  //public String dataSheetName=System.getProperty("user.dir")+"\\FileValidationDetails.xls";
  // MyExcelConnect mec3= new MyExcelConnect(fileToFileForm.file3path,2);
  // MyExcelConnect mers= new MyExcelConnect(fileToFileForm.file3path,3);

   

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
    public void start(Stage stage) {
       Scene scene = new Scene(new Group());
       
        stage.setTitle("Source Data Table View");
     //   stage.setWidth(600);
        //stage.setHeight(500);
 
        final Label label = new Label("Source data Book");
        label.setFont(new Font("Arial", 20));
 
        tableSource.setEditable(true);
        
        Callback<TableColumn, TableCell> cellFactory =
             new Callback<TableColumn, TableCell>() {
                 public TableCell call(TableColumn p) {
                    return new EditingCell();
                 }
             };
 
        TableColumn entity_field_nameCol = new TableColumn("Entity Field Name");
        entity_field_nameCol.setMinWidth(120);
        entity_field_nameCol.setCellValueFactory(
            new PropertyValueFactory<SourceDataDTO, String>("entity_field_name"));
        entity_field_nameCol.setCellFactory(cellFactory);
        entity_field_nameCol.setOnEditCommit(
            new EventHandler<CellEditEvent<SourceDataDTO, String>>() {
                @Override
                public void handle(CellEditEvent<SourceDataDTO, String> t) {
                    ((SourceDataDTO) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setEntity_field_name(t.getNewValue());
                }
             }
        );
 
 
        TableColumn position1Col = new TableColumn("Position1");
        position1Col.setMinWidth(100);
        position1Col.setCellValueFactory(
            new PropertyValueFactory<SourceDataDTO, String>("position1"));
        position1Col.setCellFactory(cellFactory);
        position1Col.setOnEditCommit(
            new EventHandler<CellEditEvent<SourceDataDTO, String>>() {
                @Override
                public void handle(CellEditEvent<SourceDataDTO, String> t) {
                    ((SourceDataDTO) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setPosition1(t.getNewValue());
                }
            }
        );
        TableColumn position2Col = new TableColumn("Position2");
        position2Col.setMinWidth(100);
        position2Col.setCellValueFactory(
            new PropertyValueFactory<SourceDataDTO, String>("position2"));
        position2Col.setCellFactory(cellFactory);
        position2Col.setOnEditCommit(
            new EventHandler<CellEditEvent<SourceDataDTO, String>>() {
                @Override
                public void handle(CellEditEvent<SourceDataDTO, String> t) {
                    ((SourceDataDTO) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setPosition2(t.getNewValue());
                }
            }
        );
        TableColumn primary_keyCol = new TableColumn("Primary_key");
        primary_keyCol.setMinWidth(100);
        primary_keyCol.setCellValueFactory(
            new PropertyValueFactory<SourceDataDTO, String>("primary_key"));
        primary_keyCol.setCellFactory(cellFactory);
        primary_keyCol.setOnEditCommit(
            new EventHandler<CellEditEvent<SourceDataDTO, String>>() {
                @Override
                public void handle(CellEditEvent<SourceDataDTO, String> t) {
                    ((SourceDataDTO) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setPrimary_key(t.getNewValue());
                }
            }
        );
        TableColumn tlogicCol = new TableColumn("TL");
        tlogicCol.setMinWidth(100);
        tlogicCol.setCellValueFactory(
            new PropertyValueFactory<SourceDataDTO, String>("tlogic"));
        tlogicCol.setCellFactory(cellFactory);
        tlogicCol.setOnEditCommit(
            new EventHandler<CellEditEvent<SourceDataDTO, String>>() {
                @Override
                public void handle(CellEditEvent<SourceDataDTO, String> t) {
                    ((SourceDataDTO) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setTlogic(t.getNewValue());
                }
            }
        );
        
        TableColumn file_typeCol = new TableColumn("File_type");
        file_typeCol.setMinWidth(100);
        file_typeCol.setCellValueFactory(
            new PropertyValueFactory<SourceDataDTO, String>("file_type"));
        file_typeCol.setCellFactory(cellFactory);
        file_typeCol.setOnEditCommit(
            new EventHandler<CellEditEvent<SourceDataDTO, String>>() {
                @Override
                public void handle(CellEditEvent<SourceDataDTO, String> t) {
                    ((SourceDataDTO) t.getTableView().getItems().get(
                        t.getTablePosition().getRow())
                        ).setFile_type(t.getNewValue());
                }
            }
        );
 
        tableSource.setItems(dataSource);
        tableSource.getColumns().addAll(entity_field_nameCol, position1Col,position2Col,primary_keyCol,tlogicCol, file_typeCol);
        
 
         TextField addEntityField = new TextField();
        addEntityField.setPromptText("Entity Field Name");
        addEntityField.setMaxWidth(entity_field_nameCol.getPrefWidth());
        
        final TextField addPosition1 = new TextField();
        addPosition1.setPromptText("Position1");
        addPosition1.setMaxWidth(position1Col.getPrefWidth());
        
        
        final TextField addPosition2 = new TextField();
        addPosition2.setPromptText("Position2");
        addPosition2.setMaxWidth(position2Col.getPrefWidth());
        
        final TextField addPrimaryKey = new TextField();
        addPrimaryKey.setPromptText("Primary Key");
        addPrimaryKey.setMaxWidth(primary_keyCol.getPrefWidth());
        
        final TextField addTl = new TextField();
        addTl.setMaxWidth(tlogicCol.getPrefWidth());
        addTl.setPromptText("Trans Logic");
        
        
        final TextField addFileType = new TextField();
        addFileType.setMaxWidth(file_typeCol.getPrefWidth());
        addFileType.setPromptText("File Type");
 
        final Button addButton = new Button("Add");
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
            	
            	
            	   
                dataSource.add(new SourceDataDTO(addEntityField.getText(),addPosition1.getText(),addPosition2.getText(),addPrimaryKey.getText(),addTl.getText(),addFileType.getText()));
                MyExcelConnect mec4= new MyExcelConnect(fileToFileForm.file3path,2);
                mec4.deleteData(2);
              //  System.out.println(new SourceDataDTO(addEntityField.getText(),addPosition1.getText(),addPosition2.getText(),addPrimaryKey.getText(),addTl.getText(),addFileType.getText()).toString());
        	try{
                for(int i=0;i<dataSource.size();i++){
                	
                	MyExcelConnect mec3= new MyExcelConnect(fileToFileForm.file3path,2);
                	mec3.setData(i+2, 1, dataSource.get(i).getEntity_field_name());
                	mec3.setData(i+2, 2, dataSource.get(i).getPosition1());
                	mec3.setData(i+2, 5, dataSource.get(i).getPosition2());
                	mec3.setData(i+2, 4, dataSource.get(i).getPrimary_key());
                	mec3.setData(i+2, 6, dataSource.get(i).getTlogic());
                	mec3.setData(i+2, 7, dataSource.get(i).getFile_type());
                	
                	MyExcelConnect mers= new MyExcelConnect(fileToFileForm.file3path,3);  
                	mers.setData(i+2, 1, dataSource.get(i).getEntity_field_name());
                	mers.setData(i+2, 3, dataSource.get(i).getPrimary_key());
                }
                
        	}catch(Throwable t){
        		loggerSourceTableView.error("Exception in SourceTV while data set up in excel");
        		t.printStackTrace();
        		
        	}
                
                addEntityField.clear();
                addPosition1.clear();
                addPosition2.clear();
                addPrimaryKey.clear();
                addTl.clear();
                addFileType.clear();

                
            }
        });
        
        final Button backBtn= new Button("Back");
        backBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
            	try {
            		System.out.println("You are back in File to File Menu!");
					fileToFileForm ftof = new fileToFileForm();
					ftof.start(stage);
				} catch (ConfigurationException e1) {
					e1.printStackTrace();
				}
                
            }
        });
        
        Button nextBtn = new Button("Next");
    	nextBtn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are in Target Table View");
				TargetTableView ttv = new TargetTableView();
				ttv.start(stage);
				
			}
		});
 
        hb.getChildren().addAll(addEntityField, addPosition1, addPosition2, addPrimaryKey,addTl,addFileType,addButton);
        hb.setSpacing(10);
        
      
        hb2.getChildren().addAll(backBtn,nextBtn);
        hb2.setSpacing(10);
        
        //final VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(15, 10, 10, 15));
        vbox.getChildren().addAll(label, tableSource, hb,hb2);
 
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        
      //  Scene scene2 = new Scene(new GridPane(), 700, 400);
        stage.setScene(scene);
        stage.show();
        stage.centerOnScreen();
      
    }
 

 
    class EditingCell extends TableCell<SourceDataDTO, String> {
 
        private TextField textField;
 
        public EditingCell() {
        }
 
        @Override
        public void startEdit() {
            if (!isEmpty()) {
                super.startEdit();
                createTextField();
                setText(null);
                setGraphic(textField);
                textField.selectAll();
            }
        }
 
        @Override
        public void cancelEdit() {
            super.cancelEdit();
 
            setText((String) getItem());
            setGraphic(null);
        }
 
        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
 
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                if (isEditing()) {
                    if (textField != null) {
                        textField.setText(getString());
                    }
                    setText(null);
                    setGraphic(textField);
                } else {
                    setText(getString());
                    setGraphic(null);
                }
            }
        }
 
        private void createTextField() {
            textField = new TextField(getString());
            textField.setMinWidth(this.getWidth() - this.getGraphicTextGap()* 2);
            textField.focusedProperty().addListener(new ChangeListener<Boolean>(){
                @Override
                public void changed(ObservableValue<? extends Boolean> arg0, 
                    Boolean arg1, Boolean arg2) {
                        if (!arg2) {
                            commitEdit(textField.getText());
                        }
                }
            });
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
    }
}