package javaFrame;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class configureForm extends Application {

	public static Logger loggerConfigureForm = LogManager.getLogger(configureForm.class);
	
	String dbType = null;
	String key = null;
	String appName = null;
	String environmentName = null;
	String regionName = null;
	String portNo = null;
	String hostName = null;
	String databaseName = null;
	String serverName=null;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("DVMap - Database Configuration Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerConfigureForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);

		Text scenetitle = new Text(" Database Configuration");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 1, 0, 2, 1);

		Label dbServerName = new Label("Environment Name:");
		grid.add(dbServerName, 0, 2);

		TextField dbServerTextField = new TextField();
		dbServerTextField.setPromptText("(*) mandatory field");
		grid.add(dbServerTextField, 1, 2);

		Label dbAppName = new Label("Application Name:");
		grid.add(dbAppName, 0, 1);

		ComboBox appComboBox = new ComboBox();
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("appDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				appComboBox.getItems().add(configFile.getProperty(key));
			}

			appComboBox.setPromptText("Select Application Name");
			appComboBox.setMaxWidth(200);
			grid.add(appComboBox, 1, 1);

			appComboBox.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					appName = t1;
					environmentName = appName;
					dbServerTextField.setText(environmentName);
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in appDetails.properties", e);
			e.printStackTrace();
		}

//		Button addApp = new Button("+");
//		grid.add(addApp, 2, 1);

		Label dbRegionName = new Label("Region Name:");
		grid.add(dbRegionName, 3, 1);

		ComboBox regionComboBox = new ComboBox();
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("regionDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				regionComboBox.getItems().add(configFile.getProperty(key));
			}

			regionComboBox.setPromptText("Select Region Name");
			regionComboBox.setMaxWidth(200);
			grid.add(regionComboBox, 4, 1);

			regionComboBox.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					regionName = t1;
					environmentName = environmentName + " - " + regionName;
					dbServerTextField.setText(environmentName);
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in regionDetails.properties", e);
			e.printStackTrace();
		}

//		Button addregion = new Button("+");
//		grid.add(addregion, 5, 1);

		Label dbHostName = new Label("Database Host Name:");
		grid.add(dbHostName, 0, 4);

		ComboBox comboBoxHost = new ComboBox();
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("hostDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				comboBoxHost.getItems().add(configFile.getProperty(key));
			}

			comboBoxHost.setPromptText("Select Host No");
			comboBoxHost.setMaxWidth(200);
			grid.add(comboBoxHost, 1, 4);

			comboBoxHost.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					hostName = t1;
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in hostDetails.properties", e);
			e.printStackTrace();
		}

//		Button addHostName = new Button("+");
//		grid.add(addHostName, 2, 4);

		Label dbPortNo = new Label("Database Port No:");
		grid.add(dbPortNo, 3, 4);

		ComboBox comboBoxPortNo = new ComboBox();

		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("portDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				comboBoxPortNo.getItems().add(configFile.getProperty(key));
			}

			comboBoxPortNo.setPromptText("Select Port No");
			comboBoxPortNo.setMaxWidth(200);
			grid.add(comboBoxPortNo, 4, 4);

			comboBoxPortNo.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					portNo = t1;
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in portDetails.properties", e);
			e.printStackTrace();
		}

//		Button addPortNo = new Button("+");
//		grid.add(addPortNo, 5, 4);
//--------------------------------------------------------------------------------
		Label dbserverName = new Label("Database Server Name:");
		grid.add(dbserverName, 3, 5);
	ComboBox comboBoxServerName = new ComboBox();

		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("serverDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				comboBoxServerName.getItems().add(configFile.getProperty(key));
			}

			comboBoxServerName.setPromptText("Select Server");
			comboBoxServerName.setMaxWidth(200);
			grid.add(comboBoxServerName, 4, 5);

			comboBoxServerName.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					serverName = t1;
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in MySQL Server Details.properties", e);
			e.printStackTrace();
		}
		
		//------------------------------------------------------------------------
		Label dbUserName = new Label("Database User Name:");
		grid.add(dbUserName, 0, 5);

		TextField dbUserTextField = new TextField();
		dbUserTextField.setPromptText("(*) mandatory field");
		grid.add(dbUserTextField, 1, 5);

		Label dbPassword = new Label("Database Password:");
		grid.add(dbPassword, 0, 6);

		PasswordField dbPasswordTextField = new PasswordField();
		dbPasswordTextField.setPromptText("(*) mandatory field");
		grid.add(dbPasswordTextField, 1, 6);

		ComboBox existingServerComboBox = new ComboBox();

		Label dbName = new Label("Database Name:");
		grid.add(dbName, 0, 3);

		ComboBox comboBoxDBName = new ComboBox();
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("dbNameDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				comboBoxDBName.getItems().add(configFile.getProperty(key));
			}

			comboBoxDBName.setPromptText("Select Database Name");
			comboBoxDBName.setMaxWidth(200);
			grid.add(comboBoxDBName, 1, 3);

			comboBoxDBName.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					hostName = t1;
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in dbNameDetails.properties", e);
			e.printStackTrace();
		}


		Label dbTypeName = new Label("Database Type:");
		grid.add(dbTypeName, 3, 3);

		ComboBox dbTypecomboBox = new ComboBox();
		dbTypecomboBox.getItems().add("Hive");
		dbTypecomboBox.getItems().add("DB2");
		dbTypecomboBox.getItems().add("Oracle");
		dbTypecomboBox.getItems().add("MySqlServer");
		dbTypecomboBox.setPromptText("Select Database Type");
		dbTypecomboBox.setMaxWidth(200);

		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("configureDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				if (key.contains(configFile.getProperty(key) + "HiveAppName")
						|| key.contains(configFile.getProperty(key) + "DB2AppName")
						|| key.contains(configFile.getProperty(key) + "OracleAppName")
						||key.contains(configFile.getProperty(key) + "MySqlServerAppName")) {
					existingServerComboBox.getItems().add(configFile.getProperty(key));
				}
			}

			existingServerComboBox.setPromptText("Select Existing Environment");
			existingServerComboBox.setMaxWidth(200);
			grid.add(existingServerComboBox, 2, 2);

			existingServerComboBox.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					dbServerTextField.setText(t1);
					Iterator<String> keys = configFile.getKeys();
					ArrayList<String> keyList = new ArrayList<String>();
					while (keys.hasNext()) {
						keyList.add(keys.next());
					}

					for (String key : keyList) {
						if (key.contains(t1 + "HiveAppName")) {
							dbTypecomboBox.setValue("Hive");
							//appComboBox.setValue(configFile.getProperty(t1 + "HiveAppName").toString().split("-")[0]);
							//regionComboBox.setValue(configFile.getProperty(t1 + "HiveAppName").toString().split("-")[1]);
							appComboBox.setValue(configFile.getProperty(t1 + "HiveApplication"));
							regionComboBox.setValue(configFile.getProperty(t1 + "HiveRegion"));
							dbUserTextField.setText((String) configFile.getProperty(t1 + "HiveUserName"));
							comboBoxHost.setValue(configFile.getProperty(t1 + "HiveHostName"));
							dbPasswordTextField.setText((String) configFile.getProperty(t1 + "HivePassword"));
							comboBoxPortNo.setValue(configFile.getProperty(t1 + "HivePortNo"));
							comboBoxDBName.setValue(configFile.getProperty(t1 + "HiveDBName"));
							comboBoxServerName.setValue(configFile.getProperty(t1 + "HiveServerName"));
						}
						if (key.contains(t1 + "DB2AppName")) {
							dbTypecomboBox.setValue("DB2");
							appComboBox.setValue(configFile.getProperty(t1 + "DB2Application"));
							regionComboBox.setValue(configFile.getProperty(t1 + "DB2Region"));
							dbUserTextField.setText((String) configFile.getProperty(t1 + "DB2UserName"));
							comboBoxHost.setValue(configFile.getProperty(t1 + "DB2HostName"));
							dbPasswordTextField.setText((String) configFile.getProperty(t1 + "DB2Password"));
							comboBoxPortNo.setValue(configFile.getProperty(t1 + "DB2PortNo"));
							comboBoxDBName.setValue(configFile.getProperty(t1 + "DB2DBName"));
							comboBoxServerName.setValue(configFile.getProperty(t1 + "DB2ServerName"));
						}
						
						if (key.contains(t1 + "OracleAppName")) {
							dbTypecomboBox.setValue("Oracle");
					        appComboBox.setValue(configFile.getProperty(t1 + "DB2Application"));
							regionComboBox.setValue(configFile.getProperty(t1 + "OracleRegion"));
							dbUserTextField.setText((String) configFile.getProperty(t1 + "OracleUserName"));
							comboBoxHost.setValue(configFile.getProperty(t1 + "OracleHostName"));
							dbPasswordTextField.setText((String) configFile.getProperty(t1 + "OraclePassword"));
							comboBoxPortNo.setValue(configFile.getProperty(t1 + "OraclePortNo"));
							comboBoxDBName.setValue(configFile.getProperty(t1 + "OracleDBName"));
							comboBoxServerName.setValue(configFile.getProperty(t1 + "OracleServerName"));
						}
						if (key.contains(t1 + "MySqlServerAppName")) {
							dbTypecomboBox.setValue("MySqlServer");
							appComboBox.setValue(configFile.getProperty(t1 + "MySqlServerApplication"));
							regionComboBox.setValue(configFile.getProperty(t1 + "MySqlServerRegion"));
							dbUserTextField.setText((String) configFile.getProperty(t1 + "MySqlServerUserName"));
							comboBoxHost.setValue(configFile.getProperty(t1 + "MySqlServerHostName"));
							dbPasswordTextField.setText((String) configFile.getProperty(t1 + "MySqlServerPassword"));
							comboBoxPortNo.setValue(configFile.getProperty(t1 + "MySqlServerPortNo"));
							comboBoxDBName.setValue(configFile.getProperty(t1 + "MySqlServerDBName"));
							comboBoxServerName.setValue(configFile.getProperty(t1 + "MySqlServerServerName"));
						}
					}
				}
			});
		} catch (Exception e) {
			loggerConfigureForm.error("ConfigurationException in configureDetails.properties", e);
			e.printStackTrace();
		}
		grid.add(dbTypecomboBox, 4, 3);

		dbTypecomboBox.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				dbType = t1;
			}
		});

//		Button addDBType = new Button("+");
//		grid.add(addDBType, 5, 3);

		Button backBtn = new Button("Back to Select Option");
		HBox hbBtn4 = new HBox(10);
		backBtn.setMinWidth(150);
		backBtn.setMinHeight(35);
		backBtn.setTextFill(Color.DARKBLUE);
		backBtn.setTextAlignment(TextAlignment.CENTER);
		backBtn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbBtn4.setAlignment(Pos.BOTTOM_LEFT);
		hbBtn4.getChildren().add(backBtn);
		grid.add(hbBtn4, 0, 8);

		Button clearBtn = new Button("Clear");
		HBox hbBtn5 = new HBox(10);
		clearBtn.setMinWidth(150);
		clearBtn.setMinHeight(35);
		clearBtn.setTextFill(Color.DARKBLUE);
		clearBtn.setTextAlignment(TextAlignment.CENTER);
		clearBtn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbBtn5.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn5.getChildren().add(clearBtn);
		grid.add(hbBtn5, 1, 8);

		Button saveDBDetails = new Button("Save Connection");
		HBox hbBtn2 = new HBox(10);
		saveDBDetails.setMinWidth(150);
		saveDBDetails.setMinHeight(35);
		saveDBDetails.setTextFill(Color.DARKBLUE);
		saveDBDetails.setTextAlignment(TextAlignment.CENTER);
		saveDBDetails.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbBtn2.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn2.getChildren().add(saveDBDetails);
		grid.add(hbBtn2, 3, 8);

		Button deleteConn = new Button("Delete Connection");
		HBox hbBtn3 = new HBox(10);
		deleteConn.setMinWidth(150);
		deleteConn.setMinHeight(35);
		deleteConn.setTextFill(Color.DARKBLUE);
		deleteConn.setTextAlignment(TextAlignment.CENTER);
		deleteConn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbBtn3.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn3.getChildren().add(deleteConn);
		grid.add(hbBtn3, 4, 8);

//		final Text actiontarget = new Text();
//		grid.add(actiontarget, 1, 7);

		backBtn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are back in Main Menu!");
				optionForm oppage = new optionForm();
				oppage.start(primaryStage);
			}
		});

		clearBtn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				clearAll(dbServerTextField, dbUserTextField, dbPasswordTextField, comboBoxHost, comboBoxDBName,
						comboBoxPortNo, appComboBox, regionComboBox, dbTypecomboBox, existingServerComboBox,comboBoxServerName);
			}
		});

		saveDBDetails.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				Alert alert = new Alert(AlertType.ERROR);
				if (dbServerTextField.getText() == null || dbServerTextField.getText().trim().isEmpty()
						|| dbUserTextField.getText() == null || dbUserTextField.getText().trim().isEmpty()
						|| dbPasswordTextField.getText() == null || dbPasswordTextField.getText().trim().isEmpty()
						|| comboBoxDBName.getSelectionModel().getSelectedItem().toString() == null
						|| comboBoxDBName.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| comboBoxHost.getSelectionModel().getSelectedItem().toString() == null
						|| comboBoxHost.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| comboBoxPortNo.getSelectionModel().getSelectedItem().toString() == null
						|| comboBoxPortNo.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| dbTypecomboBox.getSelectionModel().getSelectedItem().toString() == null
						|| dbTypecomboBox.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| appComboBox.getSelectionModel().getSelectedItem().toString() == null
						|| appComboBox.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| regionComboBox.getSelectionModel().getSelectedItem().toString() == null
						|| regionComboBox.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						||comboBoxServerName.getSelectionModel().getSelectedItem().toString() == null
						||comboBoxServerName.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerConfigureForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					try {
						PropertiesConfiguration configFile1 = new PropertiesConfiguration(
								"configureDetails.properties");

						String dbApplication = appComboBox.getSelectionModel().getSelectedItem().toString();
						String dbRegionName = regionComboBox.getSelectionModel().getSelectedItem().toString();
						
						String dbAppName = dbServerTextField.getText().toString();
						String dbHostName = comboBoxHost.getSelectionModel().getSelectedItem().toString();
						String dbUserName = dbUserTextField.getText().toString();
						String dbPassword = dbPasswordTextField.getText().toString();
						String dbPortNo = comboBoxPortNo.getSelectionModel().getSelectedItem().toString();
						String dbName = comboBoxDBName.getSelectionModel().getSelectedItem().toString();
						String dbSqlServerName=comboBoxServerName.getSelectionModel().getSelectedItem().toString();

						String dbApplicationKey = dbAppName + dbType + "Application";
						String dbRegionKey = dbAppName + dbType + "Region";
						String dbAppNameKey = dbAppName + dbType + "AppName";
						String dbHostNameKey = dbAppName + dbType + "HostName";
						String dbUserNameKey = dbAppName + dbType + "UserName";
						String dbPasswordKey = dbAppName + dbType + "Password";
						String dbPortNoKey = dbAppName + dbType + "PortNo";
						String dbNameKey = dbAppName + dbType + "DBName";
						String dbServerkey=dbAppName+dbType+"ServerName";

						configFile1.setProperty(dbApplicationKey, dbApplication);
						configFile1.setProperty(dbRegionKey, dbRegionName);
						configFile1.setProperty(dbAppNameKey, dbAppName);
						configFile1.setProperty(dbHostNameKey, dbHostName);
						configFile1.setProperty(dbUserNameKey, dbUserName);
						configFile1.setProperty(dbPasswordKey, dbPassword);
						configFile1.setProperty(dbPortNoKey, dbPortNo);
						configFile1.setProperty(dbNameKey, dbName);
						configFile1.setProperty(dbServerkey, dbSqlServerName);
						configFile1.save();

						System.out.println("Entered Database Application Name: " + dbApplication);
						System.out.println("Entered Database Region Name: " + dbRegionName);
						System.out.println("Entered Database Environment Name: " + dbAppName);
						System.out.println("Entered Database Host Name: " + dbHostName);
						System.out.println("Entered Database User Name: " + dbUserName);
						System.out.println("Entered Database Password: " + dbPassword);
						System.out.println("Entered Database Port No: " + dbPortNo);
						System.out.println("Entered Database Name: " + dbName);
						System.out.println("Entered Server Name: " + dbSqlServerName);

						clearAll(dbServerTextField, dbUserTextField, dbPasswordTextField, comboBoxHost, comboBoxDBName,
								comboBoxPortNo, appComboBox, regionComboBox, dbTypecomboBox, existingServerComboBox,comboBoxServerName);

						Alert alert1 = new Alert(AlertType.INFORMATION);
						alert1.setTitle("Save Confirmation");
						alert1.setHeaderText("Database Configuration is Saved Successfully!");
						loggerConfigureForm.info("Save Confirmation: Database Configuration is Saved Successfully!");
						alert1.initOwner(primaryStage);
						alert1.showAndWait();
					} catch (Exception e1) {
						loggerConfigureForm.error("ConfigurationException in configureDetails.properties", e1);
						e1.printStackTrace();
					}
				}
			}
		});

		deleteConn.setOnAction(new EventHandler<ActionEvent>() {

			@SuppressWarnings("unused")
			@Override
			public void handle(ActionEvent e) {
				Alert alert = new Alert(AlertType.ERROR);
				if (dbServerTextField.getText() == null || dbServerTextField.getText().trim().isEmpty()
						|| dbUserTextField.getText() == null || dbUserTextField.getText().trim().isEmpty()
						|| dbPasswordTextField.getText() == null || dbPasswordTextField.getText().trim().isEmpty()
						|| comboBoxDBName.getSelectionModel().getSelectedItem().toString() == null
						|| comboBoxDBName.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| comboBoxHost.getSelectionModel().getSelectedItem().toString() == null
						|| comboBoxHost.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| comboBoxPortNo.getSelectionModel().getSelectedItem().toString() == null
						|| comboBoxPortNo.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| dbTypecomboBox.getSelectionModel().getSelectedItem().toString() == null
						|| dbTypecomboBox.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| appComboBox.getSelectionModel().getSelectedItem().toString() == null
						|| appComboBox.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						|| regionComboBox.getSelectionModel().getSelectedItem().toString() == null
						|| regionComboBox.getSelectionModel().getSelectedItem().toString().trim().isEmpty()
						||comboBoxServerName.getSelectionModel().getSelectedItem().toString() == null
						||comboBoxServerName.getSelectionModel().getSelectedItem().toString().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerConfigureForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					Alert alert1 = new Alert(AlertType.CONFIRMATION, "", ButtonType.YES, ButtonType.NO);
					alert1.setTitle("Delete Confirmation");
					alert1.setHeaderText("Do you really want to delete?");
					loggerConfigureForm.info("Delete Confirmation: Do you really want to delete?");
					alert1.initOwner(primaryStage);

					Optional<ButtonType> result = alert1.showAndWait();
					if (result.get() == ButtonType.YES) {
						try {
							PropertiesConfiguration configFile = new PropertiesConfiguration(
									"configureDetails.properties");

							String dbApplication = appComboBox.getSelectionModel().getSelectedItem().toString();
							String dbRegionName = regionComboBox.getSelectionModel().getSelectedItem().toString();
							String dbAppName = dbServerTextField.getText().toString();
							String dbHostName = comboBoxHost.getSelectionModel().getSelectedItem().toString();
							String dbUserName = dbUserTextField.getText().toString();
							String dbPassword = dbPasswordTextField.getText().toString();
							String dbPortNo = comboBoxPortNo.getSelectionModel().getSelectedItem().toString();
							String dbName = comboBoxDBName.getSelectionModel().getSelectedItem().toString();
							String dbSqlServerName=comboBoxServerName.getSelectionModel().getSelectedItem().toString();

							String dbApplicationKey = dbAppName + dbType + "Application";
							String dbRegionKey = dbAppName + dbType + "Region";
							String dbAppNameKey = dbAppName + dbType + "AppName";
							String dbHostNameKey = dbAppName + dbType + "HostName";
							String dbUserNameKey = dbAppName + dbType + "UserName";
							String dbPasswordKey = dbAppName + dbType + "Password";
							String dbPortNoKey = dbAppName + dbType + "PortNo";
							String dbNameKey = dbAppName + dbType + "DBName";
							String dbServerkey=dbAppName+dbType+"ServerName";
							
							
							Iterator<String> keys = configFile.getKeys();
							ArrayList<String> keyList = new ArrayList<String>();
							while (keys.hasNext()) {
								keyList.add(keys.next());
							}
							
							for (String key : keyList) {
								
								if (key.contains(dbApplicationKey))
									configFile.clearProperty(key);
								else if(key.contains(dbRegionKey))
									configFile.clearProperty(key);
								else if (key.equals(dbAppNameKey))
									configFile.clearProperty(key);
								else if (key.equals(dbHostNameKey))
									configFile.clearProperty(key);
								else if (key.equals(dbUserNameKey))
									configFile.clearProperty(key);
								else if (key.equals(dbPasswordKey))
									configFile.clearProperty(key);
								else if (key.equals(dbPortNoKey))
									configFile.clearProperty(key);
								else if (key.equals(dbNameKey))
									configFile.clearProperty(key);
								else if (key.equals(dbRegionKey))
									configFile.clearProperty(key);
								else if (key.equals(dbServerkey))
									configFile.clearProperty(key);
								
							}
						
							configFile.save();

							System.out.println("Deleted Database Application Name: " + dbApplication);
							System.out.println("Deleted Database Region Name: " + dbRegionName);
							System.out.println("Deleted Database Environment Name: " + dbAppNameKey);
							System.out.println("Deleted Database Host Name: " + dbHostNameKey);
							System.out.println("Deleted Database User Name: " + dbUserNameKey);
							System.out.println("Deleted Database Password: " + dbPasswordKey);
							System.out.println("Deleted Database Port No: " + dbPortNoKey);
							System.out.println("Deleted Database Name: " + dbNameKey);
							System.out.println("Deleted Server Name: " + dbServerkey);

							clearAll(dbServerTextField, dbUserTextField, dbPasswordTextField, comboBoxHost,
									comboBoxDBName, comboBoxPortNo, appComboBox, regionComboBox, dbTypecomboBox,
									existingServerComboBox,comboBoxServerName);

							Alert alert11 = new Alert(AlertType.INFORMATION);
							alert11.setTitle("Delete Confirmation");
							alert11.setHeaderText("Database Configuration is Deleted Successfully!");
							loggerConfigureForm.info("Delete Confirmation: Database Configuration is Deleted Successfully!");
							((Stage) alert11.getDialogPane().getScene().getWindow()).getIcons()
									.add(new Image("file:Logo.png"));
							alert11.initOwner(primaryStage);
							alert11.showAndWait();
						} catch (Exception e1) {
							loggerConfigureForm.error("ConfigurationException in configureDetails.properties", e1);
							e1.printStackTrace();
						}
					}
				}
			}
		});

//		addApp.setOnAction(new EventHandler<ActionEvent>() {
//			public void handle(ActionEvent e) {
//				TextInputDialog dialog = new TextInputDialog();
//				dialog.setTitle("Add New Application");
//				dialog.setHeaderText("Enter application name you want to add: ");
//				dialog.getDialogPane().setContentText(null);
//				dialog.initOwner(primaryStage);
//				ButtonType okButton = new ButtonType("OK", ButtonData.OK_DONE);
//				dialog.getDialogPane().getButtonTypes().setAll(okButton);
//				Optional<String> result = dialog.showAndWait();
//				if (result.isPresent()) {
//					System.out.println(result.get());
//					try {
//						PropertiesConfiguration configFile = new PropertiesConfiguration("appDetails.properties");
//						String key = "appName" + result.get() + "Key";
//						configFile.setProperty(key, result.get());
//						configFile.save();
//					} catch (ConfigurationException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				else {
//					Alert alert1 = new Alert(AlertType.ERROR, "Field is empty", ButtonType.OK);
//					alert1.initOwner(primaryStage);
//					alert1.show();
//				}
//			}
//		});
//
//		addDBName.setOnAction(new EventHandler<ActionEvent>() {
//			public void handle(ActionEvent e) {
//				TextInputDialog dialog = new TextInputDialog();
//				dialog.setTitle("Add New Database Name");
//				dialog.setHeaderText("Enter database name you want to add: ");
//				dialog.getDialogPane().setContentText(null);
//				dialog.initOwner(primaryStage);
//				ButtonType okButton = new ButtonType("OK", ButtonData.OK_DONE);
//				dialog.getDialogPane().getButtonTypes().setAll(okButton);
//				Optional<String> result = dialog.showAndWait();
//				if (result.isPresent()) {
//					System.out.println(result.get());
//					try {
//						PropertiesConfiguration configFile = new PropertiesConfiguration("dbNameDetails.properties");
//						String key = "dbName" + result.get() + "Key";
//						configFile.setProperty(key, result.get());
//						configFile.save();
//					} catch (ConfigurationException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				else {
//					Alert alert1 = new Alert(AlertType.ERROR, "Field is empty", ButtonType.OK);
//					alert1.initOwner(primaryStage);
//					alert1.show();
//				}
//			}
//		});
//
//		addDBType.setOnAction(new EventHandler<ActionEvent>() {
//			public void handle(ActionEvent e) {
//				TextInputDialog dialog = new TextInputDialog();
//				dialog.setTitle("Add New Application");
//				dialog.setHeaderText("Enter application name you want to add: ");
//				dialog.getDialogPane().setContentText(null);
//				dialog.initOwner(primaryStage);
//				Optional<String> result = dialog.showAndWait();
//				if (result.isPresent()) {
//					System.out.println(result.get());
//					try {
//						PropertiesConfiguration configFile = new PropertiesConfiguration("appDetails.properties");
//						String key = result.get() + "Key";
//						configFile.setProperty(key, result.get());
//						configFile.save();
//					} catch (ConfigurationException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//
//				}
//			}
//		});
//
//		addHostName.setOnAction(new EventHandler<ActionEvent>() {
//			public void handle(ActionEvent e) {
//				TextInputDialog dialog = new TextInputDialog();
//				dialog.setTitle("Add New Host");
//				dialog.setHeaderText("Enter host name you want to add: ");
//				dialog.getDialogPane().setContentText(null);
//				dialog.initOwner(primaryStage);
//				ButtonType okButton = new ButtonType("OK", ButtonData.OK_DONE);
//				dialog.getDialogPane().getButtonTypes().setAll(okButton);
//				Optional<String> result = dialog.showAndWait();
//				if (result.isPresent()) {
//					System.out.println(result.get());
//					try {
//						PropertiesConfiguration configFile = new PropertiesConfiguration("hostDetails.properties");
//						String key = "host" + result.get() + "Key";
//						configFile.setProperty(key, result.get());
//						configFile.save();
//					} catch (ConfigurationException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				else {
//					Alert alert1 = new Alert(AlertType.ERROR, "Field is empty", ButtonType.OK);
//					alert1.initOwner(primaryStage);
//					alert1.show();
//				}
//			}
//		});
//
//		addPortNo.setOnAction(new EventHandler<ActionEvent>() {
//			public void handle(ActionEvent e) {
//				TextInputDialog dialog = new TextInputDialog();
//				dialog.setTitle("Add New Port Number");
//				dialog.setHeaderText("Enter port number you want to add: ");
//				dialog.getDialogPane().setContentText(null);
//				dialog.initOwner(primaryStage);
//				ButtonType okButton = new ButtonType("OK", ButtonData.OK_DONE);
//				dialog.getDialogPane().getButtonTypes().setAll(okButton);
//				Optional<String> result = dialog.showAndWait();
//				if (result.isPresent() && !result.get().isEmpty()) {
//					System.out.println(result.get());
//					try {
//						PropertiesConfiguration configFile = new PropertiesConfiguration("portDetails.properties");
//						String key = "portNo" + result.get() + "Key";
//						configFile.setProperty(key, result.get());
//						configFile.save();
//					} catch (ConfigurationException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				else {
//					Alert alert1 = new Alert(AlertType.ERROR, "Field is empty", ButtonType.OK);
//					alert1.initOwner(primaryStage);
//					alert1.show();
//				}
//			}
//		});
//
//		addregion.setOnAction(new EventHandler<ActionEvent>() {
//			public void handle(ActionEvent e) {
//				TextInputDialog dialog = new TextInputDialog();
//				dialog.setTitle("Add New Region");
//				dialog.setHeaderText("Enter region name you want to add: ");
//				dialog.getDialogPane().setContentText(null);
//				dialog.initOwner(primaryStage);
//				ButtonType okButton = new ButtonType("OK", ButtonData.OK_DONE);
//				dialog.getDialogPane().getButtonTypes().setAll(okButton);
//				Optional<String> result = dialog.showAndWait();
//				if (result.isPresent()) {
//					System.out.println(result.get());
//					try {
//						PropertiesConfiguration configFile = new PropertiesConfiguration("regionDetails.properties");
//						String key = "region" + result.get() + "Key";
//						configFile.setProperty(key, result.get());
//						configFile.save();
//					} catch (ConfigurationException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//				else {
//					Alert alert1 = new Alert(AlertType.ERROR, "Field is empty", ButtonType.OK);
//					alert1.initOwner(primaryStage);
//					alert1.show();
//				}
//			}
//		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				// consume event
				event.consume();

				// show close dialog
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerConfigureForm.info("ConfigureForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 950, 400);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
	}

	@SuppressWarnings("rawtypes")
	private static void clearAll(TextField dbServerTextField, TextField dbUserTextField, TextField dbPasswordTextField,
			ComboBox comboBoxHost, ComboBox comboBoxDBName, ComboBox comboBoxPortNo, ComboBox appComboBox,
			ComboBox regionComboBox, ComboBox dbTypecomboBox, ComboBox existingServerComboBox, ComboBox comboBoxServerName) {
		dbServerTextField.clear();
		dbUserTextField.clear();
		dbPasswordTextField.clear();
		comboBoxHost.getSelectionModel().clearSelection();
		comboBoxDBName.getSelectionModel().clearSelection();
		comboBoxPortNo.getSelectionModel().clearSelection();
		appComboBox.getSelectionModel().clearSelection();
		regionComboBox.getSelectionModel().clearSelection();
		dbTypecomboBox.getSelectionModel().clearSelection();
		existingServerComboBox.getSelectionModel().clearSelection();
		comboBoxServerName.getSelectionModel().clearSelection();
		dbServerTextField.clear();
		dbUserTextField.clear();
		dbPasswordTextField.clear();
	}
}
