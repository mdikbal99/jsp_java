package javaFrame;

import dataBaseConnection.ConnectToMySqlServer;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class MySqlServerTableColumnForm {
	Stage  primaryStage2;
    public void open() {
    	primaryStage2=new Stage();
		primaryStage2.setTitle("DVMap - Hive Table Column Form");
		primaryStage2.getIcons().add(new Image("file:Logo.png"));
    	
    	TextArea textArea = new TextArea();
    	int i = 1;
    	for(String str : ConnectToMySqlServer.mySqlServerColumnNameList) {
    		textArea.appendText(i + ". " + str + "\n");
    		i++;
    	}
    	StackPane root = new StackPane(textArea);
    	Scene scene = new Scene(root, 400, 600);       
    	primaryStage2.setScene(scene);
    	primaryStage2.show();
    }

}
