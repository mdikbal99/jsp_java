package javaFrame;

import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import application.Main;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import util.StringDecrpt;
import util.StringEncrpt;

public class LoginForm extends Application {
	public static Logger loggerLoginForm = LogManager.getLogger(LoginForm.class);
	
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("DVMap - Login Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerLoginForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);

		Text scenetitle = new Text(" Sign in");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 2, 0, 2, 1);

		Label userName = new Label("User Name:");
		grid.add(userName, 1, 1);

		TextField userTextField = new TextField();
		grid.add(userTextField, 2, 1);

		Label pw = new Label("Password:");
		grid.add(pw, 1, 2);

		PasswordField pwBox = new PasswordField();
		grid.add(pwBox, 2, 2);

		Button btn = new Button("Sign in");
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(btn);
		grid.add(hbBtn, 2, 4);

//		final Text actiontarget = new Text();
//		grid.add(actiontarget, 1, 6);

		btn.setOnAction(new EventHandler<ActionEvent>() {

			@SuppressWarnings("unchecked")
			@Override
			public void handle(ActionEvent e) {

				String adminID = null;
				String adminPassword = null;
				String adminIDKey = null;
				String adminPasswordKey = null;
				String adminMACAddressKey = null;
				String userIDKey = null;
				String userPasswordKey = null;
				String userMACAddressKey = null;
				String macAddressFromMachine = null;
				String macAddressFromProperty = null;
				String macAddressFromPropertyEncrypted = null;
				
				boolean idField = false;
				boolean pwField = false;
				
				Alert alert = new Alert(AlertType.ERROR);
				if(userTextField.getText() == null || userTextField.getText().trim().isEmpty()) {
					idField = true;
				}
				if (pwBox.getText() == null || pwBox.getText().trim().isEmpty()) {
					pwField = true;
				}
    	    	if (idField && pwField) {
        	    	alert.setTitle("Run Time Error");
        	    	alert.setHeaderText("User ID and Password are missing!");
        	    	loggerLoginForm.info("Run Time Error: User ID and Password are missing!");
        	    	alert.setContentText("");
        	    	((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
        	    	alert.showAndWait();
    	    	}
    	    	else if (idField || pwField) {
    	    		if (idField) {
            	    	alert.setTitle("Run Time Error");
            	    	alert.setHeaderText("User ID is missing!");
            	    	loggerLoginForm.info("Run Time Error: User ID is missing!");
            	    	alert.setContentText("");
            	    	((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
            	    	alert.showAndWait();
    	    		}
    	    		else {
            	    	alert.setTitle("Run Time Error");
            	    	alert.setHeaderText("Password is missing!");
            	    	loggerLoginForm.info("Run Time Error: Password is missing!");
            	    	alert.setContentText("");
            	    	((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
            	    	alert.showAndWait();
    	    		}
    	    	}
    	    	else{
//					try {
						
						String IDText = userTextField.getText();
						String passwordText = pwBox.getText();
						
						PropertiesConfiguration configFile = null;
						try {
							configFile = new PropertiesConfiguration("loginDetails.properties");
						} catch (ConfigurationException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
	
						InetAddress ip = null;
						try {
							try {
								ip = InetAddress.getLocalHost();
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								loggerLoginForm.error("UnknownHostException: Error to get IP Address of this Machine", e1);
								e1.printStackTrace();
							}
							NetworkInterface network = NetworkInterface.getByInetAddress(ip);
							byte[] mac = network.getHardwareAddress();
							StringBuilder sb = new StringBuilder();
							for (int i = 0; i < mac.length; i++) {
								sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
							}
							macAddressFromMachine = sb.toString();
							loggerLoginForm.info("MAC Address of this Machine is: " + macAddressFromMachine);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							loggerLoginForm.error("SocketException: Error to get Hardware Address of this Machine", e1);
							e1.printStackTrace();
						}
						
						System.out.println("Entered User ID: " + IDText);
						System.out.println("Entered Password: " + passwordText);
						System.out.println("MAC Address of this Machine: " + macAddressFromMachine);
						
						adminID = "root";//(String) configFile.getProperty("AdministratorID");
						adminPassword = "root";//(String) configFile.getProperty("AdministratorPassword");
						macAddressFromProperty = Main.macAddressFromMachine;//"6C-4B-90-09-B5-C0";
						macAddressFromPropertyEncrypted = StringEncrpt.encrypt(macAddressFromProperty+","+adminID+","+adminPassword+","+"root");
						
						try {
							configFile.setProperty("administratorKey", macAddressFromPropertyEncrypted);
							configFile.save();
						} catch (ConfigurationException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
//						System.out.println("AdministratorID: " + StringDecrpt.decrypt((String) configFile.getProperty("administratorKey")).split(",")[1]);
//						System.out.println("AdministratorPassword: " + StringDecrpt.decrypt((String) configFile.getProperty("administratorKey")).split(",")[2]);
//						System.out.println("AdministratorMACAddress: " + StringDecrpt.decrypt((String) configFile.getProperty("administratorKey")).split(",")[0]);
//						System.out.println("AdministratorMACAddressEncrypted: " + macAddressFromPropertyEncrypted);
						
						if (IDText.equals(adminID)) {
							
							loggerLoginForm.info("You Entered Administrator Credentials!");
							
							Main.isAdministrator = true;
							
							if (IDText.equals(adminID) && passwordText.equals(adminPassword)
									&& macAddressFromMachine.equalsIgnoreCase(macAddressFromProperty)) {
								optionForm page = new optionForm();
								page.start(primaryStage);
								loggerLoginForm.info("Administrator, You have successful login!");
								System.out.println("Administrator, You have successful login!");
								
							} else {
//								if(!macAddressFromMachine.equalsIgnoreCase(macAddressFromProperty)){
//									System.out.println("You are not an authorised user with this machine\n or this machin is not configured");
//									Alert alert1 = new Alert(AlertType.ERROR);
//									alert1.setTitle("Run Time Error");
//									alert1.setHeaderText("You are not an authorised user with this machine\n or this machin is not configured with DVMap");
//									((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
//											.add(new Image("file:Logo.png"));
//									alert1.showAndWait();
//								}else{
								Alert alert1 = new Alert(AlertType.ERROR);
								alert1.setTitle("Run Time Error");
								alert1.setHeaderText("Incorrect Administrator ID or Password");
								((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
										.add(new Image("file:Logo.png"));
								alert1.showAndWait();
								loggerLoginForm.info("Please, Enter the valid AdministratorID and AdministratorPassword!");
								System.out.println("Please, Enter the valid AdministratorID and AdministratorPassword!");
//								}
							}
						} else {
							
							Main.isAdministrator = false;
	
							Iterator<String> keys = configFile.getKeys();
							ArrayList<String> keyList = new ArrayList<String>();
							while (keys.hasNext()) {
								keyList.add(keys.next());
							}
		
							for (String key : keyList) {
								if (key.equals(IDText + "AdminID")) {
									adminIDKey = IDText + "AdminID";
									adminPasswordKey = IDText + "AdminPassword";
									adminMACAddressKey = IDText + "AdminMACAddress";
									Main.isAdmin = true;
								}
								if (key.equals(IDText + "UserID")) {
									userIDKey = IDText + "UserID";
									userPasswordKey = IDText + "UserPassword";
									userMACAddressKey = IDText + "UserMACAddress";
									Main.isAdmin = false;
								}
							}
							
							if (Main.isAdmin) {
								loggerLoginForm.info("You Entered Admin Credentials!");
								if (IDText.equals(configFile.getProperty(adminIDKey)) 
										&& passwordText.equals(configFile.getProperty(adminPasswordKey)) 
										&& macAddressFromMachine.equalsIgnoreCase(StringDecrpt.decrypt((String) configFile.getProperty(adminMACAddressKey)).split(",")[0])) {
									optionForm page = new optionForm();
									page.start(primaryStage);
									loggerLoginForm.info("Admin, You have successful login!");
									System.out.println("Admin, You have successful login!");
								} else {
//									if(!macAddressFromMachine.equalsIgnoreCase(StringDecrpt.decrypt((String) configFile.getProperty(adminMACAddressKey)).split(",")[0])){
//										System.out.println("You are not an authorised user with this machine\n or this machin is not configured");
//										Alert alert1 = new Alert(AlertType.ERROR);
//										alert1.setTitle("Run Time Error");
//										alert1.setHeaderText("You are not an authorised user with this machine\n or this machin is not configured with DVMap");
//										((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
//												.add(new Image("file:Logo.png"));
//										alert1.showAndWait();
//									} else {
									Alert alert1 = new Alert(AlertType.ERROR);
									alert1.setTitle("Run Time Error");
									alert1.setHeaderText("Incorrect User ID or Password");
									((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
											.add(new Image("file:Logo.png"));
									alert1.showAndWait();
									loggerLoginForm.info("Please, Enter the valid adminID and adminPassword!");
									System.out.println("Please, Enter the valid adminID and adminPassword!");
//									}
								}
							} else {
								loggerLoginForm.info("You Entered User Credentials!");
								if (IDText.equals(configFile.getProperty(userIDKey)) 
										&& passwordText.equals(configFile.getProperty(userPasswordKey)) 
										&& macAddressFromMachine.equalsIgnoreCase(StringDecrpt.decrypt((String) configFile.getProperty(userMACAddressKey)).split(",")[0])) {
									optionForm page = new optionForm();
									page.start(primaryStage);
									loggerLoginForm.info("User, You have successful login!");
									System.out.println("User, You have successful login!");
								} else {
//									if(!macAddressFromMachine.equalsIgnoreCase(StringDecrpt.decrypt((String) configFile.getProperty(userMACAddressKey)).split(",")[0])){
//										System.out.println("You are not an authorised user with this machine\n or this machin is not configured");
//										Alert alert1 = new Alert(AlertType.ERROR);
//										alert1.setTitle("Run Time Error");
//										alert1.setHeaderText("You are not an authorised user with this machine\n or this machin is not configured with DVMap");
//										((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
//												.add(new Image("file:Logo.png"));
//										alert1.showAndWait();
//									}else{
									Alert alert1 = new Alert(AlertType.ERROR);
									alert1.setTitle("Run Time Error");
									alert1.setHeaderText("Incorrect User ID or Password");
									((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
											.add(new Image("file:Logo.png"));
									alert1.showAndWait();
									loggerLoginForm.info("Please, Enter the valid userID and userPassword!");
									System.out.println("Please, Enter the valid userID and userPassword!");
//									}
								}
							}
						}
	
//					} catch (Exception e1) {
//						loggerLoginForm.error("ConfigurationException in loginDetails.properties", e1);
//						Alert alert1 = new Alert(AlertType.ERROR);
//						alert1.setTitle("Login Validation Error");
//						alert1.setHeaderText("You are not an authorised user with this machine\n or this machin is not configured with DVMap");
//						((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
//								.add(new Image("file:Logo.png"));
//						alert1.showAndWait();
//						//e1.printStackTrace();
//					}
    	    	}
			}
		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				event.consume();
				// show close dialog
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerLoginForm.info("LoginForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 400, 300);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
	}
}
