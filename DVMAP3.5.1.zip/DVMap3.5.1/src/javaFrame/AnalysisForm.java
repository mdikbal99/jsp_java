package javaFrame;

import java.io.File;
import java.io.FileInputStream;
import java.util.Optional;
import analysis.AnalyzeOfFiles;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class AnalysisForm extends Application {
	
	public static Logger loggerAnalysisForm = LogManager.getLogger(AnalysisForm.class);
	
	public static String folderPath = null;

	@Override
	public void start(Stage primaryStage) {
		final DirectoryChooser dc = new DirectoryChooser();

		primaryStage.setTitle("DVMap - Analysis Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerAnalysisForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);

		Text scenetitle = new Text(" Result Analysis");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 1, 0, 2, 1);

		Label file1 = new Label("Folder Path:");
		file1.setMinWidth(100);
		grid.add(file1, 0, 1);

		TextField file1TextField = new TextField();
		file1TextField.setDisable(true);
		file1TextField.setMinWidth(300);
		file1TextField.setPromptText("(*) mandatory field");
		grid.add(file1TextField, 1, 1);

		Button getFolder = new Button("Select Folder");
		HBox hbBtn = new HBox(10);
		getFolder.setMinWidth(100);
		hbBtn.setAlignment(Pos.BOTTOM_LEFT);
		hbBtn.getChildren().add(getFolder);
		grid.add(hbBtn, 2, 1);

		Button backBtn = new Button("Back to Select Option");
		HBox hbBackBtn = new HBox(10);
		backBtn.setMinWidth(150);
		backBtn.setMinHeight(35);
		backBtn.setTextFill(Color.DARKBLUE);
		backBtn.setTextAlignment(TextAlignment.CENTER);
		backBtn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbBackBtn.setAlignment(Pos.BOTTOM_LEFT);
		hbBackBtn.getChildren().add(backBtn);
		grid.add(hbBackBtn, 0, 3);

		Button clearBtn = new Button("Clear");
		HBox hbClearBtn = new HBox(10);
		clearBtn.setMinWidth(150);
		clearBtn.setMinHeight(35);
		clearBtn.setTextFill(Color.DARKBLUE);
		clearBtn.setTextAlignment(TextAlignment.CENTER);
		clearBtn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbClearBtn.setAlignment(Pos.BOTTOM_CENTER);
		hbClearBtn.getChildren().add(clearBtn);
		grid.add(hbClearBtn, 1, 3);

		Button analyzeBtn = new Button("Analyze");
		HBox hbAnalyzeBtn = new HBox(10);
		analyzeBtn.setMinWidth(150);
		analyzeBtn.setMinHeight(35);
		analyzeBtn.setTextFill(Color.DARKBLUE);
		analyzeBtn.setTextAlignment(TextAlignment.CENTER);
		analyzeBtn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		hbAnalyzeBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbAnalyzeBtn.getChildren().add(analyzeBtn);
		grid.add(hbAnalyzeBtn, 2, 3);

		getFolder.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				configureFolderChooser(dc);
				File folder = dc.showDialog(primaryStage);
				folderPath = folder.toString();
				System.out.println("Folder Path: " + folderPath);
				file1TextField.setText(folderPath);
			}
		});

		backBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are back in Main Menu!");
				optionForm oppage = new optionForm();
				oppage.start(primaryStage);
			}
		});

		clearBtn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				file1TextField.clear();
			}
		});

		analyzeBtn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				Alert alert = new Alert(AlertType.ERROR);
				if (file1TextField.getText() == null || file1TextField.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerAnalysisForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {

					Alert alert1 = new Alert(AlertType.INFORMATION);

					alert1.setTitle("Analyzing");

					Image image = null;
					try {
						image = new Image(new FileInputStream("8yxqez.gif"));
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						loggerAnalysisForm.error("FileNotFoundException: 8yxqez.gif is NOT FOUND!", e2);
						e2.printStackTrace();
					}
					ImageView imageView = new ImageView(image);
					imageView.setFitHeight(100);
					imageView.setFitWidth(100);
					alert1.setGraphic(imageView);

					alert1.setHeaderText("Analyzing Files!");
					alert1.setContentText("Analyzing in process");
					loggerAnalysisForm.info("Analyzing Files: Analyzing in process");
					((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert1.show();
					Task<Void> task = new Task<Void>() {
						@Override
						protected Void call() {
							AnalyzeOfFiles.analyzeFile(folderPath);
							return null;
						}
					};
					task.setOnSucceeded(eTask -> {
						alert1.close();
						Alert alert2 = new Alert(AlertType.INFORMATION);
						alert2.setTitle("Analysis Result");
						alert2.setHeaderText("Analysis Successfully Completed!");
						loggerAnalysisForm.info("Analysis Result: Analysis Successfully Completed!");
						((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons()
								.add(new Image("file:Logo.png"));
						alert2.setContentText("Please, Check "+ folderPath +" Folder for Result");
						alert2.showAndWait();
					});

					new Thread(task).start();
				}
			}
		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				// consume event
				event.consume();

				// show close dialog
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerAnalysisForm.info("AnalysisForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 700, 250);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
	}

	private static void configureFolderChooser(final DirectoryChooser dc) {
		dc.setTitle("Folder Chooser");
		dc.setInitialDirectory(new File(System.getProperty("user.home")));
	}
}
