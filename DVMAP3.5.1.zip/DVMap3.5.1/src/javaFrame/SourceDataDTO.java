package javaFrame;

import javafx.beans.property.SimpleStringProperty;

public class SourceDataDTO {
	private final SimpleStringProperty entity_field_name;
	private final SimpleStringProperty position1;
	private final SimpleStringProperty position2;
	private final SimpleStringProperty primary_key;
	private final SimpleStringProperty tlogic;
	private final SimpleStringProperty file_type;

	public SourceDataDTO(String entity_field_name, String position1, String position2, String primary_key, String tlogic,
			String file_type) {
		this.entity_field_name = new SimpleStringProperty(entity_field_name);
		this.position1 = new SimpleStringProperty(position1);
		this.position2 = new SimpleStringProperty(position2);
		this.primary_key = new SimpleStringProperty(primary_key);
		this.tlogic = new SimpleStringProperty(tlogic);
		this.file_type = new SimpleStringProperty(file_type);
	}

	public String getEntity_field_name() {
		return entity_field_name.get();
	}

	public void setEntity_field_name(String efs) {
		entity_field_name.set(efs);
	}

	public String getPosition1() {
		return position1.get();
	}

	public void setPosition1(String p1) {
		position1.set(p1);
	}

	public String getPosition2() {
		return position2.get();
	}

	public void setPosition2(String p2) {
		position2.set(p2);
	}

	public String getPrimary_key() {
		return primary_key.get();
	}

	public void setPrimary_key(String pk) {
		primary_key.set(pk);
	}

	public String getTlogic() {
		return tlogic.get();
	}

	public void setTlogic(String tl) {
		tlogic.set(tl);
	}

	public String getFile_type() {
		return file_type.get();
	}

	public void setFile_type(String ft) {
		file_type.set(ft);
	}

	@Override
	public String toString() {
		//return "SourceDataDTO [entity_field_name=" + entity_field_name + ", position1=" + position1 + ", position2="+ position2 + ", primary_key=" + primary_key + ", tlogic=" + tlogic + ", file_type=" + file_type + "]";
		
		return entity_field_name+","+position1+","+position2+","+primary_key+","+tlogic+","+file_type;
	}

}