package javaFrame;

import java.io.FileInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Optional;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.joda.time.DateTimeComparator;
import application.Main;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import util.StringDecrpt;

public class WelcomeForm extends Application {

	public static Logger loggerWelcomeForm = LogManager.getLogger(WelcomeForm.class);
	String macFromMachine = Main.macAddressFromMachine;
	
	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage primaryStage) throws ParseException {
		primaryStage.setTitle("DVMap - Login Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		//grid.setStyle("-fx-background-color: #99f6f9;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			loggerWelcomeForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);

		Text scenetitle = new Text(" Welcome to DVMap Tool");
		scenetitle.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 50));
		scenetitle.setFill(Color.BROWN);
		scenetitle.setStrokeWidth(2);
		scenetitle.setStroke(Color.BLUE);
		grid.add(scenetitle, 2, 0, 2, 1);

		try {
			image = new Image(new FileInputStream("170x36px_cognizant_logo.png"));
		} catch (Exception e2) {
			loggerWelcomeForm.error("FileNotFoundException: 170x36px_cognizant_logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel2 = new Label();
		ImageView imageView2 = new ImageView(image);
		imageView2.autosize();
		imgLabel2.setGraphic(imageView2);
		grid.add(imgLabel2, 5, 10);

		Text designCompanyBy = new Text("		Cognizant Technology Solutions Pvt. Ltd.");
		designCompanyBy.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		designCompanyBy.setTextAlignment(TextAlignment.CENTER);
		grid.add(designCompanyBy, 3, 4);

//		Text designDeptBy = new Text("			  MetQA Panorama Team");
//		designDeptBy.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
//		designDeptBy.setTextAlignment(TextAlignment.CENTER);
//		grid.add(designDeptBy, 3, 5);
		
		Label licenseLabel = new Label();
		Label activationKey = new Label("Enter Activation Key:");
		TextField activationKeyTextField = new TextField();
		
		Button btn = new Button("Activate");
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn.getChildren().add(btn);
		
		PropertiesConfiguration configFile = null;
		try {
			configFile = new PropertiesConfiguration("loginDetails.properties");
		} catch (ConfigurationException e2) {
			e2.printStackTrace();
		}
		
		Iterator<String> keys = configFile.getKeys();
		ArrayList<String> keyList = new ArrayList<String>();
		
		while (keys.hasNext()) {
			keyList.add(keys.next());
		}
		
		String macFromProperty = null;
		DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();

		for (String key : keyList) {
			if (key.equals("AdministratorMACAddress") || key.contains("AdminMACAddress") || key.contains("UserMACAddress")) {
				macFromProperty = StringDecrpt.decrypt((String) configFile.getProperty(key)).split(",")[0];
				if (macFromMachine.equalsIgnoreCase(macFromProperty)) {
					Main.isKeyPresent = true;
				} 				
			}
		}
		
		String expirationDatestr = null;
		int retVal = 0;
		Date expirationDate = null;
		for (String key : keyList) {
			if (key.equals("AdministratorMACAddress") || key.contains("AdminMACAddress") || key.contains("UserMACAddress")) {
				expirationDatestr = StringDecrpt.decrypt((String) configFile.getProperty(key)).split(",")[4];
				expirationDate = new SimpleDateFormat("yyyy-MM-dd").parse(expirationDatestr); 
				Date myDateOne = java.sql.Date.valueOf(Main.nowDate);
				retVal = dateTimeComparator.compare(myDateOne, expirationDate);
				System.out.println(retVal);
				if (retVal == 0 || retVal < 0) {
					Main.isActivated = true;
				} 
			}
		}
		
		System.out.println("Main.isKeyPresent = " + Main.isKeyPresent);
		System.out.println("Main.isActivated = " + Main.isActivated);
		
		if (Main.isKeyPresent && Main.isActivated) {
			PauseTransition delay = new PauseTransition(Duration.seconds(4));
			delay.setOnFinished(event -> {
				primaryStage.close();
				LoginForm lf = new LoginForm();
				lf.start(primaryStage);
			});
			delay.play();
		} else if (Main.isKeyPresent && !Main.isActivated) {
			licenseLabel.setText("License is Expired!");
			System.out.println("License is Expired!");
			grid.add(activationKey, 2, 6);
			grid.add(activationKeyTextField, 3, 6);
			grid.add(hbBtn, 4, 6);
			grid.add(licenseLabel, 3, 7);
		} else if (!Main.isKeyPresent) {
			System.out.println("Not Present");
			licenseLabel.setText("License is Not Present!");
			System.out.println("License is Not Present!");
			grid.add(activationKey, 2, 6);
			grid.add(activationKeyTextField, 3, 6);
			grid.add(hbBtn, 4, 6);
			grid.add(licenseLabel, 3, 7);
		}
		
		btn.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				Alert alert = new Alert(AlertType.ERROR);
    	    	if(activationKeyTextField.getText() == null || activationKeyTextField.getText().trim().isEmpty()) {
        	    	alert.setTitle("Run Time Error");
        	    	alert.setHeaderText("Field values are missing!");
        	    	loggerWelcomeForm.info("Run Time Error: Field values are missing!");
        	    	alert.setContentText("");
        	    	((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
        	    	alert.showAndWait();
    	    	}
    	    	else{
    	    		String macAddress = StringDecrpt.decrypt((String) activationKeyTextField.getText()).split(",")[0];
    	    		String id = StringDecrpt.decrypt((String) activationKeyTextField.getText()).split(",")[1];
    	    		String password = StringDecrpt.decrypt((String) activationKeyTextField.getText()).split(",")[2];
    	    		String userType = StringDecrpt.decrypt((String) activationKeyTextField.getText()).split(",")[3];
    	    		String expirationDatestr = StringDecrpt.decrypt((String) activationKeyTextField.getText()).split(",")[4];
    	    		String macEncryptedAddress = activationKeyTextField.getText();
    	    		System.out.println(macAddress);
    	    		System.out.println(id);
    	    		System.out.println(password);
    	    		System.out.println(userType);
    	    		System.out.println(expirationDatestr);
    	    		System.out.println(macEncryptedAddress);

    				Date expirationDate = null;
					try {
						expirationDate = new SimpleDateFormat("yyyy-MM-dd").parse(expirationDatestr);
					} catch (ParseException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} 
    				Date myDateOne = java.sql.Date.valueOf(Main.nowDate);
    				int retVal = dateTimeComparator.compare(myDateOne, expirationDate);
    				System.out.println(retVal);
    				
    	    		System.out.println("Compare Completed!");
    	    		if (macFromMachine.equalsIgnoreCase(macAddress)) {
    	    			if (retVal == 0 || retVal < 0) {
    	    				if (userType.equalsIgnoreCase("admin")) {
        						try {
        							PropertiesConfiguration configFile = new PropertiesConfiguration("loginDetails.properties");
        							configFile.setProperty(id + "AdminID", id);
        							configFile.setProperty(id + "AdminPassword", password);
        							configFile.setProperty(id + "AdminMACAddress", macEncryptedAddress);
        							configFile.save();
        							LoginForm lf = new LoginForm();
        							lf.start(primaryStage);
        						} catch (Exception e1) {
        							loggerWelcomeForm.error("ConfigurationException in loginDetails.properties", e1);
        							e1.printStackTrace();
        						}
        					} else {
        						try {
        							PropertiesConfiguration configFile = new PropertiesConfiguration("loginDetails.properties");
        							configFile.setProperty(id + "UserID", id);
        							configFile.setProperty(id + "UserPassword", password);
        							configFile.setProperty(id + "UserMACAddress", macEncryptedAddress);
        							configFile.save();
        							LoginForm lf = new LoginForm();
        							lf.start(primaryStage);
        						} catch (Exception e1) {
        							loggerWelcomeForm.error("ConfigurationException in loginDetails.properties", e1);
        							e1.printStackTrace();
        						}
        					}
    	    				System.out.println("DVMap Tool is Successfully Activated! Expiration Date: " + expirationDatestr);
    	    				Alert alert2 = new Alert(AlertType.INFORMATION);
    	    				alert2.setTitle("Activation");
                	    	alert2.setHeaderText("Activation Status");
                	    	loggerWelcomeForm.info("Activation Status: DVMap Tool is Successfully Activated! Expiration Date: " + expirationDatestr);
                	    	alert2.setContentText("DVMap Tool is Successfully Activated! \nExpiration Date: " + expirationDatestr);
                	    	((Stage)alert2.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
                	    	alert2.showAndWait();
    	    			} else {
    	    				System.out.println("You Enterd Expired Activation Key!");
    	    				alert.setTitle("Activation");
                	    	alert.setHeaderText("Activation Status");
                	    	loggerWelcomeForm.info("Run Time Error: You Enterd Expired Activation Key!");
                	    	alert.setContentText("You Enterd Expired Activation Key!");
                	    	((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
                	    	alert.showAndWait();
    	    			}
    	    			
    	    		} else {
    	    			System.out.println("You Enterd Wrong Activation Key!");
    	    			alert.setTitle("Activation");
            	    	alert.setHeaderText("Activation Status");
            	    	loggerWelcomeForm.info("Run Time Error: You Enterd Wrong Activation Key!");
            	    	alert.setContentText("You Enterd Wrong Activation Key!");
            	    	((Stage)alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
            	    	alert.showAndWait();
    	    		}
    	    	}
    	    }
		});
		
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				event.consume();

				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerWelcomeForm.info("WelcomeForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 1000, 500);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();

	}
}
