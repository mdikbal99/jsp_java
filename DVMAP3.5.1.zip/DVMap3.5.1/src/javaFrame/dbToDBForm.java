package javaFrame;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import FileComapre.MainClassFileValidation;
import FileComapre.StringReformat;
import application.Main;
import dataBaseConnection.ConnectToDB2;
import dataBaseConnection.ConnectToHive;
import dataBaseConnection.ConnectToMySqlServer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class dbToDBForm extends Application {

	public static Logger loggerDBtoDBForm = LogManager.getLogger(dbToDBForm.class);

	public static String file3path = "";

	static String pathOfDownloadedFileHIVE1 = null;
	static String pathOfDownloadedFileHIVE2 = null;

	static String pathOfDownloadedFileDB21 = null;
	static String pathOfDownloadedFileDB22 = null;
	
	static String pathOfDownloadedFileMySqlServer1 = null;
	static String pathOfDownloadedFileMySqlServer2 = null;

	String db1AppNameTextField = "";
	String db1TypeTextField = "";
	String db2AppNameTextField = "";
	String db2TypeTextField = "";

	boolean dbflag1 = false;
	boolean dbflag2 = false;

	boolean connetcthive1 = false;
	boolean connectDB21 = false;
	boolean connectMySqlServer1=false;
	
	boolean finalHiveFlag1 = false;
	boolean finalDB2Flag1 = false;
	boolean finalMySqlServerFlag1=false;

	boolean connetcthive2 = false;
	boolean connectDB22 = false;
	boolean connectMySqlServer2=false;
	
	boolean finalHiveFlag2 = false;
	boolean finalDB2Flag2 = false;
	boolean finalMySqlServerFlag2=false;

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@Override
	public void start(Stage primaryStage) throws ConfigurationException {
		Main.defaultResultFolderName = "Result" + StringReformat.currentDateTime();

		final DirectoryChooser dc = new DirectoryChooser();
		final FileChooser fileChooser = new FileChooser();

		// File file21111 = new File("filePathDetails.properties");
		PropertiesConfiguration configFile1 = new PropertiesConfiguration("filePathDetails.properties");

		primaryStage.setTitle("DVMap - Database to Database Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerDBtoDBForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);
		// grid.add(child, columnIndex, rowIndex, colspan, rowspan);

		Text scenetitle = new Text(" Database to Database Compare");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 1, 0, 2, 1);

		Label file1 = new Label("Select Source Connection:");
		grid.add(file1, 0, 1);

		ComboBox comboBoxExistingEnvironment1 = new ComboBox();

		Label dbName = new Label("Database Name:");
		grid.add(dbName, 0, 2);

		TextField dbNameTextField = new TextField();
		dbNameTextField.setDisable(true);
		dbNameTextField.setPromptText("(*) mandatory field");
		grid.add(dbNameTextField, 1, 2);

		Label dbPortNo = new Label("Port No:");
		grid.add(dbPortNo, 0, 3);

		TextField dbPortTextField = new TextField();
		dbPortTextField.setDisable(true);
		dbPortTextField.setPromptText("(*) mandatory field");
		grid.add(dbPortTextField, 1, 3);

		Label file21 = new Label("Database Type:");
		grid.add(file21, 0, 4);

		ComboBox comboBoxDBType1 = new ComboBox();
		comboBoxDBType1.getItems().add("Hive");
		comboBoxDBType1.getItems().add("DB2");
		comboBoxDBType1.getItems().add("Oracle");
		comboBoxDBType1.getItems().add("MySqlServer");
		comboBoxDBType1.setPromptText("Select Database Type");
		comboBoxDBType1.setMinWidth(150);
		comboBoxDBType1.setDisable(true);
		grid.add(comboBoxDBType1, 1, 4);

		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("configureDetails.properties");

			Iterator<String> keys = configFile.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				if (key.contains(configFile.getProperty(key) + "HiveAppName")
						|| key.contains(configFile.getProperty(key) + "DB2AppName")
						|| key.contains(configFile.getProperty(key) + "OracleAppName")
						||key.contains(configFile.getProperty(key) + "MySqlServerAppName")) {
					comboBoxExistingEnvironment1.getItems().add(configFile.getProperty(key));
				}
			}
			comboBoxExistingEnvironment1.setPromptText("Select Existing Environment");
			comboBoxExistingEnvironment1.setMinWidth(150);
			grid.add(comboBoxExistingEnvironment1, 1, 1);
			comboBoxExistingEnvironment1.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {
					Iterator<String> keys1 = configFile.getKeys();
					ArrayList<String> keyList1 = new ArrayList<String>();
					while (keys1.hasNext()) {
						keyList1.add(keys1.next());
					}

					for (String key : keyList1) {
						if (key.contains(t1 + "HiveAppName")) {
							comboBoxDBType1.setValue("Hive");
							dbPortTextField.setText((String) configFile.getProperty(t1 + "HivePortNo"));
							dbNameTextField.setText((String) configFile.getProperty(t1 + "HiveDBName"));
						}
						if (key.contains(t1 + "DB2AppName")) {
							comboBoxDBType1.setValue("DB2");
							dbPortTextField.setText((String) configFile.getProperty(t1 + "DB2PortNo"));
							dbNameTextField.setText((String) configFile.getProperty(t1 + "DB2DBName"));
						}
						if (key.contains(t1 + "OracleAppName")) {
							comboBoxDBType1.setValue("Oracle");
							dbPortTextField.setText((String) configFile.getProperty(t1 + "OraclePortNo"));
							dbNameTextField.setText((String) configFile.getProperty(t1 + "OracleDBName"));
						}
						if (key.contains(t1 + "MySqlServerAppName")) {
							comboBoxDBType1.setValue("MySqlServer");
							dbPortTextField.setText((String) configFile.getProperty(t1 + "MySqlServerPortNo"));
							dbNameTextField.setText((String) configFile.getProperty(t1 + "MySqlServerDBName"));
						}
					}
					db1AppNameTextField = t1;
				}
			});
		} catch (Exception e) {
			loggerDBtoDBForm.error("ConfigurationException in configureDetails.properties", e);
			e.printStackTrace();
		}

		Label file2 = new Label("Query for Source Database:");
		grid.add(file2, 0, 5);

		TextField db1query = new TextField();
		db1query.setPrefWidth(300);
		db1query.setPrefHeight(100);
		db1query.setPromptText("(*) mandatory field");
		grid.add(db1query, 1, 5, 1, 3);

		ComboBox comboBoxTableName1 = new ComboBox();
		comboBoxTableName1.setMinWidth(250);
		comboBoxTableName1.setPromptText("Select Table Name");
		PropertiesConfiguration tableConfigFile = new PropertiesConfiguration("tableDetails.properties");

		Iterator<String> tableKeys = tableConfigFile.getKeys();
		ArrayList<String> tableKeyList = new ArrayList<String>();
		while (tableKeys.hasNext()) {
			tableKeyList.add(tableKeys.next());
		}

		for (String key : tableKeyList) {
			comboBoxTableName1.getItems().add(tableConfigFile.getProperty(key));
		}
		grid.add(comboBoxTableName1, 2, 5);

		comboBoxTableName1.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				if (t1 != null) {
					db1query.setText("SELECT * FROM " + t1);
				}
				System.out.println(t1);
			}
		});

		comboBoxDBType1.valueProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				db1TypeTextField = t1;
//				if (db1TypeTextField.equalsIgnoreCase("hive")) {
//					// hld, hld_dt, hld_ms, hld_prdcr, hld_rghist
//
//					comboBoxTableName1.getItems().clear();
//					comboBoxTableName1.getItems().add("hld");
//					comboBoxTableName1.getItems().add("hld_dt");
//					comboBoxTableName1.getItems().add("hld_ms");
//					comboBoxTableName1.getItems().add("hld_prdcr");
//					comboBoxTableName1.getItems().add("hld_rghist");
//
//				comboBoxTableName1.valueProperty().addListener(new ChangeListener<String>() {
//					@Override
//					public void changed(ObservableValue ov, String t, String t1) {
//						if (t1 != null) {
//							db1query.setText("SELECT * FROM " + t1);
//						}
//						System.out.println(t1);
//					}
//				});
//				} else if (db1TypeTextField.equalsIgnoreCase("db2")) {
//
//					comboBoxTableName1.getItems().clear();
//					comboBoxTableName1.getItems().add("IBSPAN1D.ST_HLD_HIST");
//					comboBoxTableName1.getItems().add("IBSPAN1D.ST_HLD_DT_HIST");
//					comboBoxTableName1.getItems().add("IBSPAN1D.ST_HLD_MS_HIST");
//					comboBoxTableName1.getItems().add("IBSPAN1D.ST_HLD_PRDCR_HIST");
//					comboBoxTableName1.getItems().add("IBSPAN1D.ST_HLD_RGST_ROLE_HIST");
//
//					comboBoxTableName1.valueProperty().addListener(new ChangeListener<String>() {
//						@Override
//						public void changed(ObservableValue ov, String t, String t1) {
//							if (t1 != null) {
//								db1query.setText("SELECT * FROM " + t1);
//							}
//							System.out.println(t1);
//						}
//					});
//				}
//				String db1Type = db1TypeTextField;
//
//				if (db1Type.equalsIgnoreCase("hive")) {
//					try {
//						configFile1.setProperty("file1Path", pathOfDownloadedFileHIVE1);
//						configFile1.save();
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						loggerDBtoDBForm.error("ConfigurationException in filePathDetails.properties", e);
//						e.printStackTrace();
//					}
//				}
//				if (db1Type.equalsIgnoreCase("db2")) {
//					try {
//						configFile1.setProperty("file1Path", pathOfDownloadedFileDB21);
//						configFile1.save();
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						loggerDBtoDBForm.error("ConfigurationException in filePathDetails.properties", e);
//						e.printStackTrace();
//					}
//				}
			}
		});
		
		Button btnGetColumn1 = new Button("Get Source Table Column");
		HBox hbBtnGetColumn1 = new HBox(10);
		btnGetColumn1.setMinWidth(200);
		btnGetColumn1.setTextFill(Color.DARKBLUE);
		hbBtnGetColumn1.setAlignment(Pos.BOTTOM_LEFT);
		hbBtnGetColumn1.getChildren().add(btnGetColumn1);
		grid.add(hbBtnGetColumn1, 2, 6);

		Button btnClear1 = new Button("Clear Source Query");
		HBox hbBtnClear1 = new HBox(10);
		btnClear1.setMinWidth(200);
		hbBtnClear1.setAlignment(Pos.BOTTOM_LEFT);
		hbBtnClear1.getChildren().add(btnClear1);
		grid.add(hbBtnClear1, 2, 7);

		// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		Label file11 = new Label("Select Target Connection:");
		grid.add(file11, 3, 1);

		ComboBox comboBoxExistingEnvironment2 = new ComboBox();

		Label dbName2 = new Label("Database Name:");
		grid.add(dbName2, 3, 2);

		TextField dbNameTextField2 = new TextField();
		dbNameTextField2.setDisable(true);
		dbNameTextField2.setPromptText("(*) mandatory field");
		grid.add(dbNameTextField2, 4, 2);

		Label dbPortNo2 = new Label("Port No:");
		grid.add(dbPortNo2, 3, 3);

		TextField dbPortTextField2 = new TextField();
		dbPortTextField2.setDisable(true);
		dbPortTextField2.setPromptText("(*) mandatory field");
		grid.add(dbPortTextField2, 4, 3);

		Label file211 = new Label("Database Type:");
		grid.add(file211, 3, 4);

		ComboBox comboBoxDBType2 = new ComboBox();
		comboBoxDBType2.getItems().add("Hive");
		comboBoxDBType2.getItems().add("DB2");
		comboBoxDBType2.getItems().add("Oracle");
		comboBoxDBType2.getItems().add("MySqlServer");
		comboBoxDBType2.setPromptText("Select Database Type");
		comboBoxDBType2.setMinWidth(150);
		comboBoxDBType2.setDisable(true);
		grid.add(comboBoxDBType2, 4, 4);

		try {
			PropertiesConfiguration configFile11 = new PropertiesConfiguration("configureDetails.properties");

			Iterator<String> keys = configFile11.getKeys();
			ArrayList<String> keyList = new ArrayList<String>();
			while (keys.hasNext()) {
				keyList.add(keys.next());
			}

			for (String key : keyList) {
				if (key.contains(configFile11.getProperty(key) + "HiveAppName")
						|| key.contains(configFile11.getProperty(key) + "DB2AppName")
						|| key.contains(configFile11.getProperty(key) + "OracleAppName")
						||key.contains(configFile11.getProperty(key) + "MySqlServerAppName")) {
					comboBoxExistingEnvironment2.getItems().add(configFile11.getProperty(key));
				}
			}
			comboBoxExistingEnvironment2.setPromptText("Select Existing Environment");
			comboBoxExistingEnvironment2.setMinWidth(150);
			grid.add(comboBoxExistingEnvironment2, 4, 1);
			comboBoxExistingEnvironment2.valueProperty().addListener(new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue ov, String t, String t1) {

					Iterator<String> keys = configFile11.getKeys();
					ArrayList<String> keyList = new ArrayList<String>();
					while (keys.hasNext()) {
						keyList.add(keys.next());
					}

					for (String key : keyList) {
						if (key.contains(t1 + "HiveAppName")) {
							comboBoxDBType2.setValue("Hive");
							dbPortTextField2.setText((String) configFile11.getProperty(t1 + "HivePortNo"));
							dbNameTextField2.setText((String) configFile11.getProperty(t1 + "HiveDBName"));
						}
						if (key.contains(t1 + "DB2AppName")) {
							comboBoxDBType2.setValue("DB2");
							dbPortTextField2.setText((String) configFile11.getProperty(t1 + "DB2PortNo"));
							dbNameTextField2.setText((String) configFile11.getProperty(t1 + "DB2DBName"));
						}
						if (key.contains(t1 + "OracleAppName")) {
							comboBoxDBType2.setValue("Oracle");
							dbPortTextField2.setText((String) configFile11.getProperty(t1 + "OraclePortNo"));
							dbNameTextField2.setText((String) configFile11.getProperty(t1 + "OracleDBName"));
						}
						if (key.contains(t1 + "MySqlServerAppName")) {
							comboBoxDBType2.setValue("MySqlServer");
							dbPortTextField2.setText((String) configFile11.getProperty(t1 + "MySqlServerPortNo"));
							dbNameTextField2.setText((String) configFile11.getProperty(t1 + "MySqlServerDBName"));
						}
					}
					db2AppNameTextField = t1;
				}
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			loggerDBtoDBForm.error("ConfigurationException in configureDetails.properties", e);
			e.printStackTrace();
		}

		Label file2111 = new Label("Query for Target Database:");
		grid.add(file2111, 3, 5);

		TextField db2query = new TextField();
		db2query.setPrefWidth(300);
		db2query.setPrefHeight(100);
		db2query.setPromptText("(*) mandatory field");
		grid.add(db2query, 4, 5, 1, 3);

		ComboBox comboBoxTableName2 = new ComboBox();
		comboBoxTableName2.setMinWidth(250);
		comboBoxTableName2.setPromptText("Select Table Name");
		PropertiesConfiguration tableConfigFile1 = new PropertiesConfiguration("tableDetails.properties");

		Iterator<String> tableKeys1 = tableConfigFile1.getKeys();
		ArrayList<String> tableKeyList1 = new ArrayList<String>();
		while (tableKeys1.hasNext()) {
			tableKeyList1.add(tableKeys1.next());
		}

		for (String key : tableKeyList1) {
			comboBoxTableName2.getItems().add(tableConfigFile1.getProperty(key));
		}
		grid.add(comboBoxTableName2, 5, 5);

		comboBoxTableName2.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				if (t1 != null) {
					db2query.setText("SELECT * FROM " + t1);
				}
				System.out.println(t1);
			}
		});

		comboBoxDBType2.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				db2TypeTextField = t1;

//				if (db2TypeTextField.equalsIgnoreCase("hive")) {
//					// hld, hld_dt, hld_ms, hld_prdcr, hld_rghist
//
//					comboBoxTableName2.getItems().clear();
//					comboBoxTableName2.getItems().add("hld");
//					comboBoxTableName2.getItems().add("hld_dt");
//					comboBoxTableName2.getItems().add("hld_ms");
//					comboBoxTableName2.getItems().add("hld_prdcr");
//					comboBoxTableName2.getItems().add("hld_rghist");
//
//					// HBox hbox = new HBox(comboBox);
//
//					comboBoxTableName2.valueProperty().addListener(new ChangeListener<String>() {
//						@Override
//						public void changed(ObservableValue ov, String t, String t1) {
//							if (t1 != null) {
//								db2query.setText("SELECT * FROM " + t1);
//							}
//							System.out.println(t1);
//						}
//					});
//				} else if (db2TypeTextField.equalsIgnoreCase("db2")) {
//					comboBoxTableName2.getItems().clear();
//					comboBoxTableName2.getItems().add("IBSPAN1D.ST_HLD_HIST");
//					comboBoxTableName2.getItems().add("IBSPAN1D.ST_HLD_DT_HIST");
//					comboBoxTableName2.getItems().add("IBSPAN1D.ST_HLD_MS_HIST");
//					comboBoxTableName2.getItems().add("IBSPAN1D.ST_HLD_PRDCR_HIST");
//					comboBoxTableName2.getItems().add("IBSPAN1D.ST_HLD_RGST_ROLE_HIST");
//
//					comboBoxTableName2.valueProperty().addListener(new ChangeListener<String>() {
//						@Override
//						public void changed(ObservableValue ov, String t, String t1) {
//							if (t1 != null) {
//								db2query.setText("SELECT * FROM " + t1);
//							}
//							System.out.println(t1);
//						}
//					});
//				}

//				String db2Type = db2TypeTextField;
//
//				if (db2Type.equalsIgnoreCase("hive")) {
//					try {
//						configFile1.setProperty("file2Path", pathOfDownloadedFileHIVE2);
//						configFile1.save();
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						loggerDBtoDBForm.error("ConfigurationException in filePathDetails.properties", e);
//						e.printStackTrace();
//					}
//				}
//				if (db2Type.equalsIgnoreCase("db2")) {
//					try {
//						configFile1.setProperty("file2Path", pathOfDownloadedFileDB22);
//						configFile1.save();
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						loggerDBtoDBForm.error("ConfigurationException in filePathDetails.properties", e);
//						e.printStackTrace();
//					}
//				}
			}
		});
		
		Button btnGetColumn2 = new Button("Get Target Table Column");
		HBox hbBtnGetColumn2 = new HBox(10);
		btnGetColumn2.setMinWidth(200);
		btnGetColumn2.setTextFill(Color.DARKBLUE);
		hbBtnGetColumn2.setAlignment(Pos.BOTTOM_LEFT);
		hbBtnGetColumn2.getChildren().add(btnGetColumn2);
		grid.add(hbBtnGetColumn2, 5, 6);

		Button btnClear2 = new Button("Clear Target Query");
		HBox hbBtnClear2 = new HBox(10);
		btnClear2.setMinWidth(200);
		hbBtnClear2.setAlignment(Pos.BOTTOM_LEFT);
		hbBtnClear2.getChildren().add(btnClear2);
		grid.add(hbBtnClear2, 5, 7);

		Label dataSheet1 = new Label("Mapping Sheet Path:");
		grid.add(dataSheet1, 0, 8);

		TextField dsTextField = new TextField();
		dsTextField.setDisable(true);
		dsTextField.setPromptText("(*) mandatory field");
		grid.add(dsTextField, 1, 8);

		Button getFile3 = new Button("Select Mapping Sheet");
		HBox hbBtn3 = new HBox(10);
		getFile3.setMinWidth(150);
		hbBtn3.setAlignment(Pos.BOTTOM_LEFT);
		hbBtn3.getChildren().add(getFile3);
		grid.add(hbBtn3, 2, 8);

		Label resultName = new Label("Test Name:");
		grid.add(resultName, 0, 9);

		TextField resultNameTextField = new TextField(Main.defaultResultFolderName);
		resultNameTextField.setMinWidth(300);
		resultNameTextField.setPromptText("(*) mandatory field");
		grid.add(resultNameTextField, 1, 9);

		Label resultPath = new Label("Result Folder Path:");
		grid.add(resultPath, 0, 10);

		TextField resultTextField = new TextField(Main.defaultSavedPath + Main.defaultResultFolderName);
		resultTextField.setMinWidth(300);
		resultTextField.setDisable(true);
		// resultTextField.setPromptText("(*) mandatory field");
		grid.add(resultTextField, 1, 10);

		Button getResultPath = new Button("Choose Folder");
		HBox hbResultPath = new HBox(10);
		getResultPath.setMinWidth(150);
		hbResultPath.setAlignment(Pos.BOTTOM_LEFT);
		hbResultPath.getChildren().add(getResultPath);
		grid.add(hbResultPath, 2, 10);

		Button btn = new Button("Back to Select Option");
//		HBox hbBtn4 = new HBox(10);
//		hbBtn4.setAlignment(Pos.BOTTOM_LEFT);
//		hbBtn4.getChildren().add(btn);
		btn.setMinWidth(150);
		btn.setMinHeight(35);
		btn.setTextFill(Color.DARKBLUE);
		btn.setTextAlignment(TextAlignment.CENTER);
		btn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		grid.add(btn, 2, 13);

		Button btn1 = new Button("Start Compare");
//		HBox hbBtn41 = new HBox(10);
//		hbBtn41.setAlignment(Pos.BOTTOM_RIGHT);
//		hbBtn41.getChildren().add(btn1);
		btn1.setMinWidth(150);
		btn1.setMinHeight(35);
		btn1.setTextFill(Color.DARKBLUE);
		btn1.setTextAlignment(TextAlignment.CENTER);
		btn1.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		grid.add(btn1, 3, 13);
		
//		Label errorLabel = new Label();
//		grid.add(errorLabel, 2, 12, 2, 1);

		getFile3.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				try {
	
					Task<Void> task = new Task<Void>() {
						@Override
						protected Void call() throws Exception {
						
							return null;
						}
					};
					task.setOnSucceeded(eTask -> {
						ButtonType cnclBtn = new ButtonType("Cancel", ButtonBar.ButtonData.OK_DONE);
						ButtonType yesBtn = new ButtonType("YES", ButtonBar.ButtonData.NEXT_FORWARD);
						ButtonType noBtn = new ButtonType("NO", ButtonBar.ButtonData.NEXT_FORWARD);

						Alert alert2 = new Alert(AlertType.INFORMATION, "", noBtn, yesBtn, cnclBtn);
						alert2.setTitle("Option: Maping Sheet");
						alert2.setHeaderText("Do you have Maping Sheet?");
						alert2.setContentText("Click 'YES' to select Maping sheet \nClick 'NO' to prepare Maping sheet");
						
						outer: while (true) {
							Optional<ButtonType> result = alert2.showAndWait();

							if (result.orElse(cnclBtn) == yesBtn) {
								try {
									configureFileChooser(fileChooser);
									File file = fileChooser.showOpenDialog(primaryStage);
									file3path = file.toString();
									System.out.println("Data Sheet Path: " + file3path);
									dsTextField.setText(file3path);
									configFile1.setProperty("datasheetPath", file3path);
									configFile1.save();
								} catch (Exception e1) {

								}
														
								break outer;
							} else if (result.get() == noBtn) {
								System.out.println("Creating Source Maping");
								try {
									alert2.close();
									SourceTableView stv= new SourceTableView();
				                     stv.start(primaryStage);
									break outer;
								} catch (Exception e1) {
									loggerDBtoDBForm.error(e1);
									e1.printStackTrace();
								}
							} else {
								try {
									dbToDBForm of = new dbToDBForm();
									of.start(primaryStage);
								} catch (ConfigurationException e1) {
									e1.printStackTrace();
								}
								break outer;
							}
						}
					});

					new Thread(task).start();
					
                     
					
				} catch (Exception e1) {
					loggerDBtoDBForm.error("ConfigurationException in filePathDetails.properties", e1);
					e1.printStackTrace();
				}
			}
		});
		
		btnGetColumn1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				Alert alert = new Alert(AlertType.ERROR);
				if (comboBoxExistingEnvironment1.getSelectionModel().isEmpty()
						|| comboBoxDBType1.getSelectionModel().isEmpty() 
						|| db1query.getText() == null || db1query.getText().trim().isEmpty() 
						|| dbNameTextField.getText() == null || dbNameTextField.getText().trim().isEmpty() 
						|| dbPortTextField.getText() == null || dbPortTextField.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerDBtoDBForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					String AppName = db1AppNameTextField;//comboBoxExistingEnvironment1.getSelectionModel().toString();
					String dbType = db1TypeTextField;//comboBoxDBType1.getSelectionModel().toString();
					String SQLQuery = db1query.getText();

					try {
						Task<Void> task1 = new Task<Void>() {
							@Override
							protected Void call() throws Exception {
//									String missingStr = null;
								if (dbType.equalsIgnoreCase("hive")) {
									finalHiveFlag1 = ConnectToHive.getColumnNameHive(AppName, dbType, SQLQuery);
									System.out.println("finalHiveFlag: " + finalHiveFlag1);
//									System.out.println("FileToDBFrom Hive Column Names are: " + ConnectToHive.hiveColumnName);
									if (!finalHiveFlag1) {
										if (ConnectToHive.hiveDriverError) {
//											btn1.setDisable(false);
//											finalHiveFlag = false;
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in Hive Database Configuration OR Hive Query is Wrong!");
													loggerDBtoDBForm.info(
															"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToHive.hiveQueryError && ConnectToHive.hiveConnectionError) {
//												btn1.setDisable(false);
//												finalHiveFlag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in Hive Database Configuration OR Hive Query is Wrong!");
														loggerDBtoDBForm.info(
																"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
									
								} else if (dbType.equalsIgnoreCase("db2")) {
									finalDB2Flag1 = ConnectToDB2.getColumnNameDB2(AppName, dbType, SQLQuery);
									System.out.println("finalDB2Flag: " + finalDB2Flag1);
//									System.out.println("FileToDBFrom DB2 Column Names are: " + ConnectToDB2.db2ColumnName);
									if (!finalDB2Flag1) {
										if (ConnectToDB2.db2DriverError) {
//											btn1.setDisable(false);
//											finalDB2Flag = false;
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													loggerDBtoDBForm.info(
															"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToDB2.db2QueryError && ConnectToDB2.db2ConnectionError) {
//												btn1.setDisable(false);
//												finalDB2Flag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														loggerDBtoDBForm.info(
																"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
								}
								//My Sql Server
								else if (dbType.equalsIgnoreCase("MySqlServer")) {
									finalMySqlServerFlag1 = ConnectToMySqlServer.getColumnNameMySqlServer(AppName, dbType, SQLQuery);
									System.out.println("finalMySqlServerFlag1 : " + finalMySqlServerFlag1);
//									System.out.println("FileToDBFrom DB2 Column Names are: " + ConnectToDB2.db2ColumnName);
									if (!finalMySqlServerFlag1) {
										if (ConnectToMySqlServer.mySqlServerDriverError) {
//											btn1.setDisable(false);
//											finalDB2Flag = false;
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
													loggerDBtoDBForm.info(
															"Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToMySqlServer.mySqlServerQueryError && ConnectToMySqlServer.mySqlServerConnectionError) {
//												btn1.setDisable(false);
//												finalDB2Flag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
														loggerDBtoDBForm.info(
																"Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
								}
								
								return null;
							}
						};

						task1.setOnSucceeded(eTask1 -> {
							
							if (finalHiveFlag1) {
								HiveTableColumnForm hive = new HiveTableColumnForm();
								hive.open();
							}
							if (finalDB2Flag1) {
								DB2TableColumnForm db2 = new DB2TableColumnForm();
								db2.open();
							}
							if(finalMySqlServerFlag1) {
								MySqlServerTableColumnForm msql= new MySqlServerTableColumnForm();
								msql.open();
							}
						});
						new Thread(task1).start();

					} catch (Exception e1) {
						loggerDBtoDBForm.error("Error", e1);
						e1.printStackTrace();
					}
				}
			}
		});
		
		btnGetColumn2.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				Alert alert = new Alert(AlertType.ERROR);
				if (comboBoxExistingEnvironment2.getSelectionModel().isEmpty() || comboBoxDBType2.getSelectionModel().isEmpty() 
						|| db2query.getText() == null || db2query.getText().trim().isEmpty() 
						|| dbNameTextField2.getText() == null || dbNameTextField2.getText().trim().isEmpty() 
						|| dbPortTextField2.getText() == null || dbPortTextField2.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerDBtoDBForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					String AppName = db2AppNameTextField;//comboBoxExistingEnvironment2.getSelectionModel().toString();
					String dbType = db2TypeTextField;//comboBoxDBType2.getSelectionModel().toString();
					String SQLQuery = db2query.getText();

					try {
						Task<Void> task1 = new Task<Void>() {
							@Override
							protected Void call() throws Exception {
//									String missingStr = null;
								if (dbType.equalsIgnoreCase("hive")) {
									finalHiveFlag2 = ConnectToHive.getColumnNameHive(AppName, dbType, SQLQuery);
									System.out.println("finalHiveFlag: " + finalHiveFlag2);
//									System.out.println("FileToDBFrom Hive Column Names are: " + ConnectToHive.hiveColumnName);
									if (!finalHiveFlag2) {
										if (ConnectToHive.hiveDriverError) {
//											btn1.setDisable(false);
//											finalHiveFlag = false;
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in Hive Database Configuration OR Hive Query is Wrong!");
													loggerDBtoDBForm.info(
															"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToHive.hiveQueryError && ConnectToHive.hiveConnectionError) {
//												btn1.setDisable(false);
//												finalHiveFlag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in Hive Database Configuration OR Hive Query is Wrong!");
														loggerDBtoDBForm.info(
																"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
									
								} else if (dbType.equalsIgnoreCase("db2")) {
									finalDB2Flag2 = ConnectToDB2.getColumnNameDB2(AppName, dbType, SQLQuery);
									System.out.println("finalDB2Flag: " + finalDB2Flag2);
//									System.out.println("FileToDBFrom DB2 Column Names are: " + ConnectToDB2.db2ColumnName);
									if (!finalDB2Flag2) {
										if (ConnectToDB2.db2DriverError) {
//											btn1.setDisable(false);
//											finalDB2Flag = false;
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													loggerDBtoDBForm.info(
															"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToDB2.db2QueryError && ConnectToDB2.db2ConnectionError) {
//												btn1.setDisable(false);
//												finalDB2Flag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														loggerDBtoDBForm.info(
																"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
								}
								else if (dbType.equalsIgnoreCase("MySqlServer")) {
									finalMySqlServerFlag2 = ConnectToMySqlServer.getColumnNameMySqlServer(AppName, dbType, SQLQuery);
									System.out.println("finalMySqlServerFlag2: " + finalMySqlServerFlag2);
//									System.out.println("FileToDBFrom DB2 Column Names are: " + ConnectToDB2.db2ColumnName);
									if (!finalMySqlServerFlag2) {
										if (ConnectToMySqlServer.mySqlServerDriverError) {
//											btn1.setDisable(false);
//											finalDB2Flag = false;
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
													loggerDBtoDBForm.info(
															"Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToMySqlServer.mySqlServerQueryError && ConnectToMySqlServer.mySqlServerConnectionError) {
//												btn1.setDisable(false);
//												finalDB2Flag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
														loggerDBtoDBForm.info(
																"Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
								}
								return null;
							}
						};

						task1.setOnSucceeded(eTask1 -> {
							
							if (finalHiveFlag2) {
								HiveTableColumnForm hive = new HiveTableColumnForm();
								hive.open();

							}
							if (finalDB2Flag2) {
								DB2TableColumnForm db2 = new DB2TableColumnForm();
								db2.open();
							}
							if (finalMySqlServerFlag2) {
								MySqlServerTableColumnForm mysql = new MySqlServerTableColumnForm();
								mysql.open();
							}
							
						});
						new Thread(task1).start();

					} catch (Exception e1) {
						loggerDBtoDBForm.error("Error", e1);
						e1.printStackTrace();
					}
				}
			}
		});

		btnClear1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				db1query.clear();
				comboBoxTableName1.getSelectionModel().clearSelection();
			}
		});

		btnClear2.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				db2query.clear();
				comboBoxTableName2.getSelectionModel().clearSelection();
			}
		});

		getResultPath.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				configureFolderChooser(dc);
				File folder = dc.showDialog(primaryStage);
				Main.defaultSavedPath = folder.toString() + "\\";
				Main.defaultResultFolderName = resultNameTextField.getText() + "\\";
				System.out.println("Result Folder Path: " + Main.defaultSavedPath + Main.defaultResultFolderName);
				resultTextField.setText(Main.defaultSavedPath + Main.defaultResultFolderName);
			}
		});

		btn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				optionForm oppage = new optionForm();
				oppage.start(primaryStage);
			}
		});

		btn1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				Alert alert = new Alert(AlertType.ERROR);
				if (//comboBoxTableName1.getSelectionModel().isEmpty() || comboBoxTableName2.getSelectionModel().isEmpty()
						comboBoxDBType1.getSelectionModel().isEmpty()
						|| comboBoxDBType2.getSelectionModel().isEmpty()
						|| comboBoxExistingEnvironment1.getSelectionModel().isEmpty()
						|| comboBoxExistingEnvironment2.getSelectionModel().isEmpty() || dsTextField.getText() == null
						|| dsTextField.getText().trim().isEmpty() || db1query.getText() == null
						|| db1query.getText().trim().isEmpty() || db2query.getText() == null
						|| db2query.getText().trim().isEmpty() || resultTextField.getText() == null
						|| resultTextField.getText().trim().isEmpty() || dbNameTextField.getText() == null
						|| dbNameTextField.getText().trim().isEmpty() || dbNameTextField2.getText() == null
						|| dbNameTextField2.getText().trim().isEmpty() || dbPortTextField.getText() == null
						|| dbPortTextField.getText().trim().isEmpty() || dbPortTextField2.getText() == null
						|| dbPortTextField2.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerDBtoDBForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					Main.defaultResultFolderName = resultNameTextField.getText() + "\\";
					resultTextField.setText(Main.defaultSavedPath + Main.defaultResultFolderName);

					String defaultFolderpath = Main.defaultSavedPath + Main.defaultResultFolderName;
					File file1 = new File(defaultFolderpath);
					System.out.println("defaultFolderpath: " + file1.getAbsolutePath());
					if (file1.exists()) {
						Alert alert1 = new Alert(AlertType.ERROR);
						alert1.setTitle("Run Time Error");
						alert1.setHeaderText("Folder is already present in directory!");
						loggerDBtoDBForm.info("Run Time Error: Folder is already present in directory!");
						alert1.setContentText("");
						((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
								.add(new Image("file:Logo.png"));
						alert1.showAndWait();
					} else {
						btn1.setDisable(true);
						try {
							pathOfDownloadedFileHIVE1 = ConnectToHive.downloadFilePathForHive() + "FileHive1.txt";
							pathOfDownloadedFileHIVE2 = ConnectToHive.downloadFilePathForHive() + "FileHive2.txt";

							pathOfDownloadedFileDB21 = ConnectToDB2.downloadedPathDB2() + "FileDB21.txt";
							pathOfDownloadedFileDB22 = ConnectToDB2.downloadedPathDB2() + "FileDB22.txt";
							
							pathOfDownloadedFileMySqlServer1=ConnectToMySqlServer.downloadedPathMySqlServer()+"FileMySqlServer1.txt";
							pathOfDownloadedFileMySqlServer2=ConnectToMySqlServer.downloadedPathMySqlServer()+"FileMySqlServer2.txt";
							
							String db1Type = db1TypeTextField;

							if (db1Type.equalsIgnoreCase("hive")) {
								try {
									configFile1.setProperty("file1Path", pathOfDownloadedFileHIVE1);
									configFile1.save();
								} catch (Exception e1) {
									// TODO Auto-generated catch block
									loggerDBtoDBForm.error("ConfigurationException in hive filePathDetails.properties", e1);
									e1.printStackTrace();
								}
							}
							if (db1Type.equalsIgnoreCase("db2")) {
								try {
									configFile1.setProperty("file1Path", pathOfDownloadedFileDB21);
									configFile1.save();
								} catch (Exception e2) {
									// TODO Auto-generated catch block
									loggerDBtoDBForm.error("ConfigurationException in db2 filePathDetails.properties", e2);
									e2.printStackTrace();
								}
							}
							if (db1Type.equalsIgnoreCase("MySqlServer")) {
								try {
									configFile1.setProperty("file1Path", pathOfDownloadedFileMySqlServer1);
									configFile1.save();
								} catch (Exception e2) {
									// TODO Auto-generated catch block
									loggerDBtoDBForm.error("ConfigurationException in MySqlServer filePathDetails.properties", e2);
									e2.printStackTrace();
								}
							}
							
							String db2Type = db2TypeTextField;

							if (db2Type.equalsIgnoreCase("hive")) {
								try {
									configFile1.setProperty("file2Path", pathOfDownloadedFileHIVE2);
									configFile1.save();
								} catch (Exception e1) {
									// TODO Auto-generated catch block
									loggerDBtoDBForm.error("ConfigurationException in hive filePathDetails.properties", e1);
									e1.printStackTrace();
								}
							}
							if (db2Type.equalsIgnoreCase("db2")) {
								try {
									configFile1.setProperty("file2Path", pathOfDownloadedFileDB22);
									configFile1.save();
								} catch (Exception e2) {
									// TODO Auto-generated catch block
									loggerDBtoDBForm.error("ConfigurationException in db2 filePathDetails.properties", e2);
									e2.printStackTrace();
								}
							}
							if (db2Type.equalsIgnoreCase("MySqlServer")) {
								try {
									configFile1.setProperty("file2Path", pathOfDownloadedFileMySqlServer2);
									configFile1.save();
								} catch (Exception e2) {
									// TODO Auto-generated catch block
									loggerDBtoDBForm.error("ConfigurationException in MySqlServer filePathDetails.properties", e2);
									e2.printStackTrace();
								}
							}
							
							
							
							
							configFile1.setProperty("defaultResultFolderName", Main.defaultResultFolderName);
							configFile1.setProperty("defaultResultFolderPath", Main.defaultSavedPath);
							configFile1.save();
						} catch (Exception e3) {
							// TODO Auto-generated catch block
							loggerDBtoDBForm.error("ConfigurationException in filePathDetails.properties", e3);
							e3.printStackTrace();
						}

						Stage secondStage = new Stage();
						Stage secondStage1 = new Stage();

						String AppName1 = db1AppNameTextField;
						String dbType1 = db1TypeTextField;
						String SQLQuery1 = db1query.getText();

//						try {

							Alert alert1 = new Alert(AlertType.INFORMATION);
							Alert alert11 = new Alert(AlertType.INFORMATION);
							Alert alert2 = new Alert(AlertType.INFORMATION);
							
							alert1.setTitle("Source Database Extract Processing");
							alert1.setContentText("Source Database Extract in Process");
							loggerDBtoDBForm.info("Source Database Extract Processing: Source Database Extract in Process");
							alert1.setHeaderText("");
							((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							alert1.show();
							
							Task<Void> task1 = new Task<Void>() {
								@Override
								protected Void call() throws Exception {
//									String missingStr = null;
									if (dbType1.equalsIgnoreCase("hive")) {
										finalHiveFlag1 = ConnectToHive.runConnectToHive(AppName1, dbType1, SQLQuery1,
												pathOfDownloadedFileHIVE1);
										if (ConnectToHive.hiveDriverError) {
											btn1.setDisable(false);
											Platform.runLater(new Runnable() {

							                    @Override
							                    public void run() {
							                    	alert1.close();
													alert.setTitle("Run Time Error: Source");
													alert.setHeaderText("Error in Hive Database Configuration OR Hive Query is Wrong!");
													loggerDBtoDBForm.info("Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
							                    }
							                });
										} else {
											if (ConnectToHive.hiveQueryError && ConnectToHive.hiveConnectionError) {
												btn1.setDisable(false);
												Platform.runLater(new Runnable() {
	
								                    @Override
								                    public void run() {
								                    	alert1.close();
														alert.setTitle("Run Time Error: Source");
														alert.setHeaderText("Error in Hive Database Configuration OR Hive Query is Wrong!");
														loggerDBtoDBForm.info("Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
								                    }
								                });
											}
										}
									} else if (dbType1.equalsIgnoreCase("db2")) {
										finalDB2Flag1 = ConnectToDB2.runConnetDB2(AppName1, dbType1, SQLQuery1,
												pathOfDownloadedFileDB21);
										if (ConnectToDB2.db2DriverError) {
											btn1.setDisable(false);
											Platform.runLater(new Runnable() {

							                    @Override
							                    public void run() {
							                    	alert1.close();
													alert.setTitle("Run Time Error: Source");
													alert.setHeaderText("Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													loggerDBtoDBForm.info("Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
							                    }
							                });
										} else {
											if (ConnectToDB2.db2QueryError && ConnectToDB2.db2ConnectionError) {
												btn1.setDisable(false);
												Platform.runLater(new Runnable() {
	
								                    @Override
								                    public void run() {
								                    	alert1.close();
														alert.setTitle("Run Time Error: Source");
														alert.setHeaderText("Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														loggerDBtoDBForm.info("Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
								                    }
								                });
											}
										}
									} 
									if (dbType1.equalsIgnoreCase("MySqlServer")) {
										finalMySqlServerFlag1 = ConnectToMySqlServer.runConnetmySqlServer(AppName1, dbType1, SQLQuery1,
												pathOfDownloadedFileMySqlServer1);
										if (ConnectToMySqlServer.mySqlServerDriverError) {
											btn1.setDisable(false);
											Platform.runLater(new Runnable() {

							                    @Override
							                    public void run() {
							                    	alert1.close();
													alert.setTitle("Run Time Error: Source");
													alert.setHeaderText("Error in MySqlServer Database Configuration OR Hive Query is Wrong!");
													loggerDBtoDBForm.info("Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
							                    }
							                });
										} else {
											if (ConnectToMySqlServer.mySqlServerQueryError && ConnectToMySqlServer.mySqlServerConnectionError) {
												btn1.setDisable(false);
												Platform.runLater(new Runnable() {
	
								                    @Override
								                    public void run() {
								                    	alert1.close();
														alert.setTitle("Run Time Error: Source");
														alert.setHeaderText("Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
														loggerDBtoDBForm.info("Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
								                    }
								                });
											}
										}
									}
									
//									else {
//										
//									}
//									else
//										System.out.println("please check your db type and query matching with prop.");
									return null;
								}
							};
							task1.setOnSucceeded(eTask1 -> {
								if (finalHiveFlag1 || finalDB2Flag1||finalMySqlServerFlag1) {
									dbflag1 = true;
									alert1.close();
									alert11.setTitle("Target Database Extract Processing");
									alert11.setContentText("Target Database Extract in Process");
									loggerDBtoDBForm.info(
											"Target Database Extract Processing: Target Database Extract in Process");
									alert11.setHeaderText("");
									((Stage) alert11.getDialogPane().getScene().getWindow()).getIcons()
											.add(new Image("file:Logo.png"));
									alert11.show();
									// Alert alert11 = new
									// Alert(AlertType.INFORMATION);
									String AppName2 = db2AppNameTextField;
									String dbType2 = db2TypeTextField;
									String SQLQuery2 = db2query.getText();

									Task<Void> task2 = new Task<Void>() {
										@Override
										protected Void call() throws Exception {
//											String missingStr = null;
											if (dbType2.equalsIgnoreCase("hive")) {
												finalHiveFlag2 = ConnectToHive.runConnectToHive(AppName2, dbType2,
														SQLQuery2, pathOfDownloadedFileHIVE2);
												if (ConnectToHive.hiveDriverError) {
													btn1.setDisable(false);
													Platform.runLater(new Runnable() {

									                    @Override
									                    public void run() {
									                    	alert11.close();
															alert.setTitle("Run Time Error: Target");
															alert.setHeaderText("Error in Hive Database Configuration OR Hive Query is Wrong!");
															loggerDBtoDBForm.info("Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
															alert.setContentText("");
															((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																	.add(new Image("file:Logo.png"));
															alert.showAndWait();
									                    }
									                });
												} else {
													if (ConnectToHive.hiveQueryError && ConnectToHive.hiveConnectionError) {
														btn1.setDisable(false);
														Platform.runLater(new Runnable() {
			
										                    @Override
										                    public void run() {
										                    	alert11.close();
																alert.setTitle("Run Time Error: Target");
																alert.setHeaderText("Error in Hive Database Configuration OR Hive Query is Wrong!");
																loggerDBtoDBForm.info("Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
																alert.setContentText("");
																((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																		.add(new Image("file:Logo.png"));
																alert.showAndWait();
										                    }
										                });
													}
												}
											} else if (dbType2.equalsIgnoreCase("db2")) {
												finalDB2Flag2 = ConnectToDB2.runConnetDB2(AppName2, dbType2, SQLQuery2,
														pathOfDownloadedFileDB22);
												if (ConnectToDB2.db2DriverError) {
													btn1.setDisable(false);
													Platform.runLater(new Runnable() {

									                    @Override
									                    public void run() {
									                    	alert11.close();
															alert.setTitle("Run Time Error: Target");
															alert.setHeaderText("Error in DB2 Database Configuration OR DB2 Query is Wrong!");
															loggerDBtoDBForm.info("Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
															alert.setContentText("");
															((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																	.add(new Image("file:Logo.png"));
															alert.showAndWait();
									                    }
									                });
												} else {
													if (ConnectToDB2.db2QueryError && ConnectToDB2.db2ConnectionError) {
														btn1.setDisable(false);
														Platform.runLater(new Runnable() {
			
										                    @Override
										                    public void run() {
										                    	alert11.close();
																alert.setTitle("Run Time Error: Target");
																alert.setHeaderText("Error in DB2 Database Configuration OR DB2 Query is Wrong!");
																loggerDBtoDBForm.info("Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
																alert.setContentText("");
																((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																		.add(new Image("file:Logo.png"));
																alert.showAndWait();
										                    }
										                });
													}
												}
											} 
											if (dbType2.equalsIgnoreCase("MySqlServer")) {
												finalMySqlServerFlag2 = ConnectToMySqlServer.runConnetmySqlServer(AppName2, dbType2,
														SQLQuery2, pathOfDownloadedFileMySqlServer2);
												if (ConnectToMySqlServer.mySqlServerDriverError) {
													btn1.setDisable(false);
													Platform.runLater(new Runnable() {

									                    @Override
									                    public void run() {
									                    	alert11.close();
															alert.setTitle("Run Time Error: Target");
															alert.setHeaderText("Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
															loggerDBtoDBForm.info("Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
															alert.setContentText("");
															((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																	.add(new Image("file:Logo.png"));
															alert.showAndWait();
									                    }
									                });
												} else {
													if (ConnectToMySqlServer.mySqlServerQueryError && ConnectToMySqlServer.mySqlServerConnectionError) {
														btn1.setDisable(false);
														Platform.runLater(new Runnable() {
			
										                    @Override
										                    public void run() {
										                    	alert11.close();
																alert.setTitle("Run Time Error: Target");
																alert.setHeaderText("Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
																loggerDBtoDBForm.info("Run Time Error: Error in MySqlServer Database Configuration OR MySqlServer Query is Wrong!");
																alert.setContentText("");
																((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																		.add(new Image("file:Logo.png"));
																alert.showAndWait();
										                    }
										                });
													}
												}
											} 
//											else {

//											}
//											else
//												System.out.println("please check you db type and query with prop. file");
											return null;
										}
									};
									task2.setOnSucceeded(eTask2 -> {
										if (finalHiveFlag2 || finalDB2Flag2||finalMySqlServerFlag2) {
											dbflag2 = true;
											alert11.close();
											
											if (dbflag2 && dbflag1) {
												alert2.setTitle("Validating");
												Image image = null;
												try {
													image = new Image(new FileInputStream("8yxqez.gif"));
												} catch (Exception e2) {
													loggerDBtoDBForm.error("FileNotFoundException: 8yxqez.gif is NOT FOUND!",
															e2);
													e2.printStackTrace();
												}
												ImageView imageView = new ImageView(image);
												imageView.setFitHeight(100);
												imageView.setFitWidth(100);
												alert2.setGraphic(imageView);
												((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons()
														.add(new Image("file:Logo.png"));
												alert2.setHeaderText("Validating both files!");
												alert2.setContentText("Validating in process");
												loggerDBtoDBForm
														.info("Validating: Validating both files: Validating in process");
												alert2.show();
											}


											File toMakeDefaultResultPath = new File(
													Main.defaultSavedPath + Main.defaultResultFolderName);
											toMakeDefaultResultPath.mkdirs();

											Task<Void> task3 = new Task<Void>() {
												@Override
												protected Void call() throws Exception {
													try {
														MainClassFileValidation.mainMethodForFileCompare();
														MainClassFileValidation.sourceRecordCount = 0;
														MainClassFileValidation.targetRecordCount = 0;

													} catch (Exception e) {
														// TODO Auto-generated catch block
														loggerDBtoDBForm.error(
																"IOException in MainClassFileValidation.mainMethodForFileCompare()",
																e);
														e.printStackTrace();
													}
													return null;
												}
											};
											task3.setOnSucceeded(eTask3 -> {
												alert2.close();
												ButtonType okBtn = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
												ButtonType analyzeBtn = new ButtonType("Analyze",
														ButtonBar.ButtonData.NEXT_FORWARD);
												ButtonType resultBtn = new ButtonType("Result",
														ButtonBar.ButtonData.NEXT_FORWARD);
												Alert alert3 = new Alert(AlertType.INFORMATION, "", resultBtn, analyzeBtn,
														okBtn);
												alert3.setTitle("Validation Result");
												((Stage) alert3.getDialogPane().getScene().getWindow()).getIcons()
														.add(new Image("file:Logo.png"));
												alert3.setHeaderText("Validation Successfully Completed!");
												loggerDBtoDBForm.info("Validation Result: Validation Successfully Completed!");
												alert3.setContentText("Please, Check " + Main.defaultSavedPath
														+ Main.defaultResultFolderName + " Folder for Result");

												outer: while (true) {
													Optional<ButtonType> result = alert3.showAndWait();
													if (result.orElse(okBtn) == analyzeBtn) {
														AnalysisForm aof = new AnalysisForm();
														aof.start(primaryStage);
														System.out.println("Analyze");
														break outer;
													} else if (result.get() == resultBtn) {
														System.out.println("Result");
														try {
															Desktop.getDesktop().open(new File(
																	Main.defaultSavedPath + Main.defaultResultFolderName));
															continue outer;
														} catch (Exception e1) {
															// TODO Auto-generated catch
															loggerDBtoDBForm.error(
																	"IOException in Desktop.getDesktop().open(new File(Main.defaultSavedPath + Main.defaultResultFolderName))",
																	e1);
															e1.printStackTrace();
														}
													} else {
														optionForm of = new optionForm();
														of.start(primaryStage);
														break outer;
													}
												}
											});
											new Thread(task3).start();
										}

									});
									new Thread(task2).start();
								}
								

							});
							new Thread(task1).start();
//						} catch (Exception e1) {
//							loggerDBtoDBForm.error("Error", e1);
//							e1.printStackTrace();
//						}
					}
				}
				try {
					String detailFileName = Main.defaultSavedPath + Main.defaultResultFolderName + "Details.txt";
					File file = new File(detailFileName);
					file.getParentFile().mkdir();
					System.out.println("Final filepath : " + file.getAbsolutePath());
					if (!file.exists()) {
						file.createNewFile();
						System.out.println("Details File is created!");
					}

					FileWriter fw = new FileWriter(file, true);
					BufferedWriter bw = new BufferedWriter(fw);
					PrintWriter out = new PrintWriter(bw);

					out.println("Source Database Query	: " + db1query.getText());
					out.println("Destination Database Query	: " + db2query.getText());
					out.println("Datasheet File Path	: " + file3path);
					out.println("Result Folder Path	: " + Main.defaultSavedPath + Main.defaultResultFolderName);
					out.close();
					bw.close();
					fw.close();
				} catch (Exception e1) {
					loggerDBtoDBForm.error("IOException in Details.txt", e1);
					e1.printStackTrace();
				}
			}
		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				// consume event
				event.consume();

				// show close dialog
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerDBtoDBForm.info("dbToDBForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 1500, 600);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
		primaryStage.setFullScreen(true);
	}

	private static void configureFolderChooser(final DirectoryChooser dc) {
		dc.setTitle("Folder Chooser");
		dc.setInitialDirectory(new File(System.getProperty("user.home")));
	}

	private static void configureFileChooser(final FileChooser fileChooser) {
		fileChooser.setTitle("File Chooser");
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Images", "*.*"));
	}
}
