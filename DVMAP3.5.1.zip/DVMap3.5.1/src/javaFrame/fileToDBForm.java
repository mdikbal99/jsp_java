package javaFrame;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import FileComapre.MainClassFileValidation;
import FileComapre.StringReformat;
import application.Main;
import dataBaseConnection.ConnectToDB2;
import dataBaseConnection.ConnectToHive;
import dataBaseConnection.ConnectToMySqlServer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;

public class fileToDBForm extends Application {

	public static Logger loggerFileToDBForm = LogManager.getLogger(fileToDBForm.class);
	public static String file1path = "";
	public static String file2path = "";
	public static String file3path = "";

	static String pathOfDownloadedFileHIVE1 = null;
	static String pathOfDownloadedFileDB21 = null;
	static String pathOfDownloadedFileSqlServer=null;
	static String dwPathForDB2 = "";

	String dbTypeTextField = "";
	String dbAppName = "";

	boolean Hive1 = false;
	boolean DB21 = false;
	boolean mySqlServer1=false;
	boolean finalHiveFlag = false;
	boolean finalDB2Flag = false;
	boolean finalMySqlServerFlag=false;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void start(Stage primaryStage) throws ConfigurationException {
		Main.defaultResultFolderName = "Result" + StringReformat.currentDateTime();

		final DirectoryChooser dc = new DirectoryChooser();
		final FileChooser fileChooser = new FileChooser();

		primaryStage.setTitle("DVMap - File to Database Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			loggerFileToDBForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);
		// grid.add(child, columnIndex, rowIndex, colspan, rowspan);

		Text scenetitle = new Text(" File to Database Compare OR Database to File Compare");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 1, 0, 2, 1);

		Label file1 = new Label("Source OR Target File Path:");
		file1.setMinWidth(150);
		grid.add(file1, 0, 1);

		TextField file1TextField = new TextField();
		file1TextField.setDisable(true);
		file1TextField.setMinWidth(300);
		file1TextField.setPromptText("(*) mandatory field");
		grid.add(file1TextField, 1, 1);

		Button getFile1 = new Button("Select File");
		HBox hbBtn = new HBox(10);
		getFile1.setMinWidth(200);
		hbBtn.setAlignment(Pos.BOTTOM_LEFT);
		hbBtn.getChildren().add(getFile1);
		grid.add(hbBtn, 2, 1);

		Label file2 = new Label("Choose Connection:");
		file2.setMinWidth(150);
		grid.add(file2, 0, 2);

		ComboBox existingEnvironmentComboBox = new ComboBox();

		Label dbName = new Label("Database Name:");
		grid.add(dbName, 0, 3);

		TextField dbNameTextField = new TextField();
		dbNameTextField.setDisable(true);
		dbNameTextField.setPromptText("(*) mandatory field");
		grid.add(dbNameTextField, 1, 3);

		Label dbPortNo = new Label("Port No:");
		grid.add(dbPortNo, 0, 4);

		TextField dbPortTextField = new TextField();
		dbPortTextField.setDisable(true);
		dbPortTextField.setPromptText("(*) mandatory field");
		grid.add(dbPortTextField, 1, 4);

		Label file21 = new Label("Database Type:");
		file21.setMinWidth(150);
		grid.add(file21, 0, 5);

		ComboBox comboBoxDBType = new ComboBox();
		comboBoxDBType.getItems().add("Hive");
		comboBoxDBType.getItems().add("DB2");
		comboBoxDBType.getItems().add("Oracle");
		comboBoxDBType.getItems().add("MySqlServer");
		comboBoxDBType.setPromptText("Select Database Type");
		comboBoxDBType.setMinWidth(250);
		comboBoxDBType.setDisable(true);
		grid.add(comboBoxDBType, 1, 5);

		PropertiesConfiguration configFile = new PropertiesConfiguration("configureDetails.properties");

		Iterator<String> keys = configFile.getKeys();
		ArrayList<String> keyList = new ArrayList<String>();
		while (keys.hasNext()) {
			keyList.add(keys.next());
		}

		for (String key : keyList) {
			if (key.contains(configFile.getProperty(key) + "HiveAppName")
					|| key.contains(configFile.getProperty(key) + "DB2AppName")
					|| key.contains(configFile.getProperty(key) + "OracleAppName")
					|| key.contains(configFile.getProperty(key) + "MySqlServerAppName")) {
				existingEnvironmentComboBox.getItems().add(configFile.getProperty(key));
			}
		}
		existingEnvironmentComboBox.setPromptText("Select Existing Environment");
		existingEnvironmentComboBox.setMinWidth(250);
		grid.add(existingEnvironmentComboBox, 1, 2);

		existingEnvironmentComboBox.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				Iterator<String> keys = configFile.getKeys();
				ArrayList<String> keyList = new ArrayList<String>();
				while (keys.hasNext()) {
					keyList.add(keys.next());
				}

				for (String key : keyList) {
					if (key.contains(t1 + "HiveAppName")) {
						comboBoxDBType.setValue("Hive");
						dbPortTextField.setText((String) configFile.getProperty(t1 + "HivePortNo"));
						dbNameTextField.setText((String) configFile.getProperty(t1 + "HiveDBName"));
					}
					if (key.contains(t1 + "DB2AppName")) {
						comboBoxDBType.setValue("DB2");
						dbPortTextField.setText((String) configFile.getProperty(t1 + "DB2PortNo"));
						dbNameTextField.setText((String) configFile.getProperty(t1 + "DB2DBName"));
					}
					if (key.contains(t1 + "OracleAppName")) {
						comboBoxDBType.setValue("Oracle");
						dbPortTextField.setText((String) configFile.getProperty(t1 + "OraclePortNo"));
						dbNameTextField.setText((String) configFile.getProperty(t1 + "OracleDBName"));
					}
					if (key.contains(t1 + "MySqlServerAppName")) {
						comboBoxDBType.setValue("MySqlServer");
						dbPortTextField.setText((String) configFile.getProperty(t1 + "MySqlServerPortNo"));
						dbNameTextField.setText((String) configFile.getProperty(t1 + "MySqlServerDBName"));
					}
				}

				dbAppName = t1;
				System.out.println(t1);
			}
		});

		Label dataSheet = new Label("Target OR Source Database Query:");
		dataSheet.setMinWidth(150);
		grid.add(dataSheet, 0, 6);

		TextField dbQueryTextField = new TextField();
		dbQueryTextField.setPrefWidth(300);
		dbQueryTextField.setPrefHeight(100);
		dbQueryTextField.setPromptText("(*) mandatory field");
		grid.add(dbQueryTextField, 1, 6, 1, 3);

		ComboBox comboBoxTableName = new ComboBox();
		comboBoxTableName.setMinWidth(250);
		comboBoxTableName.setPromptText("Select Table Name");
		PropertiesConfiguration tableConfigFile = new PropertiesConfiguration("tableDetails.properties");

		Iterator<String> tableKeys = tableConfigFile.getKeys();
		ArrayList<String> tableKeyList = new ArrayList<String>();
		while (tableKeys.hasNext()) {
			tableKeyList.add(tableKeys.next());
		}

		for (String key : tableKeyList) {
			comboBoxTableName.getItems().add(tableConfigFile.getProperty(key));
		}
		grid.add(comboBoxTableName, 2, 6);

		comboBoxTableName.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				if (t1 != null) {
					dbQueryTextField.setText("SELECT * FROM " + t1);
				}
				System.out.println(t1);
			}
		});

		comboBoxDBType.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue ov, String t, String t1) {
				dbTypeTextField = t1;
				System.out.println(t1);

			}
		});

		Button btnGetColumn = new Button("Get Column Name");
		HBox hbBtnGetColumn = new HBox(10);
		btnGetColumn.setMinWidth(200);
		btnGetColumn.setTextFill(Color.DARKBLUE);
		hbBtnGetColumn.setAlignment(Pos.BOTTOM_LEFT);
		hbBtnGetColumn.getChildren().add(btnGetColumn);
		grid.add(hbBtnGetColumn, 2, 7);

		Button btnClear = new Button("Clear Query");
		HBox hbBtnClear = new HBox(10);
		btnClear.setMinWidth(200);
		hbBtnClear.setAlignment(Pos.BOTTOM_LEFT);
		hbBtnClear.getChildren().add(btnClear);
		grid.add(hbBtnClear, 2, 8);

		Label dataSheet1 = new Label("Mapping Sheet Path:");
		dataSheet1.setMinWidth(150);
		grid.add(dataSheet1, 0, 9);

		TextField dsTextField1 = new TextField();
		dsTextField1.setDisable(true);
		dsTextField1.setMinWidth(300);
		dsTextField1.setPromptText("(*) mandatory field");
		grid.add(dsTextField1, 1, 9);

		Button getFile3 = new Button("Select Mapping Sheet");
		HBox hbBtn3 = new HBox(10);
		getFile3.setMinWidth(200);
		hbBtn3.setAlignment(Pos.BOTTOM_LEFT);
		hbBtn3.getChildren().add(getFile3);
		grid.add(hbBtn3, 2, 9);

		Label resultName = new Label("Test Name:");
		grid.add(resultName, 0, 10);

		TextField resultNameTextField = new TextField(Main.defaultResultFolderName);
		resultNameTextField.setMinWidth(300);
		resultNameTextField.setPromptText("(*) mandatory field");
		grid.add(resultNameTextField, 1, 10);

		Label resultPath = new Label("Result Folder Path:");
		grid.add(resultPath, 0, 11);

		TextField resultTextField = new TextField(Main.defaultSavedPath + Main.defaultResultFolderName);
		resultTextField.setMinWidth(300);
		resultTextField.setDisable(true);
		grid.add(resultTextField, 1, 11);

		Button getResultPath = new Button("Choose Folder");
		HBox hbResultPath = new HBox(10);
		getResultPath.setMinWidth(150);
		hbResultPath.setAlignment(Pos.BOTTOM_LEFT);
		hbResultPath.getChildren().add(getResultPath);
		grid.add(hbResultPath, 2, 11);

		Button btn = new Button("Back to Select Option");
		btn.setMinWidth(150);
		btn.setMinHeight(35);
		btn.setTextFill(Color.DARKBLUE);
		btn.setTextAlignment(TextAlignment.CENTER);
		btn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		grid.add(btn, 0, 13);

		Button btn1 = new Button("Start Compare");
		btn1.setMinWidth(150);
		btn1.setMinHeight(35);
		btn1.setTextFill(Color.DARKBLUE);
		btn1.setTextAlignment(TextAlignment.CENTER);
		btn1.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		grid.add(btn1, 2, 13);

		PropertiesConfiguration configFile1 = new PropertiesConfiguration("filePathDetails.properties");

		getFile1.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				try {
					configureFileChooser(fileChooser);
					File file = fileChooser.showOpenDialog(primaryStage);
					file1path = file.toString();
					System.out.println("File 1 Path: " + file1path);
					file1TextField.setText(file1path);
					configFile1.setProperty("file1Path", file1path);
					configFile1.save();
				} catch (Exception e1) {
					loggerFileToDBForm.error("ConfigurationException in filePathDetails.properties", e1);
					e1.printStackTrace();
				}
			}
		});

		getFile3.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				try {
	
					Task<Void> task = new Task<Void>() {
						@Override
						protected Void call() throws Exception {
						
							return null;
						}
					};
					task.setOnSucceeded(eTask -> {
						ButtonType cnclBtn = new ButtonType("Cancel", ButtonBar.ButtonData.OK_DONE);
						ButtonType yesBtn = new ButtonType("YES", ButtonBar.ButtonData.NEXT_FORWARD);
						ButtonType noBtn = new ButtonType("NO", ButtonBar.ButtonData.NEXT_FORWARD);

						Alert alert2 = new Alert(AlertType.INFORMATION, "", noBtn, yesBtn, cnclBtn);
						alert2.setTitle("Option: Maping Sheet");
						alert2.setHeaderText("Do you have Maping Sheet?");
						alert2.setContentText("Click 'YES' to select Maping sheet \nClick 'NO' to prepare Maping sheet");
						
						outer: while (true) {
							Optional<ButtonType> result = alert2.showAndWait();

							if (result.orElse(cnclBtn) == yesBtn) {
								try {
									configureFileChooser(fileChooser);
									File file = fileChooser.showOpenDialog(primaryStage);
									file3path = file.toString();
									System.out.println("Data Sheet Path: " + file3path);
									dsTextField1.setText(file3path);
									configFile1.setProperty("datasheetPath", file3path);
									configFile1.save();
								} catch (Exception e1) {

								}
														
								break outer;
							} else if (result.get() == noBtn) {
								System.out.println("Creating Source Maping");
								try {
									alert2.close();
									SourceTableView stv= new SourceTableView();
				                     stv.start(primaryStage);
									break outer;
								} catch (Exception e1) {
									e1.printStackTrace();
								}
							} else {
								try {
									dbToDBForm of = new dbToDBForm();
									of.start(primaryStage);
								} catch (ConfigurationException e1) {
									e1.printStackTrace();
								}
								break outer;
							}
						}
					});

					new Thread(task).start();
					
                     
					
				} catch (Exception e1) {
					loggerFileToDBForm.error("Maping sheet prepare Exception", e1);
					e1.printStackTrace();
				}
			}
		});

		btnGetColumn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				Alert alert = new Alert(AlertType.ERROR);
				if (existingEnvironmentComboBox.getSelectionModel().isEmpty()
						|| comboBoxDBType.getSelectionModel().isEmpty() || dbQueryTextField.getText() == null
						|| dbQueryTextField.getText().trim().isEmpty() || dbNameTextField.getText() == null
						|| dbNameTextField.getText().trim().isEmpty() || dbPortTextField.getText() == null
						|| dbPortTextField.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerFileToDBForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					String AppName = dbAppName;
					String dbType = dbTypeTextField;
					String SQLQuery = dbQueryTextField.getText();

					try {
						Task<Void> task1 = new Task<Void>() {
							@Override
							protected Void call() throws Exception {
								if (dbType.equalsIgnoreCase("hive")) {
									finalHiveFlag = ConnectToHive.getColumnNameHive(AppName, dbType, SQLQuery);
									System.out.println("finalHiveFlag: " + finalHiveFlag);
									if (!finalHiveFlag) {
										if (ConnectToHive.hiveDriverError) {
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in Hive Database Configuration OR Hive Query is Wrong!");
													loggerFileToDBForm.info(
															"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToHive.hiveQueryError && ConnectToHive.hiveConnectionError) {
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in Hive Database Configuration OR Hive Query is Wrong!");
														loggerFileToDBForm.info(
																"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
									
								} else if (dbType.equalsIgnoreCase("db2")) {
									finalDB2Flag = ConnectToDB2.getColumnNameDB2(AppName, dbType, SQLQuery);
									System.out.println("finalDB2Flag: " + finalDB2Flag);
									if (!finalDB2Flag) {
										if (ConnectToDB2.db2DriverError) {
											Platform.runLater(new Runnable() {

												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													loggerFileToDBForm.info(
															"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
										} else {
											if (ConnectToDB2.db2QueryError && ConnectToDB2.db2ConnectionError) {
//												btn1.setDisable(false);
//												finalDB2Flag = false;
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														loggerFileToDBForm.info(
																"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
								}else if (dbType.equalsIgnoreCase("MySqlServer")) {
									finalMySqlServerFlag=ConnectToMySqlServer.getColumnNameMySqlServer(AppName, dbType, SQLQuery);
									System.out.println("finalMySqlServerFlag : " + finalMySqlServerFlag);
									if(!finalMySqlServerFlag) {
										if(ConnectToMySqlServer.mySqlServerDriverError) {
											Platform.runLater(new Runnable() {
												@Override
												public void run() {
													alert.setTitle("Run Time Error");
													alert.setHeaderText(
															"Error in MySqlServer  Configuration OR DB2 Query is Wrong!");
													loggerFileToDBForm.info(
															"Run Time Error: Error in MySqlServer Configuration OR DB2 Query is Wrong!");
													alert.setContentText("");
													((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
															.add(new Image("file:Logo.png"));
													alert.showAndWait();
												}
											});
											
										}else {
											if(ConnectToMySqlServer.mySqlServerQueryError && ConnectToMySqlServer.mySqlServerConnectionError) {
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														loggerFileToDBForm.info(
																"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											}
										}
									}
								}
								return null;
							}
						};

						task1.setOnSucceeded(eTask1 -> {

					        	if (finalHiveFlag) {
									HiveTableColumnForm hive = new HiveTableColumnForm();
									hive.open();
								}
								if (finalDB2Flag) {
									DB2TableColumnForm db2 = new DB2TableColumnForm();
									db2.open();

								}
								if(finalMySqlServerFlag) {
									MySqlServerTableColumnForm mysqlServerObj= new MySqlServerTableColumnForm();
									mysqlServerObj.open();
								}
							
						});
						new Thread(task1).start();

					} catch (Exception e1) {
						loggerFileToDBForm.error("Error", e1);
						e1.printStackTrace();
					}
				}
			}
		});

		btnClear.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				dbQueryTextField.clear();
				comboBoxTableName.getSelectionModel().clearSelection();
			}
		});

		getResultPath.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				configureFolderChooser(dc);
				File folder = dc.showDialog(primaryStage);
				Main.defaultSavedPath = folder.toString() + "\\";
				Main.defaultResultFolderName = resultNameTextField.getText() + "\\";
				System.out.println("Result Folder Path: " + Main.defaultSavedPath + Main.defaultResultFolderName);
				resultTextField.setText(Main.defaultSavedPath + Main.defaultResultFolderName);

			}
		});

		btn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are back in Main Menu!");
				optionForm oppage = new optionForm();
				oppage.start(primaryStage);
			}
		});

		btn1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				Alert alert = new Alert(AlertType.ERROR);
				if (file1TextField.getText() == null || file1TextField.getText().trim().isEmpty()
						|| existingEnvironmentComboBox.getSelectionModel().isEmpty()
						|| comboBoxDBType.getSelectionModel().isEmpty()
						|| dsTextField1.getText().trim().isEmpty() || dbQueryTextField.getText() == null
						|| dbQueryTextField.getText().trim().isEmpty() || resultTextField.getText() == null
						|| resultTextField.getText().trim().isEmpty() || dbNameTextField.getText() == null
						|| dbNameTextField.getText().trim().isEmpty() || dbPortTextField.getText() == null
						|| dbPortTextField.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerFileToDBForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					
					Main.defaultResultFolderName = resultNameTextField.getText() + "\\";
					resultTextField.setText(Main.defaultSavedPath + Main.defaultResultFolderName);

					String defaultFolderpath = Main.defaultSavedPath + Main.defaultResultFolderName;
					File file1 = new File(defaultFolderpath);
					System.out.println("defaultFolderpath: " + file1.getAbsolutePath());
					if (file1.exists()) {
						Alert alert1 = new Alert(AlertType.ERROR);
						alert1.setTitle("Run Time Error");
						alert1.setHeaderText("Folder is already present in directory!");
						loggerFileToDBForm.info("Run Time Error: Folder is already present in directory!");
						alert1.setContentText("");
						((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
								.add(new Image("file:Logo.png"));
						alert1.showAndWait();
					} else {
						btn1.setDisable(true);
						try {
							pathOfDownloadedFileHIVE1 = ConnectToHive.downloadFilePathForHive() + "FileHive1.txt";
							pathOfDownloadedFileDB21 = ConnectToDB2.downloadedPathDB2() + "FileDB21.txt";
							pathOfDownloadedFileSqlServer=ConnectToMySqlServer.downloadedPathMySqlServer()+"FileMySqlServer1.txt";
							String dbType = dbTypeTextField;
							if (dbType.equalsIgnoreCase("hive")) {
								configFile1.setProperty("file2Path", pathOfDownloadedFileHIVE1);
								configFile1.save();
							}
							if (dbType.equalsIgnoreCase("db2")) {
								configFile1.setProperty("file2Path", pathOfDownloadedFileDB21);
								configFile1.save();
							}
							if(dbType.equalsIgnoreCase("MySqlServer")) {
								configFile1.setProperty("file2Path", pathOfDownloadedFileSqlServer);
								configFile1.save();
							}
							configFile1.setProperty("defaultResultFolderName", Main.defaultResultFolderName);
							configFile1.setProperty("defaultResultFolderPath", Main.defaultSavedPath);
							configFile1.save();
						} catch (Exception e3) {
							loggerFileToDBForm.error("ConfigurationException in filePathDetails.properties", e3);
							e3.printStackTrace();
						}

						String AppName = dbAppName;
						String dbType = dbTypeTextField;
						String SQLQuery = dbQueryTextField.getText();

						try {
							String detailFileName = Main.defaultSavedPath + Main.defaultResultFolderName
									+ "Details.txt";
							File file = new File(detailFileName);
							file.getParentFile().mkdir();
							System.out.println("Final filepath : " + file.getAbsolutePath());
							if (!file.exists()) {
								file.createNewFile();
								System.out.println("Details File is created!");
							}

							FileWriter fw = new FileWriter(file, true);
							BufferedWriter bw = new BufferedWriter(fw);
							PrintWriter out = new PrintWriter(bw);

							out.println("Source File Path	: " + file1path);
							out.println("Destination Database Query	: " + SQLQuery);
							out.println("Datasheet File Path	: " + file3path);
							out.println("Result Folder Path	: " + Main.defaultSavedPath + Main.defaultResultFolderName);
							out.close();
							bw.close();
							fw.close();
						} catch (Exception e1) {
							loggerFileToDBForm.error("IOException in Details.txt", e1);
							e1.printStackTrace();
						}

						try {
							Alert alert1 = new Alert(AlertType.INFORMATION);
							alert1.setTitle("Database Extract Processing");
							alert1.setHeaderText("");
							alert1.setContentText("Database Extract in Process");
							((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
							loggerFileToDBForm.info("Database Extract Processing: Database Extract in Process");
							alert1.show();

							Task<Void> task1 = new Task<Void>() {
								@Override
								protected Void call() throws Exception {
									if (dbType.equalsIgnoreCase("hive")) {
										finalHiveFlag = ConnectToHive.runConnectToHive(AppName, dbType, SQLQuery,
												pathOfDownloadedFileHIVE1);
										if (!finalHiveFlag) {
											if (ConnectToHive.hiveDriverError) {
												btn1.setDisable(false);
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert1.close();
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in Hive Database Configuration OR Hive Query is Wrong!");
														loggerFileToDBForm.info(
																"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											} else {
												if (ConnectToHive.hiveQueryError && ConnectToHive.hiveConnectionError) {
													btn1.setDisable(false);
													Platform.runLater(new Runnable() {

														@Override
														public void run() {
															alert1.close();
															alert.setTitle("Run Time Error");
															alert.setHeaderText(
																	"Error in Hive Database Configuration OR Hive Query is Wrong!");
															loggerFileToDBForm.info(
																	"Run Time Error: Error in Hive Database Configuration OR Hive Query is Wrong!");
															alert.setContentText("");
															((Stage) alert.getDialogPane().getScene().getWindow())
																	.getIcons().add(new Image("file:Logo.png"));
															alert.showAndWait();
														}
													});
												}
											}
										}
									} else if (dbType.equalsIgnoreCase("db2")) {
										finalDB2Flag = ConnectToDB2.runConnetDB2(AppName, dbType, SQLQuery,
												pathOfDownloadedFileDB21);
										if (!finalDB2Flag) {
											if (ConnectToDB2.db2DriverError) {
												btn1.setDisable(false);
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert1.close();
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														loggerFileToDBForm.info(
																"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
											} else {
												if (ConnectToDB2.db2QueryError && ConnectToDB2.db2ConnectionError) {
													btn1.setDisable(false);
													Platform.runLater(new Runnable() {

														@Override
														public void run() {
															alert1.close();
															alert.setTitle("Run Time Error");
															alert.setHeaderText(
																	"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
															loggerFileToDBForm.info(
																	"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
															alert.setContentText("");
															((Stage) alert.getDialogPane().getScene().getWindow())
																	.getIcons().add(new Image("file:Logo.png"));
															alert.showAndWait();
														}
													});
												}
											}
										}
									}else if (dbType.equalsIgnoreCase("MySqlServer")) {
										finalMySqlServerFlag=ConnectToMySqlServer.runConnetmySqlServer(AppName, dbType, SQLQuery, pathOfDownloadedFileSqlServer);
										if(!finalMySqlServerFlag) {
											if(ConnectToMySqlServer.mySqlServerDriverError) {
												Platform.runLater(new Runnable() {

													@Override
													public void run() {
														alert.setTitle("Run Time Error");
														alert.setHeaderText(
																"Error in MySqlServer  Configuration OR DB2 Query is Wrong!");
														loggerFileToDBForm.info(
																"Run Time Error: Error in MySqlServer Configuration OR DB2 Query is Wrong!");
														alert.setContentText("");
														((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																.add(new Image("file:Logo.png"));
														alert.showAndWait();
													}
												});
												
											}else {
												if(ConnectToMySqlServer.mySqlServerQueryError && ConnectToMySqlServer.mySqlServerConnectionError) {
													Platform.runLater(new Runnable() {

														@Override
														public void run() {
															alert.setTitle("Run Time Error");
															alert.setHeaderText(
																	"Error in DB2 Database Configuration OR DB2 Query is Wrong!");
															loggerFileToDBForm.info(
																	"Run Time Error: Error in DB2 Database Configuration OR DB2 Query is Wrong!");
															alert.setContentText("");
															((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
																	.add(new Image("file:Logo.png"));
															alert.showAndWait();
														}
													});
												}
											}
										}
									}
									return null;
								}
							};

							task1.setOnSucceeded(eTask1 -> {
								alert1.close();
								if (finalHiveFlag || finalDB2Flag||finalMySqlServerFlag) {
									alert1.close();
									Alert alert2 = new Alert(AlertType.INFORMATION);
									alert2.setTitle("Validating");
									Image image = null;
									try {
										image = new Image(new FileInputStream("8yxqez.gif"));
									} catch (Exception e2) {
										loggerFileToDBForm.error("FileNotFoundException: 8yxqez.gif is NOT FOUND!", e2);
										e2.printStackTrace();
									}
									ImageView imageView = new ImageView(image);
									imageView.setFitHeight(100);
									imageView.setFitWidth(100);
									alert2.setGraphic(imageView);
									((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons()
											.add(new Image("file:Logo.png"));
									alert2.setHeaderText("Validating both files!");
									alert2.setContentText("Validating in process");
									loggerFileToDBForm.info("Validating: Validating both files: Validating in process");
									alert2.show();

									File toMakeDefaultResultPath = new File(
											Main.defaultSavedPath + Main.defaultResultFolderName);
									toMakeDefaultResultPath.mkdirs();

									Task<Void> task2 = new Task<Void>() {
										@Override
										protected Void call() throws Exception {
											try {
												MainClassFileValidation.mainMethodForFileCompare();
												MainClassFileValidation.sourceRecordCount = 0;
												MainClassFileValidation.targetRecordCount = 0;

											} catch (Exception e) {
												loggerFileToDBForm.error(
														"IOException in MainClassFileValidation.mainMethodForFileCompare()",
														e);
												e.printStackTrace();
											}
											return null;
										}
									};
									task2.setOnSucceeded(eTask2 -> {
										alert2.close();
										ButtonType okBtn = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
										ButtonType analyzeBtn = new ButtonType("Analyze",
												ButtonBar.ButtonData.NEXT_FORWARD);
										ButtonType resultBtn = new ButtonType("Result",
												ButtonBar.ButtonData.NEXT_FORWARD);
										Alert alert3 = new Alert(AlertType.INFORMATION, "", resultBtn, analyzeBtn,
												okBtn);
										alert3.setTitle("Validation Result");
										alert3.setHeaderText("Validation Successfully Completed!");
										loggerFileToDBForm
												.info("Validation Result: Validation Successfully Completed!");
										alert3.setContentText("Please, Check " + Main.defaultSavedPath
												+ Main.defaultResultFolderName + " Folder for Result");
										((Stage) alert3.getDialogPane().getScene().getWindow()).getIcons()
												.add(new Image("file:Logo.png"));

										outer: while (true) {
											Optional<ButtonType> result = alert3.showAndWait();

											if (result.orElse(okBtn) == analyzeBtn) {
												AnalysisForm aof = new AnalysisForm();
												aof.start(primaryStage);
												System.out.println("Analyze");
												break outer;
											} else if (result.get() == resultBtn) {
												System.out.println("Result");
												try {
													Desktop.getDesktop().open(new File(
															Main.defaultSavedPath + Main.defaultResultFolderName));
													continue outer;
												} catch (Exception e1) {
													loggerFileToDBForm.error(
															"IOException in Desktop.getDesktop().open(new File(Main.defaultSavedPath + Main.defaultResultFolderName))",
															e1);
													e1.printStackTrace();
												}
											} else {
												optionForm of = new optionForm();
												of.start(primaryStage);
												break outer;
											}
										}
									});
									new Thread(task2).start();
								}
							});
							new Thread(task1).start();

						} catch (Exception e1) {
							loggerFileToDBForm.error("Error", e1);
							e1.printStackTrace();
						}
					}
				}
			}
		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				event.consume();

				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerFileToDBForm.info("FileToDBForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 850, 650);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
		primaryStage.setFullScreen(true);
	}

	private static void configureFolderChooser(final DirectoryChooser dc) {
		dc.setTitle("Folder Chooser");
		dc.setInitialDirectory(new File(System.getProperty("user.home")));
	}

	private static void configureFileChooser(final FileChooser fileChooser) {
		fileChooser.setTitle("File Chooser");
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Images", "*.*"));
	}
}
