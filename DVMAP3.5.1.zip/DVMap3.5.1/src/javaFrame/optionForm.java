package javaFrame;

import java.io.FileInputStream;
import java.util.Optional;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import application.Main;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.stage.PopupWindow;

public class optionForm extends Application {

	public static Logger loggerOptionForm = LogManager.getLogger(optionForm.class);
	
	private static final String SQUARE_BUBBLE = "M24 1h-24v16.981h4v5.019l7-5.019h13z";

	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("DVMap - Option Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(0, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerOptionForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);

		Text scenetitle = new Text(" Select Option");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 2, 0, 2, 1);

		Button fileToFile = new Button("File to File\n" + "Compare");
		HBox hbBtn1 = new HBox(10);
		fileToFile.setMinWidth(150);
		fileToFile.setMinHeight(35);
		fileToFile.setTextFill(Color.DARKBLUE);
		fileToFile.setTextAlignment(TextAlignment.CENTER);
		fileToFile.setFont(Font.font("Tahoma", FontWeight.NORMAL, 13));
		fileToFile.setTooltip(makeBubble(new Tooltip("To Validate two Files (CSV/Pipe Delimeted/Offset Type)")));
		hbBtn1.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn1.getChildren().add(fileToFile);
		grid.add(fileToFile, 2, 2);

		Button dbToDB = new Button("Database to Database\n" + "Compare");
		HBox hbBtn3 = new HBox(10);
		dbToDB.setMinWidth(150);
		dbToDB.setMinHeight(35);
		dbToDB.setTextFill(Color.DARKBLUE);
		dbToDB.setTextAlignment(TextAlignment.CENTER);
		dbToDB.setFont(Font.font("Tahoma", FontWeight.NORMAL, 13));
		dbToDB.setTooltip(makeBubble(new Tooltip("To Validate a Structured Data between two Database (CSV/Pipe Delimeted/Offset Type)")));
		hbBtn3.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn3.getChildren().add(dbToDB);
		grid.add(dbToDB, 2, 3);

		Button fileToDB = new Button("File to Database\n" + "Compare");
		HBox hbBtn2 = new HBox(10);
		fileToDB.setMinWidth(150);
		fileToDB.setMinHeight(35);
		fileToDB.setTextFill(Color.DARKBLUE);
		fileToDB.setTextAlignment(TextAlignment.CENTER);
		fileToDB.setFont(Font.font("Tahoma", FontWeight.NORMAL, 13));
		fileToDB.setTooltip(makeBubble(new Tooltip("To Validate a File (CSV/Pipe Delimeted/Offset Type) with a Structured Data from Database")));
		hbBtn2.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn2.getChildren().add(fileToDB);
		grid.add(fileToDB, 2, 4);

		Button dbConfig = new Button("Database Configuration");
		HBox hbBtn5 = new HBox(10);
		dbConfig.setMinWidth(150);
		dbConfig.setMinHeight(30);
		dbConfig.setTooltip(makeBubble(new Tooltip("To Connect to Database, Configure the details!")));
		hbBtn5.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn5.getChildren().add(dbConfig);
		grid.add(dbConfig, 1, 5);
		
		if (Main.isAdmin || Main.isAdministrator) {
			Button adminBtn = new Button("DVMap Administration");
			HBox hbBtn41 = new HBox(10);
			adminBtn.setMinWidth(150);
			adminBtn.setMinHeight(30);
			adminBtn.setTextFill(Color.DARKGREEN);
			adminBtn.setTooltip(makeBubble(new Tooltip("To do System Administration!")));
			hbBtn41.setAlignment(Pos.BOTTOM_CENTER);
			hbBtn41.getChildren().add(adminBtn);
			grid.add(adminBtn, 2, 5);
			
			adminBtn.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent e) {
					System.out.println("You are in Administration Page!");
					AdminForm af = new AdminForm();
					af.start(primaryStage);
				}
			});
		}
		Button analyzeBtn = new Button("Result Analysis");
		HBox hbBtn4 = new HBox(10);
		analyzeBtn.setMinWidth(150);
		analyzeBtn.setMinHeight(30);
		analyzeBtn.setTooltip(makeBubble(new Tooltip("To get Analysis Result!")));
		hbBtn4.setAlignment(Pos.BOTTOM_CENTER);
		hbBtn4.getChildren().add(analyzeBtn);
		grid.add(analyzeBtn, 3, 5);
		


//		final Text actiontarget = new Text();
//		grid.add(actiontarget, 0, 6);

		fileToFile.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are in File to File!");
				fileToFileForm ftfpage = new fileToFileForm();
				try {
					ftfpage.start(primaryStage);
					
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					loggerOptionForm.error("ConfigurationException in ftfpage.start(primaryStage)", e1);
					e1.printStackTrace();
				}
			}
		});

		fileToDB.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are in File to Database!");
				fileToDBForm ftdpage = new fileToDBForm();
				try {
					ftdpage.start(primaryStage);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					loggerOptionForm.error("ConfigurationException in ftdpage.start(primaryStage)", e1);
					e1.printStackTrace();
				}
			}
		});

		dbToDB.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are in Database to Database!");
				dbToDBForm dtdpage = new dbToDBForm();
				try {
					dtdpage.start(primaryStage);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					loggerOptionForm.error("ConfigurationException in dtdpage.start(primaryStage)", e1);
					e1.printStackTrace();
				}
			}
		});

		analyzeBtn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are in Analysis Result!");
				AnalysisForm aof = new AnalysisForm();
				aof.start(primaryStage);
			}
		});

		dbConfig.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are in Database Configuration!");
				configureForm congpage = new configureForm();
				congpage.start(primaryStage);
			}
		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				// consume event
				event.consume();

				// show close dialog
				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					//ArchiveExistingFolder.archiveFolderGenarate();
					loggerOptionForm.info("OptionForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 600, 400);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
	}

	private Tooltip makeBubble(Tooltip tooltip) {
		tooltip.setStyle("-fx-font-size: 16px; -fx-shape: \"" + SQUARE_BUBBLE + "\";");
		tooltip.setAnchorLocation(PopupWindow.AnchorLocation.WINDOW_BOTTOM_LEFT);
		return tooltip;
	}
}
