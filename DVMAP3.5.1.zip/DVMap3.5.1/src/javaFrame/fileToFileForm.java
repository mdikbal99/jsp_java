
package javaFrame;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Optional;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import FileComapre.MainClassFileValidation;
import FileComapre.StringReformat;
import application.Main;
import javafx.application.Application;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class fileToFileForm extends Application {

	public static Logger loggerFileToFileForm = LogManager.getLogger(fileToFileForm.class);

	public static String file1path = "";
	public static String file2path = "";
	public static String file3path = "";

//	static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("_yyyy-MM-dd_HH-mm-ss");  
//	static LocalDateTime now = LocalDateTime.now();

	@Override
	public void start(Stage primaryStage) throws ConfigurationException {

		
		
		PropertiesConfiguration configFile1 = new PropertiesConfiguration("filePathDetails.properties");
		final DirectoryChooser dc = new DirectoryChooser();
		final FileChooser fileChooser = new FileChooser();
		
		Main.defaultResultFolderName = "Result" + StringReformat.currentDateTime();
		Main.defaultSavedPath=(String) configFile1.getProperty("defaultResultFolderPath");

		primaryStage.setTitle("DVMap - File to File Form");
		primaryStage.getIcons().add(new Image("file:Logo.png"));
		GridPane grid = new GridPane();
		grid.setStyle("-fx-background-color: #D9F8FF;");
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Image image = null;
		try {
			image = new Image(new FileInputStream("Logo.png"));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			loggerFileToFileForm.error("FileNotFoundException: Logo.png is NOT FOUND!", e2);
			e2.printStackTrace();
		}
		Label imgLabel = new Label();
		ImageView imageView = new ImageView(image);
		imageView.autosize();
		imgLabel.setGraphic(imageView);
		grid.add(imgLabel, 0, 0, 2, 1);
		// grid.add(child, columnIndex, rowIndex, colspan, rowspan);

		Text scenetitle = new Text(" File to File Compare");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 1, 0, 2, 1);

		Label dataSheet = new Label("Mapping Sheet Path:");
		grid.add(dataSheet, 0, 1);

		TextField dsTextField = new TextField();
		dsTextField.setDisable(true);
		dsTextField.setMinWidth(300);
		dsTextField.setPromptText("(*) mandatory field");
		grid.add(dsTextField, 1, 1);
		file3path=System.getProperty("user.dir")+"\\FileValidationDetails.xls";
		dsTextField.setText(file3path);

		Button getFile3 = new Button("Select Mapping Sheet");
		HBox hbBtn3 = new HBox(10);
		getFile3.setMinWidth(150);
		hbBtn3.setAlignment(Pos.BOTTOM_LEFT);
		hbBtn3.getChildren().add(getFile3);
		grid.add(hbBtn3, 2, 1);
		
		
		
		Label file1 = new Label("Source File Path:");
		grid.add(file1, 0, 2);

		TextField file1TextField = new TextField();
		file1TextField.setDisable(true);
		file1TextField.setMinWidth(300);
		file1TextField.setPromptText("(*) mandatory field");
		grid.add(file1TextField, 1, 2);

		Button getFile1 = new Button("Select File 1");
		HBox hbBtn = new HBox(10);
		getFile1.setMinWidth(150);
		hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn.getChildren().add(getFile1);
		grid.add(hbBtn, 2, 2);

		Label file2 = new Label("Target File Path:");
		grid.add(file2, 0, 3);

		TextField file2TextField = new TextField();
		file2TextField.setDisable(true);
		file2TextField.setMinWidth(300);
		file2TextField.setPromptText("(*) mandatory field");
		grid.add(file2TextField, 1, 3);

		Button getFile2 = new Button("Select File 2");
		HBox hbBtn2 = new HBox(10);
		getFile2.setMinWidth(150);
		hbBtn2.setAlignment(Pos.BOTTOM_RIGHT);
		hbBtn2.getChildren().add(getFile2);
		grid.add(hbBtn2, 2, 3);

	

		Label resultName = new Label("Test Name:");
		grid.add(resultName, 0, 4);

		TextField resultNameTextField = new TextField(Main.defaultResultFolderName);
		resultNameTextField.setMinWidth(300);
		resultNameTextField.setPromptText("(*) mandatory field");
		grid.add(resultNameTextField, 1, 4);

		Label resultPath = new Label("Result Folder Path:");
		grid.add(resultPath, 0, 5);

		TextField resultTextField = new TextField(Main.defaultSavedPath + Main.defaultResultFolderName);
		resultTextField.setMinWidth(300);
		resultTextField.setDisable(true);
		// resultTextField.setPromptText("(*) mandatory field");
		grid.add(resultTextField, 1, 5);

//        Label resultFolderLabel = new Label("Result Folder Path: ");
//        grid.add(resultFolderLabel, 0, 5);

//        Label resultFolderPathLabel = new Label(Main.defaultSavedPath);
//        grid.add(resultFolderPathLabel, 1, 5);

//        Label resultPathWithFolder = new Label();
//        grid.add(resultPathWithFolder, 1, 5);
//        resultPathWithFolder.textProperty().bind(resultTextField.textProperty());

		Button getResultPath = new Button("Choose Folder");
		HBox hbResultPath = new HBox(10);
		getResultPath.setMinWidth(150);
		hbResultPath.setAlignment(Pos.BOTTOM_LEFT);
		hbResultPath.getChildren().add(getResultPath);
		grid.add(hbResultPath, 2, 5);

		Button btn = new Button("Back to Select Option");
//        HBox hbBtn4 = new HBox(10);
//        hbBtn4.setAlignment(Pos.BOTTOM_LEFT);
//        hbBtn4.getChildren().add(btn);
		btn.setMinWidth(150);
		btn.setMinHeight(35);
		btn.setTextFill(Color.DARKBLUE);
		btn.setTextAlignment(TextAlignment.CENTER);
		btn.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		grid.add(btn, 0, 8);

		Button btn1 = new Button("Start Compare");
//        HBox hbBtn41 = new HBox(10);
//        hbBtn41.setAlignment(Pos.BOTTOM_RIGHT);
//        hbBtn41.getChildren().add(btn1);
		btn1.setMinWidth(150);
		btn1.setMinHeight(35);
		btn1.setTextFill(Color.DARKBLUE);
		btn1.setTextAlignment(TextAlignment.CENTER);
		btn1.setFont(Font.font("Tahoma", FontWeight.NORMAL, 14));
		grid.add(btn1, 2, 8);

	

		getFile1.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				try {

					configureFileChooser(fileChooser);
					File file = fileChooser.showOpenDialog(primaryStage);
					file1path = file.toString();
					System.out.println("File 1 Path: " + file1path);
					file1TextField.setText(file1path);
					configFile1.setProperty("file1Path", file1path);
					configFile1.save();
				} catch (Exception e1) {
					// StringWriter sw = new StringWriter();
					// e1.printStackTrace(new PrintWriter(sw));
					loggerFileToFileForm.error("ConfigurationException in filePathDetails.properties", e1);
					// loggerFileToFileForm.error("ERROR", e1);
					// loggerFileToFileForm.log(Level.ERROR, e1.getMessage(), e1);
					e1.printStackTrace();
				}
			}
		});

		getFile2.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				try {
					configureFileChooser(fileChooser);
					File file = fileChooser.showOpenDialog(primaryStage);
					file2path = file.toString();
					System.out.println("File 2 Path: " + file2path);
					file2TextField.setText(file2path);
					configFile1.setProperty("file2Path", file2path);
					configFile1.save();
				} catch (Exception e1) {
					loggerFileToFileForm.error("ConfigurationException in filePathDetails.properties", e1);
					e1.printStackTrace();
				}
			}
		});

		getFile3.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				try {
				/*	configureFileChooser(fileChooser);
					System.out.println("Data Sheet Path: " + file3path);
					configFile1.setProperty("datasheetPath", file3path);
					configFile1.save();
                     SourceTableView stv= new SourceTableView();
                     stv.start(primaryStage);*/
					
                     
				/*	e.consume();
					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Close Confirmation");
					alert.setHeaderText("Press Ok to make Maping sheet else Cancle");
					alert.initOwner(primaryStage);
					Optional<ButtonType> result = alert.showAndWait();
					if (result.get() == ButtonType.OK) {
						loggerFileToFileForm.info("FileToFileForm is Closed by User!");
						 SourceTableView stv= new SourceTableView();
	                     stv.start(primaryStage);
					}*/
					
					
					
					Task<Void> task = new Task<Void>() {
						@Override
						protected Void call() throws Exception {
						
							return null;
						}
					};
					task.setOnSucceeded(eTask -> {
						ButtonType cnclBtn = new ButtonType("Cancel", ButtonBar.ButtonData.OK_DONE);
						ButtonType yesBtn = new ButtonType("YES", ButtonBar.ButtonData.NEXT_FORWARD);
						ButtonType noBtn = new ButtonType("NO", ButtonBar.ButtonData.NEXT_FORWARD);

						Alert alert2 = new Alert(AlertType.INFORMATION, "", noBtn, yesBtn, cnclBtn);
						alert2.setTitle("Option: Maping Sheet");
						alert2.setHeaderText("Do you have Maping Sheet?");
						alert2.setContentText("Click 'YES' to select Maping sheet \nClick 'NO' to prepare Maping sheet");
						
						outer: while (true) {
							Optional<ButtonType> result = alert2.showAndWait();

							if (result.orElse(cnclBtn) == yesBtn) {
								try {
									configureFileChooser(fileChooser);
									File file = fileChooser.showOpenDialog(primaryStage);
									file3path = file.toString();
									System.out.println("Data Sheet Path: " + file3path);
									dsTextField.setText(file3path);
									configFile1.setProperty("datasheetPath", file3path);
									configFile1.save();
								} catch (Exception e1) {

								}
														
								break outer;
							} else if (result.get() == noBtn) {
								System.out.println("Creating Source Table");
								try {
									alert2.close();
									SourceTableView stv= new SourceTableView();
				                     stv.start(primaryStage);
									break outer;
								} catch (Exception e1) {
									loggerFileToFileForm.error(e1);
									e1.printStackTrace();
								}
							} else {
								try {
								fileToFileForm of = new fileToFileForm();
									of.start(primaryStage);
								} catch (ConfigurationException e1) {
									e1.printStackTrace();
								}
								break outer;
							}
						}
					});

					new Thread(task).start();
					
                     
					
				} catch (Exception e1) {
					loggerFileToFileForm.error("ConfigurationException in filePathDetails.properties", e1);
					e1.printStackTrace();
				}
			}
		});

		getResultPath.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				configureFolderChooser(dc);
				File folder = dc.showDialog(primaryStage);
				Main.defaultSavedPath = folder.toString() + "\\";
				Main.defaultResultFolderName = resultNameTextField.getText() + "\\";
				System.out.println("Result Folder Path: " + Main.defaultSavedPath + Main.defaultResultFolderName);
				resultTextField.setText(Main.defaultSavedPath + Main.defaultResultFolderName);
				/*try {
					configFile1.setProperty("defaultResultFolderName", Main.defaultResultFolderName);
					configFile1.setProperty("defaultResultFolderPath", Main.defaultSavedPath);
					configFile1.save();
				} catch (Exception e3) {
					loggerFileToFileForm.error("Exception in chooseing file and saved in filePathDetails.properties", e3);
					e3.printStackTrace();
				}*/
			}
		});

		btn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				System.out.println("You are back in Main Menu!");
				optionForm oppage = new optionForm();
				oppage.start(primaryStage);
			}
		});

		btn1.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				Alert alert = new Alert(AlertType.ERROR);
		
				if (file1TextField.getText() == null || file1TextField.getText().trim().isEmpty()
						|| file2TextField.getText() == null || file2TextField.getText().trim().isEmpty()) {
					alert.setTitle("Run Time Error");
					alert.setHeaderText("Field values are missing!");
					loggerFileToFileForm.info("Run Time Error: Field values are missing!");
					alert.setContentText("");
					((Stage) alert.getDialogPane().getScene().getWindow()).getIcons().add(new Image("file:Logo.png"));
					alert.showAndWait();
				} else {
					
					Main.defaultResultFolderName = resultNameTextField.getText() + "\\";
					resultTextField.setText(Main.defaultSavedPath + Main.defaultResultFolderName);

					String defaultFolderpath = Main.defaultSavedPath + Main.defaultResultFolderName;
					File file1 = new File(defaultFolderpath);
					System.out.println("defaultFolderpath: " + file1.getAbsolutePath());
					if (file1.exists()) {
						Alert alert1 = new Alert(AlertType.ERROR);
						alert1.setTitle("Run Time Error");
						alert1.setHeaderText("Folder is already present in directory!");
						loggerFileToFileForm.info("Run Time Error: Folder is already present in directory!");
						alert1.setContentText("");
						((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
								.add(new Image("file:Logo.png"));
						alert1.showAndWait();
					} else {
						btn1.setDisable(true);
						try {
							configFile1.setProperty("defaultResultFolderName", Main.defaultResultFolderName);
							configFile1.setProperty("defaultResultFolderPath", Main.defaultSavedPath);
							configFile1.save();
						} catch (Exception e3) {
							loggerFileToFileForm.error("ConfigurationException in filePathDetails.properties", e3);
							e3.printStackTrace();
						}

						try {
							String detailFileName = Main.defaultSavedPath + Main.defaultResultFolderName
									+ "Details.txt";
							File file = new File(detailFileName);
							file.getParentFile().mkdir();
							System.out.println("Final filepath : " + file.getAbsolutePath());
							if (!file.exists()) {
								file.createNewFile();
								System.out.println("Details File is created!");
							}

							FileWriter fw = new FileWriter(file, true);
							BufferedWriter bw = new BufferedWriter(fw);
							PrintWriter out = new PrintWriter(bw);

							out.println("Source File Path	: " + file1path);
							out.println("Destination File Path	: " + file2path);
							out.println("Datasheet File Path	: " + file3path);
							out.println("Result Folder Path	: " + Main.defaultSavedPath + Main.defaultResultFolderName);
							out.close();
							bw.close();
							fw.close();
						} catch (Exception e1) {
							loggerFileToFileForm.error("IOException in Details.txt", e1);
							e1.printStackTrace();
						}

						try {
							Alert alert1 = new Alert(AlertType.INFORMATION);
							alert1.setTitle("Validating");

							Image image = null;
							try {
								image = new Image(new FileInputStream("8yxqez.gif"));
							} catch (Exception e2) {
								loggerFileToFileForm.error("FileNotFoundException: 8yxqez.gif is NOT FOUND!", e2);
								e2.printStackTrace();
							}
							ImageView imageView = new ImageView(image);
							imageView.setFitHeight(100);
							imageView.setFitWidth(100);
							alert1.setGraphic(imageView);
							alert1.setHeaderText("Validating both files!");
							alert1.setContentText("Validating in process");
							loggerFileToFileForm.info("Validating: Validating both files: Validating in process");
							((Stage) alert1.getDialogPane().getScene().getWindow()).getIcons()
									.add(new Image("file:Logo.png"));
							alert1.show();

							// Main.defaultResultFolderPath = resultTextField.getText().toString() +
							// dtf.format(now);
							
							//File toMakeDefaultResultPath = new File(Main.defaultSavedPath + Main.defaultResultFolderName);
							//toMakeDefaultResultPath.mkdirs();
							
							Task<Void> task = new Task<Void>() {
								@Override
								protected Void call() throws Exception {
									try {
										MainClassFileValidation.mainMethodForFileCompare();
										MainClassFileValidation.sourceRecordCount = 0;
										MainClassFileValidation.targetRecordCount = 0;
									} catch (Exception e) {
										loggerFileToFileForm.error(
												"IOException in MainClassFileValidation.mainMethodForFileCompare()", e);
										e.printStackTrace();
									}
									return null;
								}
							};
							task.setOnSucceeded(eTask -> {
								System.out.println("Validation Done !!!!!! :) ");
								alert1.close();
								ButtonType okBtn = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
								ButtonType analyzeBtn = new ButtonType("Analyze", ButtonBar.ButtonData.NEXT_FORWARD);
								ButtonType resultBtn = new ButtonType("Result", ButtonBar.ButtonData.NEXT_FORWARD);

								Alert alert2 = new Alert(AlertType.INFORMATION, "", resultBtn, analyzeBtn, okBtn);
								alert2.setTitle("Validation Result");
								alert2.setHeaderText("Validation Successfully Completed!");
								loggerFileToFileForm.info("Validation Result: Validation Successfully Completed!");
								((Stage) alert2.getDialogPane().getScene().getWindow()).getIcons()
										.add(new Image("file:Logo.png"));
								alert2.setContentText("Please, Check " + Main.defaultSavedPath
										+ Main.defaultResultFolderName + " Folder for Result");

								outer: while (true) {
									Optional<ButtonType> result = alert2.showAndWait();

									if (result.orElse(okBtn) == analyzeBtn) {
										AnalysisForm aof = new AnalysisForm();
										aof.start(primaryStage);
										System.out.println("Analyze");
										break outer;
									} else if (result.get() == resultBtn) {
										System.out.println("Result");
										try {
											// Desktop.getDesktop().open(new File(Main.defaultSavedPath +
											// FatchDataFromExcel.fileName(MainClassFileValidation.dataSheetName)));
											Desktop.getDesktop().open(
													new File(Main.defaultSavedPath + Main.defaultResultFolderName));
											continue outer;
										} catch (Exception e1) {
											loggerFileToFileForm.error(
													"IOException in Desktop.getDesktop().open(new File(Main.defaultSavedPath + Main.defaultResultFolderName"
															+ e1);
											e1.printStackTrace();
										}
									} else {
										optionForm of = new optionForm();
										of.start(primaryStage);
										break outer;
									}
								}
							});

							new Thread(task).start();

						} catch (Exception e1) {
							loggerFileToFileForm.error("Error", e1);
							e1.printStackTrace();
						}
					}
				}
			}
		});

		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {

				event.consume();

				Alert alert = new Alert(AlertType.CONFIRMATION);
				alert.setTitle("Close Confirmation");
				alert.setHeaderText("Do you really want to quit?");
				alert.initOwner(primaryStage);

				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {
					loggerFileToFileForm.info("FileToFileForm is Closed by User!");
					System.exit(0);
				}
			}
		});

		Scene scene = new Scene(grid, 700, 400);
		primaryStage.setScene(scene);
		primaryStage.show();
		primaryStage.centerOnScreen();
		//primaryStage.setFullScreen(true);
	}

	private static void configureFolderChooser(final DirectoryChooser dc) {
		dc.setTitle("Folder Chooser");
		dc.setInitialDirectory(new File(System.getProperty("user.home")));
	}

	private static void configureFileChooser(final FileChooser fileChooser) {
		fileChooser.setTitle("File Chooser");
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Images", "*.*"));
	}
}
