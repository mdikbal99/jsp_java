package FileComapre;

import java.util.ArrayList;
import util.MyExcelConnect;

public class TargetOffsetFetch {
	
	
	public static ArrayList<String> primaryKeyOffsetRetriveForTarget(String dataSheetName, String fileType){
		ArrayList<String> listPrimaryKeyoffset = new ArrayList<>();
		MyExcelConnect sh1Target = new MyExcelConnect(dataSheetName, 1);
		
		if(fileType.equalsIgnoreCase("offset")){
			String PreSubStr = null;
			String postSubStr = null;
			int PreSubInt = 0;
			String transLoffT="";
			System.out.println("your target file type is offset delimited");
			for(int i=1;i<=sh1Target.lastrowno()+1;i++){
				if (sh1Target.excelread(i, 4).equalsIgnoreCase("y")) {
					
					PreSubStr = sh1Target.excelread(i, 2);
					PreSubInt = Integer.parseInt(PreSubStr);
					PreSubInt = PreSubInt - 1;

					postSubStr = sh1Target.excelread(i, 5);
					
					if(sh1Target.excelread(i, 6)==null||sh1Target.excelread(i, 6)==""||sh1Target.excelread(i, 6).isEmpty()) {
						transLoffT="NO_TL_LOGICS";
					}else
						transLoffT=sh1Target.excelread(i, 6);
					
					String offsetCount=String.valueOf(PreSubInt)+","+postSubStr+"*"+transLoffT;
				listPrimaryKeyoffset.add(offsetCount);
				}
					
				}
			}
		
		
		if (fileType.equalsIgnoreCase("comma")||fileType.equalsIgnoreCase("pipe")) {
			System.out.println("your target file is comma/pipe seperated");

			String pkoffSet="";
			String transLT="";
				for (int j = 2; j <= sh1Target.lastrowno()+1; j++) {
					if (sh1Target.excelread(j, 4).equalsIgnoreCase("y")) {
						pkoffSet = sh1Target.excelread(j, 2);
					//	r = Integer.parseInt(pkoffSet);
						String offsetCount=pkoffSet;
						
						
						if(sh1Target.excelread(j, 6)==null||sh1Target.excelread(j, 6)==""||sh1Target.excelread(j, 6).isEmpty()) {
							transLT="NO_TL_LOGICS";
						}else
							transLT=sh1Target.excelread(j, 6);
						
						listPrimaryKeyoffset.add(offsetCount+"*"+transLT);
					}

			
				}
			}
		
		
		listPrimaryKeyoffset.trimToSize();
		return listPrimaryKeyoffset;
		
	}
	

}
