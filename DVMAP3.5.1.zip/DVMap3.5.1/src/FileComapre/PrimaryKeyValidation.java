package FileComapre;

import java.util.ArrayList;
import java.util.List;

public class PrimaryKeyValidation extends MainClassFileValidation {

	static int executionCount=1;
	public static void validatePrimaryKey(List<String> primaryKeyOffsetRetriveForSouce,
			List<String> primaryKeyOffsetRetriveForTarget, String validationType, String fileName,
			String sourceFilePath, String targetFilePath, String fileTypeForSouce, String fileTypeForTarget) {
		
		ArrayList<String> sourceListPrimary = new ArrayList<>();
		ArrayList<String> targetListPrimary = new ArrayList<>();
		
		try {
			if (count > 1000000) {
				
				CreateSourceListClass createSourceList = new CreateSourceListClass();
			    Thread thread1 = new Thread(createSourceList);
				thread1.start();
				
				System.out.println("PrimaryKeyValidation -> CreateSourceListClass");
				sourceListPrimary = CreateSourceListClass.makingSourceList(primaryKeyOffsetRetriveForSouce,fileTypeForSouce);
				System.out.println("Source List Primary end");
				sourceListPrimary.trimToSize();
				
		
		        
				CreateTargetListClass createTargetList = new CreateTargetListClass();
			    Thread thread2 = new Thread(createTargetList);
			    thread2.start();
		        
			    System.out.println("PrimaryKeyValidation -> CreateTargetListClass");
				targetListPrimary = CreateTargetListClass.makingTargetList(primaryKeyOffsetRetriveForTarget,fileTypeForTarget);
				System.out.println("Target ListPrimary End ");
				targetListPrimary.trimToSize();
				
				
				
				System.out.println("Comparing data  "+executionCount+" and generating match unMatch files......");
				executionCount=executionCount+1;
				Runtime.getRuntime().gc();
			
				Compare.compareLists(sourceListPrimary, targetListPrimary, validationType, fileName);
				
				
				sourceListPrimary.clear();
				targetListPrimary.clear();
				
                System.out.println("String comparision end............");
			}

			else {
				
				sourceListPrimary = StringForSource.sourceString(primaryKeyOffsetRetriveForSouce, sourceFilePath,fileTypeForSouce);
				//primaryKeyOffsetRetriveForSouce.clear();
				targetListPrimary = StringForTarget.targetString(primaryKeyOffsetRetriveForTarget, targetFilePath,fileTypeForTarget);
				//primaryKeyOffsetRetriveForTarget.clear();
				
			
				sourceListPrimary.trimToSize();
				targetListPrimary.trimToSize();
				
			
				System.out.println("Comparing data  "+executionCount+" and generating match unMatch files......");
				executionCount=executionCount+1;
				
				Compare.compareLists(sourceListPrimary, targetListPrimary, validationType, fileName);
				
				sourceListPrimary.clear();
				targetListPrimary.clear();
				System.out.println("String comparision end............... ");
				
				
			}
			
		} 
		catch (Exception e) 
		{ 
			e.printStackTrace();
		}

	}



}