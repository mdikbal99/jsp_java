package FileComapre;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
//import java.util.Scanner;
//import java.util.stream.Stream;
//import java.nio.file.Files;
//import java.nio.file.Paths;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class StringForTarget {

	public static Logger loggerStringForTarget= LogManager.getLogger(StringForTarget.class);
	public static ArrayList<String> targetString(List<String> listPrimaryKeyoffset,String targetFilePath,String fileType){
		 ArrayList<String> targetStringList= new ArrayList<>();
		// System.out.println("Target file path is : "+targetFilePath);
		try {
			if(fileType.equalsIgnoreCase("offset")){
		String Data1;
		String startoffset="";
		String endoffset="";
		String transLogic="";
//------------------------------------Old Code------------------------		
		
		//Stream inputStream = Files.lines(Paths.get(targetFilePath), StandardCharsets.UTF_8);
		//InputStream inputStream = new FileInputStream(targetFilePath);
		//Scanner fileScanner = new Scanner(inputStream, StandardCharsets.UTF_8.name());
		
/*	    FileReader fr = new FileReader(targetFilePath);
		BufferedReader br = new BufferedReader(fr);
			while ((Data1 = br.readLine()) != null) {
	     //	while (fileScanner.hasNextLine()){
			//Data1=fileScanner.nextLine();
				String targetString="";
				for(String a :listPrimaryKeyoffset){
					startoffset=a.split(",")[0];
					endoffset=a.split(",")[1];
					targetString=targetString+StringReformat.reformatString(Data1.substring(Integer.parseInt(startoffset),Integer.parseInt(endoffset)).trim());
				}

				targetStringList.add(targetString);

			}
			br.close();*/
//--------------------------------Old Code Close---------------------------------		
		
//--------------newly added(1/15/2019)-----------------------------------new Implement Code---------------------------------------------		
		LineIterator fileContents2= FileUtils.lineIterator(new File(targetFilePath), StandardCharsets.UTF_8.name());
		while(fileContents2.hasNext()){
			Data1=fileContents2.nextLine();
			String targetString="";
			for(String a :listPrimaryKeyoffset){
				
				String b=a.split("\\*")[0];
				transLogic=a.split("\\*")[1];
				
				startoffset=b.split(",")[0];
				endoffset=b.split(",")[1];
				try{
				targetString=targetString+StringReformat.reformatString(Data1.substring(Integer.parseInt(startoffset),Integer.parseInt(endoffset)).trim(),transLogic);
				}catch(Exception e){
					targetString=targetString+StringReformat.reformatString("",transLogic);
				}
			}
			targetStringList.add(targetString);
			
		}
		fileContents2.close();
//-------------------------------------------------------new Implement end---------------------------------------------------		
			
			
			targetStringList.trimToSize();
		}
		} catch (IOException e) {
			e.printStackTrace();
			loggerStringForTarget.error("Exception in offset target String formation",e);
		}
		try{
		if (fileType.equalsIgnoreCase("comma")||fileType.equalsIgnoreCase("pipe")) {
			LineIterator fileContents2= FileUtils.lineIterator(new File(targetFilePath), StandardCharsets.UTF_8.name());
			String Data2;
			String transLogic="";
			while(fileContents2.hasNext()){
				Data2=fileContents2.nextLine();
				
			
           	 String targetString="";
				for(String a :listPrimaryKeyoffset){
					String b=a.split("\\*")[0];
					transLogic=a.split("\\*")[1];
					if(fileType.equalsIgnoreCase("comma")){
						try{
					    targetString = targetString + StringReformat.reformatString(Data2.split(",")[Integer.parseInt(b)-1].trim(),transLogic);
						}catch(Exception e){
							targetString = targetString + StringReformat.reformatString("",transLogic);
						}
					}
					
					else if(fileType.equalsIgnoreCase("pipe")){
						try{
						targetString = targetString + StringReformat.reformatString(Data2.split("\\|")[Integer.parseInt(b)-1].trim(),transLogic);
						}catch(Exception e){
							targetString = targetString + StringReformat.reformatString("",transLogic);
						}
					}
					else{
						System.out.println("please check targetString() with excel sheet format type ");
					}
				}

				targetStringList.add(targetString);

			}
			fileContents2.close();
		}
		} catch (IOException e) {
			e.printStackTrace();
			loggerStringForTarget.error("exception in comma/pipe in target string formation",e);
		}
		targetStringList.trimToSize();
	
		return targetStringList;

	}







}
