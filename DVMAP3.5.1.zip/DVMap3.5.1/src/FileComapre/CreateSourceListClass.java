package FileComapre;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import application.Main;
import util.FileReadFromFolder;

public class CreateSourceListClass extends Thread {
	// String
	// path="C:\\Users\\Public\\Documents\\Panorama\\DataValidation\\HiveData\\";
	// final static File folder = new File("D:/DataValidation/tempSourceSplit");
	static String tempSource = Main.defaultSavedPath + Main.defaultResultFolderName + "tempSourceSplit";
	static File folder = new File(tempSource);
	public static Logger loggerCreateSourceListClass = LogManager.getLogger(CreateSourceListClass.class);

	public static ArrayList<String> makingSourceList(List<String> primaryKeyOffsetRetriveForSouce, String fileTypeForSouce) {

		List<String> listOfSplitedfilesForSource;
		ArrayList<String> sourceListPrimary = new ArrayList<>();
		try {
			folder.getParentFile().mkdir();
			listOfSplitedfilesForSource = FileReadFromFolder.listFilesForFolderForSource(folder);
			
			for (String splitedFilePathForSource : listOfSplitedfilesForSource) {
				ArrayList<String> abc = new ArrayList<>();
				// sourceListPrimary=StringForSource.sourceString(primaryKeyOffsetRetriveForSouce,splitedFilePathForSource, fileTypeForSouce);
				abc = StringForSource.sourceString(primaryKeyOffsetRetriveForSouce, splitedFilePathForSource,fileTypeForSouce);
				abc.trimToSize();
				for (String a : abc) {
					sourceListPrimary.add(a);
				}
				System.out.println("retrive data from and added to sourceListPrimary="+splitedFilePathForSource);
			}
			
			listOfSplitedfilesForSource.clear();

		} catch (IOException e1) {
			loggerCreateSourceListClass.error("exception in Create Source List" ,e1);
			e1.printStackTrace();
		}
		
		sourceListPrimary.trimToSize();
		return sourceListPrimary;

	}
	
}
