package FileComapre;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import util.FileSplit;

public class MainClassFileValidation {
	public static String dataSheetName;
	static String Matchfile;
	static String sourceNotInTargetFile;
	static String targetNotInSourceFile;
	//public static String folderLocation = Main.defaultSavedPath;
	public static Logger loggerMainClassFileValidation = LogManager.getLogger(MainClassFileValidation.class);
	File files = null;
	protected static int count;

	public static double sourceRecordCount;
	public static double targetRecordCount;
	
	static Instant SourcelineCount_StartAt;
	static Instant SourcelineCount_EndAt;
	
	static Instant TargetlineCount_StartAt;
	static Instant TargetlineCount_EndAt;

	public static String dataSheetPathFromProp() {
		String dataSheetPath = "";
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("filePathDetails.properties");
			dataSheetPath = (String) configFile.getProperty("datasheetPath");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dataSheetPath;
	}

	public static String File1PathFromProp() {
		String file1Path = "";
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("filePathDetails.properties");
			file1Path = (String) configFile.getProperty("file1Path");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file1Path;

	}

	public static String File2PathFromProp() {
		String file2Path = "";
		try {
			PropertiesConfiguration configFile = new PropertiesConfiguration("filePathDetails.properties");
			file2Path = (String) configFile.getProperty("file2Path");

		} catch (Exception e) {
			System.out.println("File2 path is wrong in Prop. file");
		}
		return file2Path;
	}


	@SuppressWarnings("static-access")
	public static boolean mainMethodForFileCompare() throws IOException {

		

		String sourceFilePath = File1PathFromProp();
		String targetFilePath = File2PathFromProp();
		dataSheetName = dataSheetPathFromProp();

		String sourceFileType = FatchDataFromExcel.sourecType(dataSheetName);
		String targetFileType = FatchDataFromExcel.targetType(dataSheetName);
		String filename = FatchDataFromExcel.fileName();

		// this two list will take the primary offset from the data sheet
		ArrayList<String> primaryKeyOffsetRetriveForSouce = SourceOffsetFetch.primaryKeyOffsetRetriveForSouce(dataSheetName,
				sourceFileType);
		primaryKeyOffsetRetriveForSouce.trimToSize();
		ArrayList<String> primaryKeyOffsetRetriveForTarget = TargetOffsetFetch.primaryKeyOffsetRetriveForTarget(dataSheetName,
				targetFileType);
		primaryKeyOffsetRetriveForTarget.trimToSize();

		
		try {
//-----------------------------------------------OLD code---------------------------------------------------------------			
		/*	File fileS = new File(sourceFilePath);
			Scanner scanner = new Scanner(fileS);
			while (scanner.hasNextLine()) {
				scanner.nextLine();
				sourceRecordCount++;
				count++;
			}
			scanner.close();
			File fileT = new File(targetFilePath);
			Scanner scannerT = new Scanner(fileT);
			while (scannerT.hasNextLine()) {
				scannerT.nextLine();
				targetRecordCount++;
			}*/
//--------------------------------------------------------OLD CODE END--------------------------------------------		

//--------------------------newly added(1/11/2019)--------------------------------New Implemented Code-----------------------------------
			 
			SourcelineCount_StartAt=Instant.now();
			  LineIterator fileContents= FileUtils.lineIterator(new File(sourceFilePath), StandardCharsets.UTF_8.name());
		    	while (fileContents.hasNext()) {
					//System.out.println(fileContents.next());
					fileContents.nextLine();
					sourceRecordCount++;
					count++;
				}
		       SourcelineCount_EndAt=Instant.now();
		    	System.out.println("Total Source Record Count="+sourceRecordCount);
		    	System.out.println("Total Time Taken to retrive Source="+Duration.between(SourcelineCount_StartAt, SourcelineCount_EndAt));
		    	fileContents.close();
		    	
		    	TargetlineCount_StartAt=Instant.now();
		    	 LineIterator fileContents2= FileUtils.lineIterator(new File(targetFilePath), StandardCharsets.UTF_8.name());
			    	while (fileContents2.hasNext()) {
						//System.out.println(fileContents2.next());
						fileContents2.nextLine();
						targetRecordCount++;
					}
			    TargetlineCount_EndAt=Instant.now();
			    	System.out.println("Total Target Record Count="+targetRecordCount);
			    	System.out.println("Total Time Taken to retrive Target"+Duration.between(TargetlineCount_StartAt, TargetlineCount_EndAt));
			    	fileContents2.close();
			    	Runtime.getRuntime().gc();
//----------------------------------------------------------New Implemented Close----------------------------------	\
			    	//1000000
			if (count > 1000000) {
				System.out.println("your file size is too large...");
				System.out.println("spliting big files......");
				FileSplit.fileSplitForSource();
				FileSplit.fileSplitForTarget();
				System.out.println("Spliting big files end.....");
			}
		
		//	scannerT.close();
			
		} catch (IOException E) {
			loggerMainClassFileValidation.error("problem in MainClassValidation Before Start Pk Validation" ,E);
			E.printStackTrace();
		}
		
		try {
	
		//String validationType = "Primary Key";
		System.out.println("sourceFilePath----" + sourceFilePath);
		System.out.println("targetFilePath----" + targetFilePath);
		
        Thread.sleep(1000);
    	System.out.println("Key validation Started***At*"+StringReformat.folderwithDate("")+"********");

		PrimaryKeyValidation.validatePrimaryKey(primaryKeyOffsetRetriveForSouce, primaryKeyOffsetRetriveForTarget,
			"Primary Key", filename,  sourceFilePath, targetFilePath, sourceFileType, targetFileType);
		
		System.out.println("Key validation ended at**"+StringReformat.folderwithDate(""));
		
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Runtime.getRuntime().gc();
		
		AttributeValidation atv = new AttributeValidation();
		atv.attributeValidation(primaryKeyOffsetRetriveForSouce, primaryKeyOffsetRetriveForTarget, "attribute",
				filename, sourceFileType, targetFileType);
		
		/*if (count > 1000000) {
			FileSplit.deleteTempFiles();
		}*/
		
		System.out.println("Data validation Ended*****At**"+StringReformat.folderwithDate(""));
		return true;

	}

}

