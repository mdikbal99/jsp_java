package FileComapre;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

public class StringReformat {

	public static Logger stringReformatLog = Logger.getLogger(StringReformat.class);

	public static String reformatString(String str, String transLogic) {

		String functionName = "";
		String functionArgument = "";
		String returnStr = "";

		try {
			if (transLogic.equalsIgnoreCase("NO_TL_LOGICS")) {
				functionName = "NO_TL_LOGICS";
			} else
				try {
					functionName = transLogic.split("\\(")[0].trim();
					functionArgument = transLogic.split("\\(")[1].trim();
				} catch (Exception e) {
					returnStr = str + "|";
					stringReformatLog.error(
							"Exception in TransformationLogic! Please check your dataSheet's TransFormatrion Logic");
				}

			switch (functionName) {

			case "NO_TL_LOGICS":
				returnStr = str + "|";
				break;
			case "dateSplit":
				returnStr = returnSplitedDate(str, functionArgument) + "|";
				break;
			case "replace":
				returnStr = replaceString(str, functionArgument) + "|";
				break;
			case "presideZero":
				returnStr = addPreZero(str, functionArgument) + "|";
				break;
			case "decimal":
				returnStr = convertDecimal(str, functionArgument) + "|";
				break;
			case "removeInsignificantZero":
				returnStr=removeInsignificantZero(str, functionArgument)+"|";
			case "changeDateFormat":
				returnStr=changeDateFormat(str,functionArgument)+"|";
			default:
				break;
			}
			// int splitNum=Character.getNumericValue("split(2)".split("\\(")[1].charAt(0));
		} catch (Exception e) {
			stringReformatLog.error("Problem in reformatString method,Please check DataSheet Transformation Logic", e);
			e.printStackTrace();
		}
		return returnStr;
	}
	
	public static String changeDateFormat(String str,String functionArgument) {
		try {
		String args = functionArgument.split("\\)")[0];
		String haveFormat=args.split(",")[0];
		String needFormat=args.split(",")[1];
		 
			SimpleDateFormat formatter1=new SimpleDateFormat(haveFormat);
			Date date=formatter1.parse(str);
			System.out.println(date);
			
			DateFormat dateFormat = new SimpleDateFormat(needFormat);  
			 str = dateFormat.format(date);  
			
		} catch (ParseException e) {
			e.printStackTrace();
			stringReformatLog.error(
					"Exception in changeDateFormat! Please check StringReformat");
			return str;
		}
		 return str;
	}
	
	public static String removeInsignificantZero(String str, String functionArgument) {
		try {
		str = str.indexOf(".") < 0 ? str : str.replaceAll("0*$", "").replaceAll("\\.$", "");
		//DecimalFormat decimalFormat = new DecimalFormat("0.########");
		//String result = decimalFormat.format(Double.valueOf(s));
		//s.replaceFirst("\\.0*$|(\\.\\d*?)0+$", "$1");
		}catch(Exception e) {
			e.printStackTrace();
			stringReformatLog.error(
					"Exception in removeInsignificantZero! Please check StringReformat");
		}
		return str;
	}

	public static String returnSplitedDate(String dateString, String functionArgument) {// "2018-01-27",0
		int splitNum = 0;
		ArrayList<String> dateList = new ArrayList<String>();
		try {
			if (dateString.contains("-")) {
				dateList.add(dateString.split("-")[0].trim());
				dateList.add(dateString.split("-")[1].trim());
				dateList.add(dateString.split("-")[2].trim());

			} else if (dateString.contains("/")) {
				dateList.add(dateString.split("/")[0].trim());
				dateList.add(dateString.split("/")[1].trim());
				dateList.add(dateString.split("/")[2].trim());

			} else if (dateString.contains(" ")) {
				dateList.add(dateString);
				return dateList.get(0);
			}

		} catch (Exception e) {
			stringReformatLog.error("The Attribute Date Type is Technically wrong !", e);
			return dateString;
		}
		try {
			splitNum = Integer.parseInt(functionArgument.split("\\)")[0]);
			if (splitNum == 0 || splitNum == 1 || splitNum == 2)
				return dateList.get(splitNum);
		} catch (Exception e) {
			stringReformatLog.error("Problem in returnSplitedDate method,Please check DataSheet Transformation Logic",
					e);
			return dateString;
		}
		return dateString;
	}

	public static String replaceString(String str, String functionArgument) {
		// Arrays.asList(functionArgument.split("\\S*,\\S*"));
		List<String> func_Arg_List = new ArrayList<String>(Arrays.asList(functionArgument.split(",")));
		String replaceString = "";
		String outputPosition = "";

		for (int i = 0; i < func_Arg_List.size(); i++) {
			String inputPosition = func_Arg_List.get(i);
			if (func_Arg_List.size() - 2 == i) {
				outputPosition = func_Arg_List.get(i + 1).split("\\)")[0].trim();
			} else {
				if (i < func_Arg_List.size() - 1)
					outputPosition = func_Arg_List.get(i + 1).trim();
				else
					return str;
			}
			i++;
			if (str.equalsIgnoreCase(inputPosition)) {
				replaceString = outputPosition;
			}
		}
		func_Arg_List.clear();
		if (replaceString == "") {
			return str;
		} else
			return replaceString;
	}

	public static String addPreZero(String str, String functionArgument) {
		String formated = "";
		try {
			int digit = Integer.parseInt(functionArgument.split("\\)")[0]);
			formated = String.format("%0" + digit + "d", Integer.parseInt(str));
		} catch (Exception e) {
			stringReformatLog.error("format error on presidingZero", e);
			return str;

		}
		return formated;
	}

	public static String convertDecimal(String str, String functionArgument) {
		String return_str = "";
		double strDouble = Double.valueOf(str);
		int strInt = (int) strDouble;
		String converted_str = String.valueOf(strInt);

		String zero_Frm_FuncArg = functionArgument.split("\\)")[0];
		return_str = converted_str + "." + zero_Frm_FuncArg;

		return return_str;
	}

	public static String folderwithDate(String filename) {
		DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("_yyyy-mm-dd_hh-mm-ss");
		LocalDateTime now = LocalDateTime.now();

		return filename + dtf1.format(now);
	}

	public static String currentDateTime() {
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("_yyy-MM-dd_hh-mm-ss");
		LocalDateTime nowDateTime = LocalDateTime.now();
		String currentDateTime = dtf2.format(nowDateTime);
		return currentDateTime;
	}

}
