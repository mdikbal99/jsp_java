package FileComapre;

import java.util.ArrayList;

import util.MyExcelConnect;

public class SourceOffsetFetch {

	
	public static ArrayList<String> primaryKeyOffsetRetriveForSouce(String dataSheetName, String fileType){
		ArrayList<String> listPrimaryKeyoffset = new ArrayList<>();
		MyExcelConnect sh2Source = new MyExcelConnect(dataSheetName, 2);
		
		if(fileType.equalsIgnoreCase("offset")){
			System.out.println("your Source file type is offset delimited");
			String PreSubStr = null;
			String postSubStr = null;
			int PreSubInt = 0;
			String transLoff="";
			for(int i=1;i<=sh2Source.lastrowno()+1;i++){
				if (sh2Source.excelread(i, 4).equalsIgnoreCase("y")) {
					
					PreSubStr = sh2Source.excelread(i, 2);
					PreSubInt = Integer.parseInt(PreSubStr);
					PreSubInt = PreSubInt - 1;

					postSubStr = sh2Source.excelread(i, 5);
					
				
				
				if(sh2Source.excelread(i, 6)==null||sh2Source.excelread(i, 6)==""||sh2Source.excelread(i, 6).isEmpty()) {
					transLoff="NO_TL_LOGICS";
				}else
					transLoff=sh2Source.excelread(i, 6);
				
				String offsetCount=String.valueOf(PreSubInt)+","+postSubStr+"*"+transLoff;
				
				listPrimaryKeyoffset.add(offsetCount);
				}
					
				}
			}
		
		
		else if (fileType.equalsIgnoreCase("comma")||fileType.equalsIgnoreCase("pipe")) {
			System.out.println("your source file is comma/pipe seperated");

				String pk = "";
				String transLS="";
				for (int j = 2; j <= sh2Source.lastrowno()+1; j++) {
					if (sh2Source.excelread(j, 4).equalsIgnoreCase("y")) {
						 pk = sh2Source.excelread(j, 2);
						//r = Integer.parseInt(pk);
						String offsetCount=pk;
						
						if(sh2Source.excelread(j, 6)==null||sh2Source.excelread(j, 6)==""||sh2Source.excelread(j, 6).isEmpty()) {
							transLS="NO_TL_LOGICS";
						}else
							transLS=sh2Source.excelread(j, 6);
						listPrimaryKeyoffset.add(offsetCount+"*"+transLS);
					}

				}
				
			}else
				System.out.println("Please check your File type with your data sheet \n comma,pipe,offset type can be validated");
		
		
		listPrimaryKeyoffset.trimToSize();
		return listPrimaryKeyoffset;
		
	}
	
	
}
