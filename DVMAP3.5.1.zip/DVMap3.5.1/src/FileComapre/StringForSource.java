package FileComapre;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;



public class StringForSource {
	
	 
	public static Logger loggerStringForSource= LogManager.getLogger(StringForSource.class);
	public static ArrayList<String> sourceString(List<String> listPrimaryKeyoffset,String sourceFilePath,String fileType){
		
		ArrayList<String> sourceStringList = new ArrayList<>();
		//ArrayList<String> listTransLogicForSource = TransLogicsFetch.transLogicListForSource(MainClassFileValidation.dataSheetPathFromProp());

		try {
			if (fileType.equalsIgnoreCase("offset")) {
				String Data1;
				String startoffset = "";
				String endoffset = "";
				String transLogic="";
//--------------------------------------Old Cold Start------------------------------------------------------------------------------------		
				/*
				 * FileReader fr = new FileReader(sourceFilePath); BufferedReader br2 = new
				 * BufferedReader(fr); while ((Data1 = br2.readLine()) != null) { String
				 * sourceString=""; for(String a :listPrimaryKeyoffset){
				 * 
				 * startoffset=a.split(",")[0]; endoffset=a.split(",")[1];
				 * 
				 * sourceString=sourceString+StringReformat.reformatString(Data1.substring(
				 * Integer.parseInt(startoffset),Integer.parseInt(endoffset)).trim());
				 * 
				 * } sourceStringList.add(sourceString);
				 * 
				 * }
				 * 
				 * br2.close();
				 */

//-------------------Old Code End----------------------------------------------------------	---------------------------------------

//-------------newly added(1/15/2019)--------------------------------------new Implement Code---------------------------------------	
				LineIterator fileContents = FileUtils.lineIterator(new File(sourceFilePath),
						StandardCharsets.UTF_8.name());
				while (fileContents.hasNext()) {
					Data1 = fileContents.nextLine();
					String sourceString = "";

					for (String a : listPrimaryKeyoffset) {
						String b=a.split("\\*")[0];

						startoffset = b.split(",")[0];
						endoffset = b.split(",")[1];
						
						transLogic=a.split("\\*")[1];
						try {

							sourceString = sourceString + StringReformat.reformatString(
									Data1.substring(Integer.parseInt(startoffset), Integer.parseInt(endoffset)).trim(),transLogic);

						} catch (Exception e) {
							sourceString = sourceString + StringReformat.reformatString("",transLogic);
						}

					}
					sourceStringList.add(sourceString);
				}
				fileContents.close();
//-------------------------------------------------------------new Implement Close--------------------------------------------------			
				sourceStringList.trimToSize();
			}
		} catch (IOException e) {
			loggerStringForSource.error("exception in offset Source String formation",e);
			e.printStackTrace();
		}
		try {
			if (fileType.equalsIgnoreCase("comma") || fileType.equalsIgnoreCase("pipe")) {

				LineIterator fileContents = FileUtils.lineIterator(new File(sourceFilePath),
						StandardCharsets.UTF_8.name());

				String Data1;
                String tarnsLogic="";
				while (fileContents.hasNext()) {
					Data1 = fileContents.nextLine();

					String sourceString = "";
					for (String a : listPrimaryKeyoffset) {
						String b=a.split("\\*")[0];
						tarnsLogic=a.split("\\*")[1];

						if (fileType.equalsIgnoreCase("comma")) {
							try {
								sourceString = sourceString + StringReformat
										.reformatString(Data1.split(",")[Integer.parseInt(b) - 1].trim(),tarnsLogic);
							} catch (Exception e) {
								sourceString = sourceString + StringReformat.reformatString("",tarnsLogic);
							}

						} else if (fileType.equalsIgnoreCase("pipe")) {
							try {
								sourceString = sourceString + StringReformat.reformatString(Data1.split("\\|")[Integer.parseInt(b) - 1].trim(),tarnsLogic);
								 
							

							} catch (Exception e) {
								sourceString = sourceString + StringReformat.reformatString("",tarnsLogic);
							}

						} else {
							System.out.println("please check sourceString() with excel sheet format type ");
						}
					}
					
					
//					  int splitNum = 0;
//					  char transNumString; String sourceStringTrans=""; 
//					  try {
//					  if(listOfTransLogicForSourcePK.isEmpty()) { 
//						//for (String transL :  TransLogicsFetch.transLogicListForSource(MainClassFileValidation.dataSheetPathFromProp()));
//                        for (String transL : listOfTransLogicForSourcePK){
//					  System.out.println(transL+ "------------------------------------------------------------------------------>transL"
//					  ); transNumString = transL.split("\\(")[1].charAt(0); 
//					  splitNum =Character.getNumericValue(transL.split("\\(")[1].charAt(0)); 
//					  sourceStringTrans =sourceStringTrans+StringReformat.reformatString(StringReformat.returnSplitedDate(sourceString.substring(sourceString.lastIndexOf("|")+1),splitNum)); 
//					  } }}
//					  catch(Exception e) { System.out.println(e); System.exit(2); }
					 
					
					sourceStringList.add(sourceString);

				}

				fileContents.close();
			}
		} catch (IOException e) {
			loggerStringForSource.error("Exception in comma/pipe source String formation",e);
			e.printStackTrace();
		}
		sourceStringList.trimToSize();
		return sourceStringList;

	}

}
