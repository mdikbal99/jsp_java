package FileComapre;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import application.Main;

@SuppressWarnings("rawtypes")
public class Compare {
	static String Matchfile;
	static String sourceNotInTargetFile;
	static String targetNotInSourceFile;
	static String folderLocation = null;
	static File files = null;
	static String matchFlag = "";

	static int matchRecordCount;
	static int sNotINtRecordCount;
	static int tNotINsRecordCount;

	// this method will validate Source and Target String and generate 3 files
	public static void compareLists(List firstList, List secondList, String attribute, String filename) {
		folderLocation = Main.defaultSavedPath;
		if (attribute == "Primary Key") {
			Matchfile = folderLocation + "\\"+ filename + "\\" + attribute + "\\" + "matchFile.txt";
			sourceNotInTargetFile = folderLocation +"\\" + filename + "\\" + attribute + "\\" + "SourceNotInTarget.txt";
			targetNotInSourceFile = folderLocation +"\\" + filename + "\\" + attribute + "\\" + "TagetNotInSource.txt";
			files = new File(Matchfile);
			// files.mkdir();
			files.getParentFile().mkdirs();
		} else {

			Matchfile = folderLocation +"\\" + filename + "\\Attribute\\" + attribute + "\\" + "matchFile.txt";
			sourceNotInTargetFile = folderLocation +"\\" + filename + "\\Attribute\\" + attribute + "\\"
					+ "SourceNotInTarget.txt";
			targetNotInSourceFile = folderLocation +"\\" + filename + "\\Attribute\\" + attribute + "\\"
					+ "TagetNotInSource.txt";
			files = new File(Matchfile);
			// files.mkdir();
			files.getParentFile().mkdirs();
		}

		Map<String, String> mapForFirstList = new HashMap<String, String>();
		Map<String, String> mapForSecondList = new HashMap<String, String>();

		// LinkedHashMap<String, String> mapForFirstList = new LinkedHashMap
		// <String, String>();
		// LinkedHashMap <String, String> mapForSecondList = new LinkedHashMap
		// <String, String>();

		Iterator firstListIterator = firstList.iterator();
		Iterator secondListIterator = secondList.iterator();

		while (firstListIterator.hasNext()) {
			String firstListKeyValue = firstListIterator.next().toString();
			if (!mapForFirstList.containsKey(firstListKeyValue)) {
				mapForFirstList.put(firstListKeyValue, firstListKeyValue);
			}
		}

		while (secondListIterator.hasNext()) {
			String secondListKeyValue = secondListIterator.next().toString();
			if (!mapForSecondList.containsKey(secondListKeyValue)) {

				mapForSecondList.put(secondListKeyValue, secondListKeyValue);
			}
		}

		compareAndPrintResults(mapForFirstList, mapForSecondList);
		mapForFirstList.clear();
		mapForSecondList.clear();

		excelPrint(attribute);

	}

	public static void compareAndPrintResults(Map mapForFirstList, Map mapForSecondList) {
		doSameComparisionAndPrint(mapForFirstList, mapForSecondList);

		sNotINtRecordCount = 0;
		doComparisionAndPrint_SnT(mapForFirstList, mapForSecondList);

		tNotINsRecordCount = 0;
		doComparisionAndPrint_TnS(mapForFirstList, mapForSecondList);

		mapForFirstList.clear();
		mapForSecondList.clear();

	}

	public static void doComparisionAndPrint_SnT(Map mapA, Map mapB) {

		if (mapA != null && mapB != null) {
			Iterator mapAIterator = mapA.keySet().iterator();
			try (BufferedWriter bw1 = new BufferedWriter(new FileWriter(sourceNotInTargetFile))) {
				while (mapAIterator.hasNext()) {
					String key = mapAIterator.next().toString();
					if (!mapB.containsKey(key)) {
						bw1.write(key);
						sNotINtRecordCount++;
						// mapAIterator.remove();
						bw1.newLine();
					}
				}
				bw1.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	@SuppressWarnings("unchecked")
	public static void doComparisionAndPrint_TnS(Map mapA, Map mapB) {
		if (mapB != null && mapA != null) {
			Iterator<String> mapBIterator = mapB.keySet().iterator();
			try (BufferedWriter bw2 = new BufferedWriter(new FileWriter(targetNotInSourceFile, true))) {
				while (mapBIterator.hasNext()) {
					String keyb = mapBIterator.next().toString();
					if (!mapA.containsKey(keyb)) {

						bw2.write(keyb);
						tNotINsRecordCount++;
						// mapB.remove(keyb);
						// mapBIterator.remove();
						bw2.newLine();
					}
				}
				bw2.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void doSameComparisionAndPrint(Map mapA, Map mapB) {
		matchRecordCount = 0;
		if (mapA != null && mapB != null) {
			Iterator mapAIterator = mapA.keySet().iterator();

			try (BufferedWriter bw1 = new BufferedWriter(new FileWriter(Matchfile, true))) {
				while (mapAIterator.hasNext()) {
					String key = mapAIterator.next().toString();
					if (mapB.containsKey(key)) {

						bw1.write(key);
						matchRecordCount++;
						// mapAIterator.remove();
						bw1.newLine();
					}
				}

				bw1.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	public static void excelPrint(String attribute) {
		System.out.println("tNotINsRecordCount=" + tNotINsRecordCount + "\nsNotINtRecordCount=" + sNotINtRecordCount
				+ "\nmatchRecordCount=" + matchRecordCount);
		if (tNotINsRecordCount > 0 || sNotINtRecordCount > 0)
			ResultUpdate.validationStatus("fail", attribute, String.valueOf(matchRecordCount),
					String.valueOf(sNotINtRecordCount), String.valueOf(tNotINsRecordCount));

		else if (tNotINsRecordCount == 0 && sNotINtRecordCount == 0)
			ResultUpdate.validationStatus("pass", attribute, String.valueOf(matchRecordCount),
					String.valueOf(sNotINtRecordCount), String.valueOf(tNotINsRecordCount));

	}

}
