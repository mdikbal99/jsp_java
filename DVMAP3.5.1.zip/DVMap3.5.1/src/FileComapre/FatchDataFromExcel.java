package FileComapre;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import util.MyExcelConnect;

public class FatchDataFromExcel {


	public static String sourceFilePath(String dataSheetName) {
		MyExcelConnect d1 = new MyExcelConnect(dataSheetName, 2);
		String sourceFile = d1.excelread(2, 6);
		return sourceFile;
	}

	public static String targetFilePath(String dataSheetName) {
		MyExcelConnect d2 = new MyExcelConnect(dataSheetName, 1);
		String targetFile = d2.excelread(2, 6);
		return targetFile;
	}
	
	public static String sourecType(String dataSheetName){
		MyExcelConnect d1 = new MyExcelConnect(dataSheetName, 2);
		String sourceFile = d1.excelread(2, 7);
		return sourceFile;
		
	}
	public static String targetType(String dataSheetName){
		MyExcelConnect d1 = new MyExcelConnect(dataSheetName, 1);
		String targetFile = d1.excelread(2, 7);
		return targetFile;
		
	}
	
	public static String fileName(){
		PropertiesConfiguration configFile1;
		String resultFolderName = null;
		try {
			configFile1 = new PropertiesConfiguration("filePathDetails.properties");
			resultFolderName = (String) configFile1.getProperty("defaultResultFolderName");
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultFolderName;
		
	}
}
