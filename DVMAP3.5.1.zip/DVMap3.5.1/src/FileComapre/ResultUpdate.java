package FileComapre;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import java.time.format.DateTimeFormatter;

import application.Main;
import util.MyExcelConnect;
//import java.time.LocalDateTime;

public class ResultUpdate extends MainClassFileValidation {
	//static final String dataSheetName = "D:\\DataValidation\\FileValidationDetails.xls";

	public static void validationStatus(String status, String attribute,String matchRecordCount,String sNotINtRecordCount,String tNotINsRecordCount) {
		MyExcelConnect mec3 = new MyExcelConnect(dataSheetName, 2);
		MyExcelConnect resUpdate= new MyExcelConnect(dataSheetName,3);
		try {
			/*mec3.setData(2, 10, String.valueOf(sourceRecordCount));
			mec3.setData(2, 11, String.valueOf(targetRecordCount));*/
			
			resUpdate.setData(2, 10,  String.valueOf(sourceRecordCount));
			resUpdate.setData(3, 10,  String.valueOf(targetRecordCount));
			
			
		} catch (Throwable e1) {
			e1.printStackTrace();
		}
	
		for (int i = 2; i <= mec3.lastrowno() + 1; i++) {
	//------------------------------------------------------------------------------------------		
		
			if (mec3.excelread(i, 1).trim().equalsIgnoreCase(attribute) && mec3.excelread(i, 1).trim().isEmpty()==false) {
			
				try {
					/*mec3.setData(i, 9, status);
					mec3.setData(i, 12, matchRecordCount);
					mec3.setData(i, 13, sNotINtRecordCount);
					mec3.setData(i, 14, tNotINsRecordCount);*/
					resUpdate.setData(i, 4, status);
					resUpdate.setData(i, 5, matchRecordCount);
					resUpdate.setData(i, 6, sNotINtRecordCount);
					resUpdate.setData(i, 7, tNotINsRecordCount);
					
					
				} catch (Throwable e) {
					e.printStackTrace();
				}
			}
			
	//----------------------------------------------------------------------------------------		
			else if(attribute.equalsIgnoreCase("Primary Key")){
				if(mec3.excelread(i, 4).equalsIgnoreCase("y") && mec3.excelread(i, 4).isEmpty()==false){
					try {
						/*mec3.setData(i, 9, status);
						mec3.setData(i, 12, matchRecordCount);
						mec3.setData(i, 13, sNotINtRecordCount);
						mec3.setData(i, 14, tNotINsRecordCount);*/
						
						resUpdate.setData(i, 4, status);
						resUpdate.setData(i, 5, matchRecordCount);
						resUpdate.setData(i, 6, sNotINtRecordCount);
						resUpdate.setData(i, 7, tNotINsRecordCount);
						
					} catch (Throwable e) {
						e.printStackTrace();
					}
				}
			}

		}
		
		try {

			FileInputStream	file = new FileInputStream(dataSheetPathFromProp());
			HSSFWorkbook workbookinput = new HSSFWorkbook(file);
			HSSFWorkbook workbookoutput=workbookinput;
			
		
		//	workbookoutput.getSheetAt(0).getRow(9).getCell(4); 
			workbookoutput.removeSheetAt(2);
			workbookoutput.removeSheetAt(1);
			workbookoutput.removeSheetAt(0);
			
			HSSFCellStyle style=workbookinput.createCellStyle();
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			
			FileOutputStream out = new FileOutputStream(Main.defaultSavedPath + Main.defaultResultFolderName + "ResultSheet.xls");
			workbookoutput.write(out);
			
			
			out.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
}
