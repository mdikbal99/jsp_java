package FileComapre;

import java.util.ArrayList;

import FileComapre.StringReformat;
import util.MyExcelConnect;

public class AttributeValidation extends MainClassFileValidation {
	// static final String dataSheetName =
	// "D:\\DataValidation\\FileValidationDetails.xls";

	public static void attributeValidation(ArrayList<String> primaryKeyOffsetRetriveForSouce,
			ArrayList<String> primaryKeyOffsetRetriveForTarget, String validationType, String filename, String sourceFileType, String targetFileType) {

		System.out.println("Attribute Validation Started....At.."+StringReformat.folderwithDate(""));
		
		String sourceFilePath = File1PathFromProp();
		String targetFilePath = File2PathFromProp();
		ArrayList<String> listForSouceAttribute = new ArrayList<>();
		ArrayList<String> listForTargetAttribute = new ArrayList<>();
		

		MyExcelConnect mec2 = new MyExcelConnect(dataSheetName, 2);
		MyExcelConnect mec1 = new MyExcelConnect(dataSheetName, 1);

		int attraddc = 0;
		int attraddct = 0;

		MyExcelConnect sh2Source = new MyExcelConnect(dataSheetName, 2);
		MyExcelConnect sh1Target = new MyExcelConnect(dataSheetName, 1);

		for (int i = 2; i <= mec2.lastrowno() + 1; i++) {

			if (mec2.excelread(i, 4).equalsIgnoreCase("y") == false
					&& mec1.excelread(i, 4).equalsIgnoreCase("y") == false) {

				listForSouceAttribute = primaryKeyOffsetRetriveForSouce;
				listForSouceAttribute.trimToSize();
				listForTargetAttribute = primaryKeyOffsetRetriveForTarget;
				listForTargetAttribute.trimToSize();
				// ---------------------------------------------------------------------------------------------------------------------------------------------------
				if (sourceFileType.equalsIgnoreCase("offset")) {
					String PreSubStr = null;
					String postSubStr = null;
					int PreSubInt = 0;
					String transLoff="";

					PreSubStr = sh2Source.excelread(i, 2);
					PreSubInt = Integer.parseInt(PreSubStr);
					PreSubInt = PreSubInt - 1;

					postSubStr = sh2Source.excelread(i, 5);
					if (sh2Source.excelread(i, 2).isEmpty() == false || sh2Source.excelread(i, 5).isEmpty() == false) {
						if(sh2Source.excelread(i, 6)==null||sh2Source.excelread(i, 6)==""||sh2Source.excelread(i, 6).isEmpty()) {
							transLoff="NO_TL_LOGICS";
						}else
							transLoff=sh2Source.excelread(i, 6);
						
						String offsetCount = String.valueOf(PreSubInt) + "," + postSubStr+"*"+transLoff;
						
						if (attraddc == 0) {
							listForSouceAttribute.add(offsetCount);
							attraddc = attraddc + 1;
						} else {
							listForSouceAttribute.remove(listForSouceAttribute.size() - 1);
							listForSouceAttribute.add(offsetCount);
							attraddct = attraddct + 1;
						}
					}

				} else if (sourceFileType.equalsIgnoreCase("comma") || sourceFileType.equalsIgnoreCase("pipe")) {
					String transLS="";
					if (sh2Source.excelread(i, 2).isEmpty() == false) {
						String pk = sh2Source.excelread(i, 2);
						// r = Integer.parseInt(pk);
						// String offsetCount=String.valueOf(r);
						if(sh2Source.excelread(i, 6)==null||sh2Source.excelread(i, 6)==""||sh2Source.excelread(i, 6).isEmpty()) {
							transLS="NO_TL_LOGICS";
						}else
							transLS=sh2Source.excelread(i, 6);
						
						String offsetCount = pk+"*"+transLS;

						if (attraddc == 0) {
							listForSouceAttribute.add(offsetCount);
							attraddc = attraddc + 1;
						} else {
							listForSouceAttribute.remove(listForSouceAttribute.size() - 1);
							listForSouceAttribute.add(offsetCount);
							attraddct = attraddct + 1;
						}
					}
				} else {
					System.out.println(
							"Problem in attributeValidation()..within Source File attribute type and position");

				}
				// ---------------------------------------------------------------------------------------------------------------------------------------

				if (targetFileType.equalsIgnoreCase("offset")) {
					String PreSubStr = null;
					String postSubStr = null;
					int PreSubInt = 0;
					String transLT="";
					if (sh1Target.excelread(i, 2).isEmpty() == false || sh1Target.excelread(i, 5).isEmpty() == false) {
						PreSubStr = sh1Target.excelread(i, 2);
						PreSubInt = Integer.parseInt(PreSubStr);
						PreSubInt = PreSubInt - 1;

						postSubStr = sh1Target.excelread(i, 5);
						
						if(sh1Target.excelread(i, 6)==null||sh1Target.excelread(i, 6)==""||sh1Target.excelread(i, 6).isEmpty()) {
							transLT="NO_TL_LOGICS";
						}else
							transLT=sh1Target.excelread(i, 6);

						String offsetCount = String.valueOf(PreSubInt) + "," + postSubStr +"*"+transLT;

						if (attraddct == 0) {
							listForTargetAttribute.add(offsetCount);
							attraddct = attraddct + 1;
						} else {

							listForTargetAttribute.remove(listForTargetAttribute.size() - 1);
							listForTargetAttribute.add(offsetCount);
							attraddct = attraddct + 1;
						}
					}

				} else if (targetFileType.equalsIgnoreCase("comma") || targetFileType.equalsIgnoreCase("pipe")) {
					String transLT="";
					if (sh1Target.excelread(i, 2).isEmpty() == false) {
						String pkoffSet = sh1Target.excelread(i, 2);
						// r = Integer.parseInt(pkoffSet);
						
						if(sh1Target.excelread(i, 6)==null||sh1Target.excelread(i, 6)==""||sh1Target.excelread(i, 6).isEmpty()) {
							transLT="NO_TL_LOGICS";
						}else
							transLT=sh1Target.excelread(i, 6);
						
						String offsetCount = pkoffSet+"*"+transLT;

						if (attraddct == 0) {
							listForTargetAttribute.add(offsetCount);
							attraddct = attraddct + 1;
						} else if (sh1Target.excelread(i, 2).isEmpty() == false) {

							listForTargetAttribute.remove(listForTargetAttribute.size() - 1);
							listForTargetAttribute.add(offsetCount);
							attraddct = attraddct + 1;
						}
					}
				} else {
					System.out.println("Problem in attributeValidation() within Target File attribute type and position");
				}
				// -------------------------------------------------------------------------------------------------------------------

				// pkv.validatePrimaryKey(listForSouceAttribute,
				// listForTargetAttribute, sh2Source.excelread(i, 1),filename,
				// 1, sourceFilePath, targetFilePath, sourceFileType,
				// targetFileType);
				
				if (sh1Target.excelread(i, 2).isEmpty() == false || sh2Source.excelread(i, 2).isEmpty() == false) {
					System.gc();
					listForSouceAttribute.trimToSize();
					listForTargetAttribute.trimToSize();
					

					PrimaryKeyValidation.validatePrimaryKey(listForSouceAttribute, listForTargetAttribute, sh2Source.excelread(i, 1).trim(),
							filename, sourceFilePath, targetFilePath, sourceFileType, targetFileType);
				}
			}
		}
		listForSouceAttribute.clear();
		listForTargetAttribute.clear();
	}
}
