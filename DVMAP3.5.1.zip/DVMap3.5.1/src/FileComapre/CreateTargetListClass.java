package FileComapre;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import application.Main;
import util.FileReadFromFolder;

public class CreateTargetListClass extends Thread {
	// final static File folder2 = new
	// File("D:/DataValidation/tempTargetSplit");
	static String tempTarget = Main.defaultSavedPath + Main.defaultResultFolderName + "tempTargetSplit";
	static File folder2 = new File(tempTarget);

public static ArrayList<String> makingTargetList(List<String> primaryKeyOffsetRetriveForTarget,String fileTypeForTarget) {
		
		List<String> listOfSplitedfilesForTarget;
		ArrayList<String> targetListPrimary = new ArrayList<>();
		
		
		try {
			folder2.getParentFile().mkdir();
			listOfSplitedfilesForTarget = FileReadFromFolder.listFilesForFolderForTarget(folder2);

			for (String splitedFilePathForTarget : listOfSplitedfilesForTarget) {
				
				ArrayList<String> def = new ArrayList<>();
				def = StringForTarget.targetString(primaryKeyOffsetRetriveForTarget, splitedFilePathForTarget,fileTypeForTarget);
				def.trimToSize();
				for (String b : def) {
					targetListPrimary.add(b);
				}
				System.out.println("retrive data from and added to targetListPrimary="+splitedFilePathForTarget);
			}
			listOfSplitedfilesForTarget.clear();

		} 
		catch (Exception E) {
			E.printStackTrace();
		}
		
		targetListPrimary.trimToSize();
		return targetListPrimary;

	}

}
