package util;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
/*
 * Simplify to read and write from excel by ikbal
 */

public class MyExcelConnect {

	File file;
	FileInputStream fis;

	public Workbook wb;
	public XSSFWorkbook wb2;
	public  Sheet sheet1;
	public HSSFSheet sheet2;
	public XSSFSheet sheet3;

	// public HSSFSheet sheet1;
	Row r;
	Cell cell;
	String filepath;
	String fileExtensionName;

	public MyExcelConnect(String filepath, int sheetnum) {
		file = new File(filepath);
		this.filepath = filepath;
		this.fileExtensionName = filepath.substring(filepath.indexOf("."));

		try {
			fis = new FileInputStream(file);
			if (fileExtensionName.equals(".xls")) {
				wb = new HSSFWorkbook(fis);
				sheet1 = (HSSFSheet) wb.getSheetAt(sheetnum);
			} else if (fileExtensionName.equals(".xlsx")) {
				wb = new XSSFWorkbook(fis);
				sheet1 = (XSSFSheet) wb.getSheetAt(sheetnum);
			} else if (fileExtensionName.equals(".xlsm")) {
				wb = new XSSFWorkbook(OPCPackage.open(fis));
				sheet1 = wb.getSheetAt(sheetnum);
			}else
				wb = new HSSFWorkbook(fis);
			    sheet1 = wb.getSheetAt(sheetnum);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public int lastrowno() {
		int lastrow = sheet1.getLastRowNum();
		return lastrow;
	}

	public String excelread(int rownum, int cellnum) {
		DataFormatter formatter = new DataFormatter();

		// return sheet1.getRow(rownum-1).getCell(cellnum-1).getStringCellValue();
		return formatter.formatCellValue(sheet1.getRow(rownum - 1).getCell(cellnum - 1));

	}

	public Date exceldateread(int rownum, int cellnum) {

		return (Date) sheet1.getRow(rownum - 1).getCell(cellnum - 1).getDateCellValue();
	}

	public int excelintread(int rownum, int cellnum) {
		return (int) sheet1.getRow(rownum - 1).getCell(cellnum - 1).getNumericCellValue();
	}

	public void setData(int row, int col, String data) throws Throwable {
		// sheet1 = wb.getSheetAt(sheetnumber-1);
		r = sheet1.getRow(row - 1);
		cell = r.createCell(col - 1);
		cell.setCellValue(data);
		FileOutputStream fileOut = new FileOutputStream(filepath);
		wb.write(fileOut);
		fileOut.close();
	}
	public void close(){
	try {
		fis.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	}
	/*   =IF('Source File Details'!A2<>"",'Source File Details'!A2,"")
    =IF('Target File Details'!A2<>"",'Target File Details'!A2,"")*/
//  Runtime.getRuntime().exec("cmd /c taskkill /f /im excel.exe");
	public void deleteData(int sheetNum){
		Iterator<Row> rowIte =  sheet1.iterator();
		while(rowIte.hasNext()){
		    rowIte.next();              
		    rowIte.remove();
		}
		try {
			fis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}