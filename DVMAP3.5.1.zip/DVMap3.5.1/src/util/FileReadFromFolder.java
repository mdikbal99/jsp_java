package util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileReadFromFolder {

	
	public static List<String> listFilesForFolderForTarget(final File folder2) throws IOException {
		List<String> list = new ArrayList<String>();
		for (final File fileEntry : folder2.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolderForTarget(fileEntry);
			} else {
				list.add(folder2 + "\\" + fileEntry.getName());
			}
		}
		
		return list;

	}

	public static List<String> listFilesForFolderForSource(final File folder) throws IOException {
		List<String> list = new ArrayList<String>();
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolderForSource(fileEntry);
			} else {
				list.add(folder + "\\" + fileEntry.getName());
			}
		}

		/*
		 * for(String a:list){ System.out.println(a); }
		 */

		// way 2
		/*
		 * Files.walk(Paths.get("D:/DataValidation/New Folder"))
		 * .filter(Files::isRegularFile) .forEach(System.out::println);
		 */

		// way 3
		/*
		 * List<File> filesInFolder =
		 * Files.walk(Paths.get("D:/DataValidation/New Folder"))
		 * .filter(Files::isRegularFile) .map(Path::toFile)
		 * .collect(Collectors.toList()); for(File a:filesInFolder){
		 * System.out.println(a); }
		 */

		/*
		 * try (Stream<Path> paths = Files.walk(Paths.get("/home/you/Desktop")))
		 * { paths .filter(Files::isRegularFile) .forEach(System.out::println);
		 * }catch (Exception e) {}
		 */

		// return filesInFolder;
		return list;

	}

}
