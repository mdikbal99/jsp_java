package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Scanner;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import FileComapre.MainClassFileValidation;
import application.Main;

public class FileSplit extends MainClassFileValidation{
	static double nol = 900486.0; // No. of lines to be split and saved in each
	static double noOfFiles;
	

	public static Logger loggerFileSplit = LogManager.getLogger(FileSplit.class);
	public static void fileSplitForTarget(){
		Main.defaultTBigSavedPath = Main.defaultSavedPath + Main.defaultResultFolderName + "tempTargetSplit\\";
		try {
				PropertiesConfiguration configFile = new PropertiesConfiguration("filePathDetails.properties");
				String inputfile=(String) configFile.getProperty("file2Path");


			File file = new File(inputfile);
			Scanner scanner = new Scanner(file);

			int count = 0;
			while (scanner.hasNextLine()) {
				scanner.nextLine();
				count++;
			}
			System.out.println("Lines in the file: " + count);

			double temp = (count / nol);
			int temp1 = (int) temp;
			int nof = 0;
			if (temp1 == temp) {
				nof = temp1;
			} else {
				nof = temp1 + 1;
			}
			System.out.println("No. of files to be generated for Target :" + nof);

			scanner.close();
 // ---------------------------------------------------------------------------------------------------------------------

			FileInputStream fstream = new FileInputStream(inputfile);
			DataInputStream in = new DataInputStream(fstream);

			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			
            File splitedFilePathT=new File(Main.defaultTBigSavedPath + "File1.txt");
            splitedFilePathT.getParentFile().mkdirs();

			for (int j = 1; j <= nof; j++) {

				FileWriter fstream1 = new FileWriter(Main.defaultTBigSavedPath + "File" + j + ".txt");

				// fstream1.getParentFile().mkdirs();
				BufferedWriter out = new BufferedWriter(fstream1);
				for (int i = 1; i <= nol; i++) {
					strLine = br.readLine();
					if (strLine != null) {
						out.write(strLine);
						if (i != nol) {
							out.newLine();
						}
					}
				}
				out.close();
				fstream1.close();
			}
			fstream.close();
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			loggerFileSplit.error("Exception in target FileSplit",e);
		}

	}

	public static void fileSplitForSource(){
		Main.defaultSBigSavedPath = Main.defaultSavedPath + Main.defaultResultFolderName + "tempSourceSplit\\";
		try {

			PropertiesConfiguration configFile = new PropertiesConfiguration("filePathDetails.properties");
			String inputfile=(String) configFile.getProperty("file1Path");

			File file = new File(inputfile);
			Scanner scanner = new Scanner(file);

			int count = 0;
			while (scanner.hasNextLine()) {
				scanner.nextLine();
				count++;
			}
			System.out.println("Lines in the file: " + count);

			double temp = (count / nol);
			int temp1 = (int) temp;
			int nof = 0;
			if (temp1 == temp) {
				nof = temp1;
			} else {
				nof = temp1 + 1;
			}
			System.out.println("No. of files to be generated for Source:" + nof);
			scanner.close();
			// ---------------------------------------------------------------------------------------------------------

			FileInputStream fstream = new FileInputStream(inputfile);
			DataInputStream in = new DataInputStream(fstream);

			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;

			File splitedFilePathS=new File(Main.defaultSBigSavedPath + "File1.txt");
			splitedFilePathS.getParentFile().mkdirs();
			
			for (int j = 1; j <= nof; j++) {
				FileWriter fstream1 = new FileWriter(Main.defaultSBigSavedPath + "File" + j + ".txt");

				// fstream1.getParentFile().mkdirs();
				BufferedWriter out = new BufferedWriter(fstream1);
				for (int i = 1; i <= nol; i++) {
					strLine = br.readLine();
					if (strLine != null) {
						out.write(strLine);
						if (i != nol) {
							out.newLine();
						}
					}
				}
				out.close();
				fstream1.close();
			}
			fstream.close();
			in.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			loggerFileSplit.error("Excetion in source filesplit",e);
		}


	}
	public static void deleteTempFiles(){
		try {
		    String [] s=new File(Main.defaultSBigSavedPath).list();
		    String [] t=new File(Main.defaultTBigSavedPath).list();
		   for(String a:s){
		    File filess =new File(Main.defaultSBigSavedPath + a);
			filess.delete();
		   }
		   for(String b:t){
			   File fileT =new File(Main.defaultTBigSavedPath + b);
			   fileT.delete();
		   }

		}
		 catch (Exception e) {
			e.printStackTrace();
		}


	}

}
