package analysis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import FileComapre.StringReformat;
import javaFrame.AnalysisForm;

public class AnalyzeOfFiles {
	static String UnMatchfile1;
	static String UnMatchfile2;
	static String Matchfile;

	static int sourceCounter = 0;
	static int targetCounter = 0;
	static String folderLocation;
	public static Logger loggerAnalyzeOfFiles = LogManager.getLogger(AnalyzeOfFiles.class);
	public static void analyzeFile(String analyzeFolder) {

		folderLocation = AnalysisForm.folderPath;
		String sourceFile = analyzeFolder + "\\SourceNotInTarget.txt";
		String targetFile = analyzeFolder + "\\TagetNotInSource.txt";

		Matchfile = folderLocation + "\\Analysis\\" + "missMatchResult.txt";
		UnMatchfile1 = folderLocation + "\\Analysis\\" + "recordsNotInTarget.txt";
		UnMatchfile2 = folderLocation + "\\Analysis\\" + "recordsNotInSource.txt";
		File files = new File(UnMatchfile1);
		files.getParentFile().mkdirs();

		ArrayList<String> listA = new ArrayList<String>();
		ArrayList<String> listB = new ArrayList<String>();
		String targetStr;
		String sourceStr;
		try {
			FileReader fr = new FileReader(sourceFile);
			String Data1;
			BufferedReader br = new BufferedReader(fr);
			int sourceLines = 0;
			while ((Data1 = br.readLine()) != null) {
				sourceLines = sourceLines + 1;
				if (sourceLines == 1) {
					for (int i = 0; i <= Data1.length() - 1; i++) {
						if (Data1.charAt(i) == '|') {
							sourceCounter = sourceCounter + 1;
						}
					}
				}
				sourceStr = "";
				sourceStr = Data1;
				listA.add(sourceStr);
			}
			listA.trimToSize();
			br.close();
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			FileReader frt = new FileReader(targetFile);
			String Data2;
			BufferedReader br2 = new BufferedReader(frt);
			int targetLines = 0;
			while ((Data2 = br2.readLine()) != null) {
				targetLines = targetLines + 1;
				if (targetLines == 1) {
					for (int i = 0; i <= Data2.length() - 1; i++) {
						if (Data2.charAt(i) == '|') {
							targetCounter = targetCounter + 1;
						}
					}
				}
				targetStr = "";
				targetStr = Data2;
				listB.add(targetStr);
			}
			listB.trimToSize();
			br2.close();
			frt.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		AnalyzeOfFiles.compareLists(listA, listB);

		sourceCounter = 0;
		targetCounter = 0;
		folderLocation = null;
		listA.clear();
		listB.clear();
		System.out.println("Analysis Completed" + StringReformat.folderwithDate(""));

	}

	private static void compareLists(ArrayList<String> firstList, ArrayList<String> secondList) {
		Map<String, String> mapForFirstList = new HashMap<String, String>();
		Map<String, String> mapForSecondList = new HashMap<String, String>();
		@SuppressWarnings("rawtypes")
		Iterator firstListIterator = firstList.iterator();
		@SuppressWarnings("rawtypes")
		Iterator secondListIterator = secondList.iterator();
		String value1;
		while (firstListIterator.hasNext()) {
			String firstListKeyValue = firstListIterator.next().toString();
			// firstListKeyValue=firstListKeyValue.replace("||", "|Blank|");
			try {
				value1 = firstListKeyValue.split("\\|")[sourceCounter - 1];
			} catch (Exception e) {
				value1 = "";
				e.printStackTrace();
			}
			String firstListKeyValueS = "";
			for (int j = 0; j < sourceCounter - 1; j++) {
				try {
					firstListKeyValueS = firstListKeyValueS + firstListKeyValue.split("\\|")[j].trim() + "|";
				} catch (Exception e) {
					firstListKeyValueS = firstListKeyValueS + "|";
				}
			}

			if (!mapForFirstList.containsKey(firstListKeyValueS)) {
				mapForFirstList.put(firstListKeyValueS, value1);

			}
		}
		firstList.clear();
		String value2;
		while (secondListIterator.hasNext()) {
			String secondListKeyValue = secondListIterator.next().toString();
			// secondListKeyValue=secondListKeyValue.replace("||", "|Blank|");
			try {
				value2 = secondListKeyValue.split("\\|")[targetCounter - 1];
			} catch (Exception e) {
				value2 = "";
			}
			String secondListKeyValueT = "";
			for (int t = 0; t < targetCounter - 1; t++) {
				try {
					secondListKeyValueT = secondListKeyValueT + secondListKeyValue.split("\\|")[t].trim() + "|";
				} catch (Exception e) {
					secondListKeyValueT = secondListKeyValueT + "|";
				}
			}
			if (!mapForSecondList.containsKey(secondListKeyValueT)) {
				mapForSecondList.put(secondListKeyValueT, value2);
			}
		}
		secondList.clear();
		compareAndPrintResults(mapForFirstList, mapForSecondList);
	}

	private static void compareAndPrintResults(Map<String, String> mapForFirstList,
			Map<String, String> mapForSecondList) {

		printItemsFromFirstListThatAreNotOnSecondList(mapForFirstList, mapForSecondList);
		printItemsFromSecondListThatAreNotOnFirstList(mapForFirstList, mapForSecondList);
		printItemsFromFirstListThatAreOnSecondList(mapForFirstList, mapForSecondList);
	}

	private static void printItemsFromFirstListThatAreNotOnSecondList(Map<String, String> mapA,
			Map<String, String> mapB) {
		doComparisionAndPrint1(mapA, mapB);
	}

	private static void printItemsFromSecondListThatAreNotOnFirstList(Map<String, String> mapA,
			Map<String, String> mapB) {
		doComparisionAndPrint2(mapA, mapB);
	}

	private static void printItemsFromFirstListThatAreOnSecondList(Map<String, String> mapA, Map<String, String> mapB) {
		doSameComparisionAndPrint(mapA, mapB);
	}

	private static void doComparisionAndPrint1(Map<String, String> mapA, Map<String, String> mapB) {
		if (mapA != null && mapB != null) {
			Iterator<String> mapAIterator = mapA.keySet().iterator();
			int lineOne1 = 0;
			try (BufferedWriter bw1 = new BufferedWriter(new FileWriter(UnMatchfile1, true))) {
				while (mapAIterator.hasNext()) {
					String key = mapAIterator.next().toString();
					Object valueA = mapA.get(key);
					if (!mapB.containsKey(key)) {
						if (lineOne1 == 0) {
							String towrite = "";
							for (int i = 0; i < sourceCounter; i++) {
								towrite = towrite + "|";
							}
							towrite = "Key" + towrite + "Source Not In Target|";
							bw1.write(towrite);
							bw1.newLine();
							lineOne1 = lineOne1 + 1;
						}
						bw1.write(key + "|" + valueA.toString());
						bw1.newLine();
					}
				}
				bw1.close();
			} catch (IOException e) {
				e.printStackTrace();
				loggerAnalyzeOfFiles.error("Exception In Analysis Of file",e);
			}
		}
	}

	private static void doComparisionAndPrint2(Map<String, String> mapA, Map<String, String> mapB) {

		if (mapA != null && mapB != null) {
			Iterator<String> mapBIterator = mapB.keySet().iterator();
			int lineOne2 = 0;
			try (BufferedWriter bw1 = new BufferedWriter(new FileWriter(UnMatchfile2, true))) {
				while (mapBIterator.hasNext()) {
					String keyb = mapBIterator.next().toString();
					Object valueB = mapB.get(keyb);
					if (!mapA.containsKey(keyb)) {
						if (lineOne2 == 0) {
							String towrite = "";
							for (int i = 0; i < sourceCounter; i++) {
								towrite = towrite + "|";
							}
							towrite = "Key" + towrite + "Target Not In Source|";
							bw1.write(towrite);
							bw1.newLine();
							lineOne2 = lineOne2 + 1;
						}
						bw1.write(keyb + "|" + valueB.toString());
						bw1.newLine();
					}
				}
				bw1.close();
			} catch (IOException e) {
				e.printStackTrace();
				loggerAnalyzeOfFiles.error("Exception In Analysis Of file",e);
			}
		}

	}

	private static void doSameComparisionAndPrint(Map<String, String> mapA, Map<String, String> mapB) {
		if (mapA != null && mapB != null) {
			Iterator<String> mapAIterator = mapA.keySet().iterator();
			int lineOne = 0;
			try (BufferedWriter bw1 = new BufferedWriter(new FileWriter(Matchfile, true))) {
				while (mapAIterator.hasNext()) {
					String key = mapAIterator.next().toString();
					Object valuea = mapA.get(key);
					if (mapB.containsKey(key)) {
						Object valueb = mapB.get(key);

						if (lineOne == 0) {
							String towrite = "";
							for (int i = 0; i < sourceCounter; i++) {
								towrite = towrite + "|";
							}
							towrite = "Key" + towrite + "Source Attribute Value|" + "Target Attribute Value";
							bw1.write(towrite);
							bw1.newLine();

						}
						lineOne = lineOne + 1;
						System.out.println(
								"line " + lineOne + "::" + key + "|" + valuea.toString() + "|" + valueb.toString());

						bw1.write(key + "|" + valuea.toString() + "|" + valueb.toString());
						bw1.newLine();

					}
				}
				bw1.close();
			} catch (IOException e) {
				loggerAnalyzeOfFiles.error("Exception In Analysis Of file",e);
				e.printStackTrace();
			}

		}
	}
}
