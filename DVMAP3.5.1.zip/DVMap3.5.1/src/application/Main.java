package application;

import java.io.File;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import org.apache.log4j.Logger;
import com.google.common.collect.Iterators;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import FileComapre.MainClassFileValidation;
import javaFrame.WelcomeForm;
import javafx.application.Application;


public class Main extends MainClassFileValidation {

	static DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	static DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("_yyy-MM-dd_hh-mm-ss");
	public static LocalDate nowDate = LocalDate.now();  
	public static LocalDateTime nowDateTime = LocalDateTime.now();
	public static String currentDate = dtf1.format(nowDate);
	public static String currentDateTime = dtf2.format(nowDateTime);
	public static String defaultSavedPath = null;
	public static String defaultSBigSavedPath = null;
	public static String defaultTBigSavedPath = null;
	public static String defaultResultFolderName = null;
	public static String macAddressFromMachine = null;
	
	public static boolean isAdministrator = false;
	public static boolean isAdmin = false;
	public static boolean isActivated = false;
	public static boolean isKeyPresent = false;
	
	public static int appCount = 0;
	public static int dbNameCount = 0;
	public static int hostCount = 0;
	public static int portCount = 0;
	public static int tableCount = 0;
	public static int regionCount = 0;
	public static int serverCount=0;
	
	public static Logger loggerMain = Logger.getLogger(Main.class);
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws ConfigurationException {  

		File file = new File("C:\\DVMapLog\\logFile.log");
		PrintWriter writer;
		try {
			writer = new PrintWriter(file);
			writer.print("");
			writer.close();
		} catch (Exception e) {
			loggerMain.error("FileNotFoundException: C:\\DVMapLog\\logFile.log is NOT FOUND!", e);
			e.printStackTrace();
		}
		
		InetAddress ip = null;
		try {
			try {
				ip = InetAddress.getLocalHost();
			} catch (Exception e1) {
				loggerMain.error("UnknownHostException: Error to get IP Address of this Machine", e1);
				e1.printStackTrace();
			}
			NetworkInterface network = NetworkInterface.getByInetAddress(ip);
			byte[] mac = network.getHardwareAddress();
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < mac.length; i++) {
				sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));		
			}
			macAddressFromMachine = sb.toString();
			loggerMain.info("MAC Address of this Machine is: " + macAddressFromMachine);
		} catch (Exception e1) {
			loggerMain.error("SocketException: Error to get Hardware Address of this Machine", e1);
			e1.printStackTrace();
		}
		
		PropertiesConfiguration filePathDetails = new PropertiesConfiguration("filePathDetails.properties");
		defaultSavedPath = (String) filePathDetails.getProperty("defaultResultFolderPath");
		defaultResultFolderName = (String) filePathDetails.getProperty("defaultResultFolderName");
		
		PropertiesConfiguration appDetailsFile = new PropertiesConfiguration("appDetails.properties");
		Iterator<String> keys1 = appDetailsFile.getKeys();
		appCount = Iterators.size(keys1);
		loggerMain.info("the app count="+appCount);
		
		PropertiesConfiguration hostDetailsFile = new PropertiesConfiguration("hostDetails.properties");
		Iterator<String> keys2 = hostDetailsFile.getKeys();
		hostCount = Iterators.size(keys2);
		loggerMain.info("the host count="+hostCount);
		
		PropertiesConfiguration dbDetailsFile = new PropertiesConfiguration("dbNameDetails.properties");
		Iterator<String> keys3 = dbDetailsFile.getKeys();
		dbNameCount = Iterators.size(keys3);
		loggerMain.info("database count="+dbNameCount);
				
		PropertiesConfiguration portDetailsFile = new PropertiesConfiguration("portDetails.properties");
		Iterator<String> keys4 = portDetailsFile.getKeys();
		portCount = Iterators.size(keys4);
		loggerMain.info("total port number count="+portCount);
			
		PropertiesConfiguration regionDetailsFile = new PropertiesConfiguration("regionDetails.properties");
		Iterator<String> keys5 = regionDetailsFile.getKeys();
		regionCount = Iterators.size(keys5);
		loggerMain.info("total region count"+regionCount);
		
		PropertiesConfiguration tableDetailsFile = new PropertiesConfiguration("tableDetails.properties");
		Iterator<String> keys6 = tableDetailsFile.getKeys();
		tableCount = Iterators.size(keys6);
		loggerMain.info("total table count="+tableCount);
		
		System.out.println("MAC Address of this Machine is: " + macAddressFromMachine);
		//System.out.println(StringEncrpt.encrypt("6C-4B-90-09-5B-0C"+","+"admin"+","+"admin"+","+"admin"+","+nowDate.plusMonths(1)));
		//StringEncrpt.encrypt(macAddressFromMachine+","+"final"+","+"final"+","+"admin"+","+nowDate.plusYears(1));
		//System.out.println(StringEncrpt.encrypt("C4-65-16-22-85-BD"+","+"mns"+","+"mns"+","+"admin"+","+nowDate.plusYears(1)));
        //System.out.println(StringDecrpt.decrypt("9EUNvdio9HfcWOd3KCjJgavXJwwWmDrcWqvtRw19+//IAqbdFKR75NBo0CTHSpV8\r\n"));
		Application.launch(WelcomeForm.class, args);
		
		
	}
}
