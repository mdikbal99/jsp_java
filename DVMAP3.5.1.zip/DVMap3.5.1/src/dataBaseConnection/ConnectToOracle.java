package dataBaseConnection;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Properties;

import FileComapre.StringReformat;


public class ConnectToOracle {

	public static void runConnectToOracle(String AppName,String dbType, String SQLQuery, String path) {
    	String hostname = null;
    	String userid = null;
    	String password = null;
		try {
			File file = new File("configureDetails.properties");
			FileInputStream fileInput = new FileInputStream(file);
	        Properties configFile = new Properties();
	    	configFile.load(fileInput);
			fileInput.close();
			hostname = configFile.getProperty("dbHostName");
			userid = configFile.getProperty("dbUserName");
			password = configFile.getProperty("dbPassword");
			System.out.println("Database Host Name: " + hostname);
			System.out.println("Database User Name: " + userid);
			System.out.println("Database Password: " + password);
			
//			String url = "jdbc:db2://"+hostname+".metlife.com:50000/IBDWQR1";
//			String url = "jdbc:oracle:thin:@localhost:1521:" + dbName, userName, password
//			
			Class.forName("oracle.jdbc.driver.OracleDriver");
	        Connection conn = null;
	        ResultSet rs=null;
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:" + hostname , userid, password);
	        rs = conn.createStatement().executeQuery("Select HLD_NUM, HLD_SFX_NUM, HLD_PROD_CUSIP_ID FROM IBSPAN1D.ST_HLD_HIST WHERE SRC_SYS_CD ='IDST' AND ST_RCD_CUR_IND= 'Y'");
	        ResultSetMetaData rsmd= rs.getMetaData();
	        int colNumber=rsmd.getColumnCount();
	       System.out.println("No of Column is : "+colNumber);
	        	
	        	String fileName = StringReformat.folderwithDate("ExtractFile");
	        	String path1="C:\\Users\\Public\\Documents\\Panorama\\DataValidation\\DataFromDataBase\\"+fileName+".txt";
	        	File fl= new File(path1);
	        	fl.mkdirs();
		    	FileWriter fstream1 = new FileWriter(path1);
		    	
		    	try {
                	Properties configFile1 = new Properties();
                	configFile1.setProperty("fileName", path1);
        			
                	File file1 = new File("extractFileDetails.properties");
        			FileOutputStream fileOut = new FileOutputStream(file1);
        			configFile1.store(fileOut, null);
        			fileOut.close();
        			
        		} catch (IOException e1) {
         
        			e1.printStackTrace();
        		}
		    	
		        BufferedWriter out = new BufferedWriter(fstream1);
		        int count=0;
	        while (rs.next()){
	        	String data="";
	        	 for(int i=1;i<=colNumber;i++){
                data=data+rs.getString(i)+"|";	
	 	        }
	        	out.write(data);
	        	out.newLine();
	        	++count;
	        	
	        }
	      System.out.println(count+"no of lines");
	        out.close();

	        fstream1.close();
	        conn.close();
	        System.exit(0);
		
		} 
		catch (ClassNotFoundException e) {
            System.out.println("Please include Classpath  Where your Hive Driver is located");
            e.printStackTrace();
            //return;
        }
		catch (Exception e) {
        	System.out.println("please check your SQL query");
			e.printStackTrace();
		}
		
		
	}

}
