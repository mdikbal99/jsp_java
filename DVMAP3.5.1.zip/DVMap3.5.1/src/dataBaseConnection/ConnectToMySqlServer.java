package dataBaseConnection;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import application.Main;

public class ConnectToMySqlServer {
	public static boolean mySqlServerDriverError = false;
	public static boolean mySqlServerConnectionError = false;
	public static boolean mySqlServerQueryError = false;
//	public static String db2ColumnName = null;
	public static List<String> mySqlServerColumnNameList = new ArrayList<String>();
	static boolean IOExceptionFlag1 = false;
	static boolean IOExceptionFlag2 = false;
	static boolean SQLExceptionFlag1 = false;
	static boolean SQLExceptionFlag2 = false;
	
	public static Logger ConnectToMySqlServerForm = LogManager.getLogger(ConnectToMySqlServer.class);
	
	public static String downloadedPathMySqlServer() {
		String path = Main.defaultSavedPath + Main.defaultResultFolderName + "MySqlServerData\\" + "ExtractFile";
		File fl = new File(path);
		fl.mkdir();
		return path;
	}
	public static boolean getColumnNameMySqlServer(String AppName, String dbType, String SQLQuery) {
		boolean flag = false;
		String userid = null;
		String password = null;
		String dbName = null;
		String portNo = null;
		String dbServerName = null;
		mySqlServerColumnNameList.clear();
		try {
			File file = new File("configureDetails.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties configFile = new Properties();
			configFile.load(fileInput);
			fileInput.close();
			userid = configFile.getProperty(AppName + dbType + "UserName");
			password = configFile.getProperty(AppName + dbType + "Password");
			dbName = configFile.getProperty(AppName + dbType + "DBName");
			portNo = configFile.getProperty(AppName + dbType + "PortNo");
			dbServerName=configFile.getProperty(AppName + dbType + "MySqlServerName");
			System.out.println("Database Port No: " + portNo);
			System.out.println("Database Server Name: " + dbServerName);
			System.out.println("Database Name: " + dbName);
			System.out.println("Database User Name: " + userid);
			System.out.println("Database Password: " + password);

			 String url =  "jdbc:sqlserver://"+dbServerName+";databaseName="+dbName+";integratedSecurity=true";
			 
			
			  Connection conn = null; ResultSet rs = null;
			  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); conn =
			  DriverManager.getConnection(url, userid, password);
			 
				  
			rs = conn.createStatement().executeQuery(SQLQuery);
	
			try {
				ResultSetMetaData rsmd = rs.getMetaData();
				int colNumber = rsmd.getColumnCount();
				System.out.println("No of Column is : " + colNumber);
				for (int i = 1; i <= colNumber; i++ ) {
					String column = rsmd.getColumnName(i);
					mySqlServerColumnNameList.add(column);
				}
			} catch (SQLException e) {
				SQLExceptionFlag1 = true;
				ConnectToMySqlServerForm.error("mySqlServer: SQLException is occurred!", e);
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				SQLExceptionFlag2 = true;
				ConnectToMySqlServerForm.error("mySqlServer: SQLException is occurred when object of Connection is Closing!", e);
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e2) {
			mySqlServerDriverError = true;
			flag = true;
			System.out.println("mySqlServer: Please include Classpath Where your DB2 Driver is located");
			ConnectToMySqlServerForm.error("mySqlServer: Please include Classpath Where your DB2 Driver is located", e2);
			e2.printStackTrace();
		} catch (SQLException e) {
			mySqlServerConnectionError = true;
			mySqlServerQueryError = true;
			flag = true;
			System.out.println("mySqlServer: Database Connection Failed! OR SQL Query is Wrong!");
			ConnectToMySqlServerForm.error("mySqlServer: Database Connection Failed OR SQL Query is Wrong!!", e);
			e.printStackTrace();
		} catch (IOException e) {
			IOExceptionFlag2 = true;
			e.printStackTrace();
		}
		return !flag;
	
	}
	
	public static boolean runConnetmySqlServer(String AppName, String dbType, String SqlQuery, String path) {
		boolean flag = false;
		String hostname = null;
		String userid = null;
		String password = null;
		String dbName = null;
		String dbServerName=null;
		try {
			File file = new File("configureDetails.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties configFile = new Properties();
			configFile.load(fileInput);
			fileInput.close();
			hostname = configFile.getProperty(AppName + dbType + "HostName");
			userid = configFile.getProperty(AppName + dbType + "UserName");
			password = configFile.getProperty(AppName + dbType + "Password");
			dbName = configFile.getProperty(AppName + dbType + "DBName");
			dbServerName=configFile.getProperty(AppName + dbType + "MySqlServerName");
			System.out.println("Database Server Name: " + hostname);
			System.out.println("Database Name: " + dbName);
			System.out.println("Database User Name: " + userid);
			System.out.println("Database Password: " + password);
			System.out.println("MySql Server Name: " + dbServerName);

			 String url =  "jdbc:sqlserver://"+dbServerName+";databaseName="+dbName+";integratedSecurity=true";
			 Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection conn = null;
			ResultSet rs = null;
			conn = DriverManager.getConnection(url, userid, password);
			rs = conn.createStatement().executeQuery(SqlQuery);

			
			File fl = new File(path);
			fl.getParentFile().mkdirs();
			FileWriter fstream1 = new FileWriter(path);
			BufferedWriter out = null;
			int count = 0;
			
			try {
				ResultSetMetaData rsmd = rs.getMetaData();
				int colNumber = rsmd.getColumnCount();
				System.out.println("No of Column is : " + colNumber);
				String name = "|";
				for (int i = 1; i <= colNumber; i++ ) {
				  name = name + rsmd.getColumnName(i) + "|";
				}
				System.out.println("Column Names are: " + name);
				try {
					Properties configFile1 = new Properties();
					configFile1.setProperty("fileName", path);
					File file1 = new File("extractFileDetails.properties");
					FileOutputStream fileOut = new FileOutputStream(file1);
					configFile1.store(fileOut, null);
					fileOut.close();
				} catch (IOException e1) {
					IOExceptionFlag1 = true;
					e1.printStackTrace();
					ConnectToMySqlServerForm.error("mySqlServer: IOException is occurred when object of FileOutputStream is Closing!", e1);
				}

				out = new BufferedWriter(fstream1);

				while (rs.next()) {
					String data = "";
					for (int i = 1; i <= rsmd.getColumnCount(); i++) {
						switch (rsmd.getColumnType(i)) {
						case java.sql.Types.DECIMAL:
							data = data + ((BigDecimal) rs.getBigDecimal(i)).toPlainString() + "|";
							break;
						case java.sql.Types.NUMERIC:
							data = data + ((BigDecimal) rs.getBigDecimal(i)).toPlainString() + "|";
							break;
						case java.sql.Types.INTEGER:
							data = data + rs.getInt(i) + "|";
							break;
						case java.sql.Types.TIME:
							data = data + rs.getTime(i) + "|";
							break;
						case java.sql.Types.BIGINT:
							data = data + rs.getLong(i) + "|";
							break;
						default:
							data = data + rs.getString(i) + "|";
						}
					}
					out.write(data);
					out.newLine();
					++count;
				}
			} catch (SQLException e) {
				SQLExceptionFlag1 = true;
				ConnectToMySqlServerForm.error("mySqlServer: SQLException is occurred!", e);
				e.printStackTrace();
			}
			System.out.println("No Of records : " + count);
			out.close();
			fstream1.close();
			try {
				conn.close();
			} catch (SQLException e) {
				SQLExceptionFlag2 = true;
				ConnectToMySqlServerForm.error("mySqlServer: SQLException is occurred when object of Connection is Closing!", e);
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			mySqlServerDriverError = true;
			flag = true;
			System.out.println("mySqlServer: Please include Classpath Where your DB2 Driver is located");
			ConnectToMySqlServerForm.error("mySqlServer: Please include Classpath Where your DB2 Driver is located", e2);
			e2.printStackTrace();
		} catch (SQLException e) {
			mySqlServerConnectionError = true;
			mySqlServerQueryError = true;
			flag =  true;
			System.out.println("mySqlServer: Database Connection Failed! OR SQL Query is Wrong!");
			ConnectToMySqlServerForm.error("mySqlServer: Database Connection Failed OR SQL Query is Wrong!!", e);
			e.printStackTrace();
		} catch (IOException e) {
			IOExceptionFlag2 = true;
			e.printStackTrace();
		}
		return !flag;
	}
}
