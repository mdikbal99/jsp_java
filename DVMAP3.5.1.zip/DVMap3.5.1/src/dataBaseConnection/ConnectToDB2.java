package dataBaseConnection;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.math.BigDecimal;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import application.Main;

public class ConnectToDB2 {
	
	public static boolean db2DriverError = false;
	public static boolean db2ConnectionError = false;
	public static boolean db2QueryError = false;
//	public static String db2ColumnName = null;
	public static List<String> db2ColumnNameList = new ArrayList<String>();
	static boolean IOExceptionFlag1 = false;
	static boolean IOExceptionFlag2 = false;
	static boolean SQLExceptionFlag1 = false;
	static boolean SQLExceptionFlag2 = false;
	
	public static Logger ConnectToDB2Form = LogManager.getLogger(ConnectToDB2.class);
	
	public static String downloadedPathDB2() {
		String path = Main.defaultSavedPath + Main.defaultResultFolderName + "DB2Data\\" + "ExtractFile";
		File fl = new File(path);
		fl.mkdir();
		return path;
	}
	
	public static boolean getColumnNameDB2(String AppName, String dbType, String SQLQuery) {
		boolean flag = false;
		String hostname = null;
		String userid = null;
		String password = null;
		String dbName = null;
		String portNo = null;
		db2ColumnNameList.clear();
		try {
			File file = new File("configureDetails.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties configFile = new Properties();
			configFile.load(fileInput);
			fileInput.close();
			hostname = configFile.getProperty(AppName + dbType + "HostName");
			userid = configFile.getProperty(AppName + dbType + "UserName");
			password = configFile.getProperty(AppName + dbType + "Password");
			dbName = configFile.getProperty(AppName + dbType + "DBName");
			portNo = configFile.getProperty(AppName + dbType + "PortNo");
			System.out.println("Database Port No: " + portNo);
			System.out.println("Database Host Name: " + hostname);
			System.out.println("Database Name: " + dbName);
			System.out.println("Database User Name: " + userid);
			System.out.println("Database Password: " + password);

			// String url = "jdbc:db2://AXRSGPAR0066:50000/IBDWQR1";
			String url = "jdbc:db2://" + hostname + ":" + portNo + "/" + dbName;

			Class.forName("com.ibm.db2.jcc.DB2Driver");
			Connection conn = null;
			ResultSet rs = null;
			conn = DriverManager.getConnection(url, userid, password);
			rs = conn.createStatement().executeQuery(SQLQuery);
	
			try {
				ResultSetMetaData rsmd = rs.getMetaData();
				int colNumber = rsmd.getColumnCount();
				System.out.println("No of Column is : " + colNumber);
				// The column count starts from 1
				//db2ColumnName = ",";
				for (int i = 1; i <= colNumber; i++ ) {
					String column = rsmd.getColumnName(i);
					db2ColumnNameList.add(column);
				  // Do stuff with name
				}
//				System.out.println("Column Names are: " + db2ColumnName);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				SQLExceptionFlag1 = true;
				ConnectToDB2Form.error("DB2: SQLException is occurred!", e);
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				SQLExceptionFlag2 = true;
				ConnectToDB2Form.error("DB2: SQLException is occurred when object of Connection is Closing!", e);
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			db2DriverError = true;
			flag = true;
			System.out.println("DB2: Please include Classpath Where your DB2 Driver is located");
			ConnectToDB2Form.error("DB2: Please include Classpath Where your DB2 Driver is located", e2);
			e2.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			db2ConnectionError = true;
			db2QueryError = true;
			flag = true;
			System.out.println("DB2: Database Connection Failed! OR SQL Query is Wrong!");
			ConnectToDB2Form.error("DB2: Database Connection Failed OR SQL Query is Wrong!!", e);
			e.printStackTrace();
		} catch (IOException e) {
			IOExceptionFlag2 = true;
			e.printStackTrace();
		}
//		db2ConnectionError && db2DriverError && db2QueryError && IOExceptionFlag2 && SQLExceptionFlag1 && SQLExceptionFlag2;
		return !flag;
	
	}

	public static boolean runConnetDB2(String AppName, String dbType, String SqlQuery, String path) {
		boolean flag = false;
		String hostname = null;
		String userid = null;
		String password = null;
		String dbName = null;
		String portNo = null;
		try {
			File file = new File("configureDetails.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties configFile = new Properties();
			configFile.load(fileInput);
			fileInput.close();
			hostname = configFile.getProperty(AppName + dbType + "HostName");
			userid = configFile.getProperty(AppName + dbType + "UserName");
			password = configFile.getProperty(AppName + dbType + "Password");
			dbName = configFile.getProperty(AppName + dbType + "DBName");
			portNo = configFile.getProperty(AppName + dbType + "PortNo");
			System.out.println("Database Port No: " + portNo);
			System.out.println("Database Host Name: " + hostname);
			System.out.println("Database Name: " + dbName);
			System.out.println("Database User Name: " + userid);
			System.out.println("Database Password: " + password);

			// String url = "jdbc:db2://AXRSGPAR0066:50000/IBDWQR1";
			String url = "jdbc:db2://" + hostname + ":" + portNo + "/" + dbName;

			Class.forName("com.ibm.db2.jcc.DB2Driver");
			Connection conn = null;
			ResultSet rs = null;
			conn = DriverManager.getConnection(url, userid, password);
			rs = conn.createStatement().executeQuery(SqlQuery);
//			catch (SQLException e) {
//				// TODO Auto-generated catch block
//				db2QueryError = true;
//				System.out.println("DB2: SQL Query is Wrong!");
//				ConnectToDB2Form.error("DB2: SQL Query is Wrong!", e);
//				e.printStackTrace();
//			}
			
			File fl = new File(path);
			fl.getParentFile().mkdirs();
			FileWriter fstream1 = new FileWriter(path);
			BufferedWriter out = null;
			int count = 0;
			
			try {
				ResultSetMetaData rsmd = rs.getMetaData();
				int colNumber = rsmd.getColumnCount();
				System.out.println("No of Column is : " + colNumber);
				// The column count starts from 1
				String name = "|";
				for (int i = 1; i <= colNumber; i++ ) {
				  name = name + rsmd.getColumnName(i) + "|";
				  // Do stuff with name
				}
				System.out.println("Column Names are: " + name);
				try {
					Properties configFile1 = new Properties();
					configFile1.setProperty("fileName", path);
					File file1 = new File("extractFileDetails.properties");
					FileOutputStream fileOut = new FileOutputStream(file1);
					configFile1.store(fileOut, null);
					fileOut.close();
				} catch (IOException e1) {
					IOExceptionFlag1 = true;
					e1.printStackTrace();
					ConnectToDB2Form.error("DB2: IOException is occurred when object of FileOutputStream is Closing!", e1);
				}

				out = new BufferedWriter(fstream1);
//				while (rs.next()) {
//					String data = "";
//					for (int i = 1; i <= colNumber; i++) {
//						data = data + rs.getString(i) + "|";
//					}
//					out.write(data);
//					out.newLine();
//					++count;
//				}
				while (rs.next()) {
					String data = "";
					for (int i = 1; i <= rsmd.getColumnCount(); i++) {
						//System.out.println("Column type at "+i+"-->"+rsmd.getColumnTypeName(i));
						/*
						 * INTEGER=4 CHAR=1 CHAR=1 DATE=91 DECIMAL=3
						 */
						switch (rsmd.getColumnType(i)) {
						case java.sql.Types.DECIMAL:
							data = data + ((BigDecimal) rs.getBigDecimal(i)).toPlainString() + "|";
							//data = data +rs.getBigDecimal(i)+"|";
							break;
						case java.sql.Types.NUMERIC:
							data = data + ((BigDecimal) rs.getBigDecimal(i)).toPlainString() + "|";
							break;
						case java.sql.Types.INTEGER:
							data = data + rs.getInt(i) + "|";
							break;
						case java.sql.Types.TIME:
							data = data + rs.getTime(i) + "|";
							break;
						case java.sql.Types.BIGINT:
							data = data + rs.getLong(i) + "|";
							break;
						default:
							data = data + rs.getString(i) + "|";
						}
					}
					out.write(data);
					out.newLine();
					++count;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				SQLExceptionFlag1 = true;
				ConnectToDB2Form.error("DB2: SQLException is occurred!", e);
				e.printStackTrace();
			}
			System.out.println("No Of records : " + count);
			out.close();
			fstream1.close();
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				SQLExceptionFlag2 = true;
				ConnectToDB2Form.error("DB2: SQLException is occurred when object of Connection is Closing!", e);
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			db2DriverError = true;
			flag = true;
			System.out.println("DB2: Please include Classpath Where your DB2 Driver is located");
			ConnectToDB2Form.error("DB2: Please include Classpath Where your DB2 Driver is located", e2);
			e2.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			db2ConnectionError = true;
			db2QueryError = true;
			flag =  true;
			System.out.println("DB2: Database Connection Failed! OR SQL Query is Wrong!");
			ConnectToDB2Form.error("DB2: Database Connection Failed OR SQL Query is Wrong!!", e);
			e.printStackTrace();
		} catch (IOException e) {
			IOExceptionFlag2 = true;
			e.printStackTrace();
		}
//		db2ConnectionError && db2DriverError && db2QueryError && IOExceptionFlag1 && IOExceptionFlag2 && SQLExceptionFlag1 && SQLExceptionFlag2;
		return !flag;
	}
}
